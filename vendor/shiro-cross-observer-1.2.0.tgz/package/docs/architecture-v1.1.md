# Cross-Observer Architecture — v1.1.0 Freeze

**Status:** FROZEN  
**Version:** 1.1.0  
**Definition:** First stable release validated across **Society + Self**.

## Core principle

> Observatories determine WHAT we observe.  
> Lenses determine HOW we see it.

## Layer separation

| Layer | Role | Examples |
|-------|------|----------|
| Protocol | どう思考を進めるか | Kosuke Protocol, Parallel Life Protocol |
| **Lens** | どの視点から見るか | Buddhist Lens (this package) |
| Observatory | 何を観測するか | Clean Society, Entangled Society, Parallel Life, Intimacy |
| **Desire Model** | 欲の形成・方向づけ・変換の構造概念 | [Desire Model v0.1](./desire-model-v0.1.md)（Engine なし） |

- LensResult is a **derived interpretation** — it never mutates the source Observation.
- Kosuke Protocol is **not** registered as a Lens.
- Observatory-internal schemas must not leak into Lens core; use Adapters.
- Desire Model is **not** a Lens and **not** Buddhist psychology; it is a cross-domain concept spec.

## Cross-Domain Proof (v1.1.0)

Cross-Observer v1.1.0 has been validated across:

| Observatory | Domain | Integration |
|-------------|--------|-------------|
| Clean Society (Body Meaning) | institutional / social observations | production |
| Entangled Society | structural / entangled observations | production |
| Parallel Life (kosuke-frontend) | personal / counterfactual life observations | production |
| Intimacy | interpersonal / relationship observations | production (post-freeze extension) |
| Scam Folklore | adversarial / manipulation observations | production (v1.1.1 patch) |
| Employment (Edu–Employment Gap) | incentive / institutional employment | production (v1.1.2 patch) |
| Education (same host) | desire formation / teachable interface | production (v1.1.3 patch) |

Shared SoT (identical across consumers):

- `LensDefinition`
- Lens Registry
- Buddhist concepts B01–B08
- `applyLens`
- `LensResult`
- epistemic safeguards

Observatory-specific surface: **Adapter + host UI wiring only**.

## Distribution

Vendored SoT tarball:

```bash
npm run pack:consumers
# → vendor/shiro-cross-observer-1.1.3.tgz in each consumer
```

Consumers must not copy Lens logic.

## Active Lens (v1.1.0)

- `buddhist` @ Lens definition version `1.0.0` (concept set stable)
- Package version `1.1.5` is a compatible patch (Aging body-change adapter)
- Package version `1.1.6` is a compatible patch (Illness / Chronic Pain disruption adapter)
- Package version `1.2.0` is a compatible minor (production UX presenter; schema unchanged)
- Freeze base remains `1.1.0` (Society + Self proof)
- Same host may wire Employment + Education adapters without Lens core knowing host routes
- Body Meaning may wire Productive Body + Aging Dementia Anxiety + Chronic Pain (`body-meaning`) alongside Forced Crime (`clean-society`) without mixing domains

## Roadmap (not in freeze)

- Additional Lenses (Stoic, Taoist, …)
- Compare Lenses UI
- Desire Engine（[Desire Model v0.1](./desire-model-v0.1.md) は概念仕様のみ — Ready for Engine: **NOT YET**）
- Further Observatory integrations beyond the seven validated domains
