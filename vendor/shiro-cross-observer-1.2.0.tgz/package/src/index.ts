/**
 * @shiro/cross-observer
 * Cross-Observatory Lens Architecture v1.2.0 (v1.1.0 freeze + production UX presenter)
 *
 * Observatories determine WHAT we observe.
 * Lenses determine HOW we see it.
 */

export {
  CROSS_OBSERVER_PACKAGE_VERSION,
  CROSS_OBSERVER_FREEZE,
} from "./version";

export type {
  LensConcept,
  LensDefinition,
  LensInput,
  LensResult,
  LensStatus,
  RelatedPattern,
  LensApplyOutcome,
  LensApplyError,
  LensApplySuccess,
  LensApplyErrorCode,
} from "./types/lens";

export {
  SUPPORTED_OBSERVATORY_IDS,
  isSupportedObservatoryId,
  type SupportedObservatoryId,
} from "./types/observatory";

export { ARCHITECTURE_LAYERS, type FutureMultiLensComparison } from "./architecture/layers";

export {
  listLenses,
  listActiveLenses,
  getLensDefinition,
  hasLens,
  getLensApplicator,
  isBuddhistLensRegistered,
  listFutureLensCandidates,
  getLensRegistrySnapshot,
} from "./registry/lens-registry";

export { applyLens } from "./engine/apply-lens";

export {
  adaptObservation,
  adaptParallelLife,
  parallelLifeToLensInput,
  adaptCleanSociety,
  cleanSocietyToLensInput,
  adaptEntangledSociety,
  entangledSocietyToLensInput,
  intimacyToLensInput,
  scamToLensInput,
  employmentToLensInput,
  educationToLensInput,
  bodyMeaningToLensInput,
  ADAPTERS_BY_OBSERVATORY,
  createLensInput,
  parallelLifeAdapter,
  scamAdapter,
  employmentAdapter,
  educationAdapter,
  cleanSocietyAdapter,
  entangledSocietyAdapter,
  intimacyAdapter,
  marketSignalsAdapter,
  bodyMeaningAdapter,
  literatureAdapter,
  type AdaptableObservation,
  type ObservatoryAdapter,
  type ParallelLifeObservation,
  type CleanSocietyObservation,
  type EntangledSocietyObservation,
  type IntimacyObservation,
  type ScamObservation,
  type EmploymentObservation,
  type EducationObservation,
  type BodyMeaningObservation,
} from "./adapters";

export * from "./lenses/buddhist";
