import type { LensInput, LensResult } from "../types/lens";
import { getBuddhistConceptById } from "../lenses/buddhist/concepts";
import { getLensDefinition } from "../registry/lens-registry";
import {
  excerptObservationText,
  MAX_DISPLAY_SECONDARIES,
} from "../lenses/buddhist/presentation";

type Props = {
  input: LensInput;
  result: LensResult;
  className?: string;
};

function conceptLabel(id: string): string {
  const c = getBuddhistConceptById(id);
  if (!c) return id;
  return `${c.code} ${c.nameJa}`;
}

/**
 * Quiet Lens Result viewer.
 * Hierarchy: Primary → Interpretation → Visible → Related → Limits → Reflection.
 */
export function LensViewer({ input, result, className = "" }: Props) {
  const lens = getLensDefinition(result.lensId);
  const excerpt = excerptObservationText(input.text);
  const secondaries = result.secondaryConcepts.slice(0, MAX_DISPLAY_SECONDARIES);
  const related = (result.relatedPatterns ?? []).slice(0, 3);

  return (
    <article className={`lens-viewer ${className}`.trim()}>
      <p className="annotation">Lens Result · 派生の読み</p>

      <section className="lens-viewer__block lens-viewer__block--context">
        <h2>元の観測</h2>
        {input.title ? (
          <h3 className="lens-viewer__obs-title">{input.title}</h3>
        ) : null}
        <p className="lens-viewer__obs-meta">
          Source: {input.sourceObservatory}
          {input.sourceObservationId ? ` · ${input.sourceObservationId}` : ""}
        </p>
        {excerpt ? <p className="lens-viewer__obs-text">{excerpt}</p> : null}
      </section>

      <section className="lens-viewer__block">
        <h2>レンズ</h2>
        <p>
          {lens?.name ?? result.lensId}
          {lens ? ` / ${lens.nameJa}` : ""}
        </p>
        <p className="lens-viewer__lens-cue">
          仏教思想を、答えではなく観測視点として使う。
        </p>
      </section>

      <section className="lens-viewer__block">
        <h2>主概念</h2>
        <p className="lens-viewer__primary">{conceptLabel(result.primaryConcept)}</p>
      </section>

      {secondaries.length > 0 ? (
        <section className="lens-viewer__block">
          <h2>副次概念</h2>
          <ul className="lens-viewer__chips">
            {secondaries.map((id) => (
              <li key={id} className="lens-viewer__chip">
                {conceptLabel(id)}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="lens-viewer__block">
        <h2>読み</h2>
        <p>{result.interpretation}</p>
      </section>

      <section className="lens-viewer__block">
        <h2>何が見えてくるか</h2>
        <ul>
          {result.whatBecomesVisible.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>

      {related.length > 0 ? (
        <section className="lens-viewer__block lens-viewer__related">
          <h2>関連</h2>
          <ul className="lens-viewer__related-list">
            {related.map((p) => (
              <li key={p.id} className="lens-viewer__related-item">
                <p className="lens-viewer__related-name">
                  {p.name}
                  {p.nameJa ? ` / ${p.nameJa}` : ""}
                </p>
                <p>{p.description}</p>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="lens-viewer__block lens-viewer__limits">
        <details>
          <summary>このレンズでは決められないこと</summary>
          <ul>
            {result.limitations.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </details>
      </section>

      <section className="lens-viewer__block lens-viewer__reflection-block">
        <h2>問い</h2>
        <p className="lens-viewer__reflection">{result.reflectionQuestion}</p>
      </section>
    </article>
  );
}
