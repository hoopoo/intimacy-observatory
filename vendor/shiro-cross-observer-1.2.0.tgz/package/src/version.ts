/** Package freeze metadata — keep in sync with package.json */
export const CROSS_OBSERVER_PACKAGE_VERSION = "1.2.0" as const;

export const CROSS_OBSERVER_FREEZE = {
  version: "1.1.0" as const,
  status: "frozen",
  patch: CROSS_OBSERVER_PACKAGE_VERSION,
  label:
    "Society + Self validated; v1.2.0 production UX presenter (schema unchanged)",
  validatedDomains: [
    "institutional-social",
    "structural-entangled",
    "personal-counterfactual",
    "interpersonal-intimacy",
    "adversarial-scam",
    "employment-incentive",
    "education-formation",
    "embodied-body-meaning",
    "aging-body-change",
    "illness-chronic-pain",
  ],
  productionConsumers: [
    "body-meaning/clean-society",
    "body-meaning/productive-body",
    "body-meaning/aging-dementia-anxiety",
    "body-meaning/chronic-pain",
    "entangled-society",
    "kosuke-frontend/parallel-life",
    "intimacy",
    "scam-folklore",
    "education-employment-gap",
  ],
} as const;
