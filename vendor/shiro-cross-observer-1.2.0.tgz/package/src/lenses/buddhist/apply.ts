import type { LensInput, LensResult, RelatedPattern } from "../../types/lens";
import { BUDDHIST_CONCEPTS, getBuddhistConceptById } from "./concepts";
import {
  BUDDHIST_LIMITATION_NOTE,
  assertObservationLanguage,
} from "./safeguards";
import { detectDesireMotifs, DESIRE_MOTIF_COPY } from "./desire-motif";
import { DEPENDENT_ORIGINATION_COPY } from "./related/entangled-society";
import { COMPOSITE_EVIL_LENS_BRIDGE } from "./related/composite-evil";
import {
  PARALLEL_LIFE_LENS_COPY,
  pickParallelLifeReflectionQuestion,
  containsParallelLifeForbidden,
} from "./parallel-life";
import {
  INTIMACY_LENS_COPY,
  pickIntimacyReflectionQuestion,
  containsIntimacyForbidden,
} from "./intimacy";
import { ROMANCE_PROTOCOL_LENS_BRIDGE } from "./related/romance-protocol-collapse";
import {
  SCAM_LENS_COPY,
  pickScamReflectionQuestion,
  containsScamForbidden,
} from "./scam";
import { INTENTIONAL_HARM_LENS_BRIDGE } from "./related/intentional-harm";
import {
  EMPLOYMENT_LENS_COPY,
  pickEmploymentReflectionQuestion,
  containsEmploymentForbidden,
} from "./employment";
import { STRUCTURAL_INCENTIVIZATION_LENS_BRIDGE } from "./related/structural-incentivization";
import {
  EDUCATION_LENS_COPY,
  pickEducationReflectionQuestion,
  containsEducationForbidden,
} from "./education";
import {
  BODY_MEANING_LENS_COPY,
  containsBodyMeaningForbidden,
  isAgingBodyMeaningInput,
  isIllnessBodyMeaningInput,
  pickBodyMeaningReflectionQuestion,
} from "./body-meaning";
import { EMBODIED_DESIRE_SIGNAL_LENS_BRIDGE } from "./related/embodied-desire-signal";
import { AGING_BODY_CHANGE_LENS_BRIDGE } from "./related/aging-body-change";
import { ILLNESS_CHRONIC_PAIN_LENS_BRIDGE } from "./related/illness-chronic-pain";
import { INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE } from "./related/institutional-desire-formation";
import {
  buildCompactInterpretation,
  buildCompactVisible,
  buildGatedRelatedPatterns,
  compactDesireNote,
  pickCleanSocietyReflectionQuestion,
  pickEntangledReflectionQuestion,
} from "./presentation";
import { BUDDHIST_LENS_ID } from "./definition";

type ScoredConcept = { id: string; score: number };

const CONCEPT_KEYWORDS: Record<string, string[]> = {
  "b01-impermanence": [
    "変わら",
    "変化",
    "老い",
    "時間",
    "制度",
    "関係",
    "永遠",
    "固定",
    "impermanence",
    "change",
    "aging",
  ],
  "b02-dukkha": [
    "苦",
    "満たされ",
    "摩擦",
    "不足",
    "痛み",
    "思い通り",
    "ストレス",
    "dukkha",
    "suffer",
    "摩擦",
    "比較",
    "孤独",
    "不安",
    "羞恥",
    "恥",
    "混乱",
    "疲労",
    "疲れ",
    "不眠",
    "眠気",
    "fatigue",
    "urgency",
    "損失",
    "fear",
    "shame",
  ],
  "b03-non-self": [
    "私",
    "彼ら",
    "会社",
    "社会",
    "肩書",
    "優等生",
    "落ちこぼれ",
    "偏差値",
    "学歴",
    "identity",
    "国際性",
    "役割",
    "アイデンティティ",
    "identity",
    "self",
    "ロール",
  ],
  "b04-dependent-origination": [
    "条件",
    "関係",
    "接続",
    "因果",
    "絡み",
    "entangl",
    "composite",
    "合成",
    "システム",
    "依存",
  ],
  "b05-craving": [
    "欲し",
    "取り戻",
    "失いたく",
    "避けたい",
    "渇",
    "desire",
    "craving",
    "fear",
    "longing",
    "儲け",
    "愛され",
    "知りたい",
    "年収",
    "役職",
    "どうなって",
    "確認",
    "選ばれ",
    "見捨て",
    "もっと良い",
    "マッチ",
    "安心",
    "助けたい",
    "損したく",
    "騙",
    "詐欺",
  ],
  "b06-attachment": [
    "執着",
    "握",
    "手放せ",
    "過去",
    "正解",
    "別の人生",
    "成功像",
    "attachment",
    "cling",
    "評価",
    "残って",
    "もし",
    "未選択",
    "後悔",
    "理想",
    "最適",
    "perfect",
    "sunk",
    "すでに払",
    "信じ",
    "関係が偽物",
  ],
  "b07-emptiness": [
    "意味",
    "価値",
    "カテゴリー",
    "本質",
    "固有",
    "emptiness",
    "本質的",
    "正しい教育",
    "正常",
  ],
  "b08-compassion": [
    "被害",
    "弱",
    "見えな",
    "抜け落ち",
    "排除",
    "blind",
    "compassion",
    "誰の",
    "身体",
    "高齢",
    "孤独",
    "grief",
    "介護",
    "恥",
    "相談",
  ],
};

const OBSERVATORY_CONCEPT_BIAS: Record<string, string[]> = {
  "parallel-life": ["b05-craving", "b06-attachment", "b01-impermanence"],
  scam: [
    "b05-craving",
    "b08-compassion",
    "b06-attachment",
    "b02-dukkha",
    "b04-dependent-origination",
  ],
  employment: [
    "b05-craving",
    "b06-attachment",
    "b04-dependent-origination",
    "b03-non-self",
    "b02-dukkha",
    "b01-impermanence",
    "b08-compassion",
  ],
  education: [
    "b05-craving",
    "b06-attachment",
    "b03-non-self",
    "b04-dependent-origination",
    "b02-dukkha",
    "b01-impermanence",
    "b08-compassion",
  ],
  "clean-society": [
    "b04-dependent-origination",
    "b05-craving",
    "b06-attachment",
  ],
  "entangled-society": [
    "b04-dependent-origination",
    "b08-compassion",
    "b07-emptiness",
  ],
  intimacy: ["b05-craving", "b06-attachment", "b02-dukkha", "b04-dependent-origination"],
  "market-signals": ["b05-craving", "b01-impermanence", "b06-attachment"],
  "body-meaning": [
    "b01-impermanence",
    "b02-dukkha",
    "b03-non-self",
    "b04-dependent-origination",
    "b08-compassion",
    "b05-craving",
    "b06-attachment",
  ],
  literature: ["b06-attachment", "b07-emptiness", "b08-compassion"],
};

function scoreConcepts(input: LensInput): ScoredConcept[] {
  const haystack = `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`;
  const lower = haystack.toLowerCase();

  const scores = BUDDHIST_CONCEPTS.map((concept) => {
    const keys = CONCEPT_KEYWORDS[concept.id] ?? [];
    let score = 0;
    for (const key of keys) {
      if (lower.includes(key.toLowerCase())) score += 2;
    }
    return { id: concept.id, score };
  });

  const bias = OBSERVATORY_CONCEPT_BIAS[input.sourceObservatory] ?? [];
  bias.forEach((id, index) => {
    const row = scores.find((s) => s.id === id);
    if (row) row.score += 3 - Math.min(index, 2);
  });

  // Ensure deterministic non-zero baseline so we always produce a reading.
  for (const row of scores) {
    if (row.score === 0) row.score = 0.1;
  }

  return scores.sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
}

function buildRelatedPatterns(input: LensInput): RelatedPattern[] {
  return buildGatedRelatedPatterns(input);
}

function buildInterpretation(
  input: LensInput,
  primaryId: string,
  _secondaryIds: string[],
  desires: string[],
): string {
  return buildCompactInterpretation(input, primaryId, desires);
}

function buildWhatBecomesVisible(
  input: LensInput,
  _primaryId: string,
  desires: string[],
): string[] {
  return buildCompactVisible(input, desires);
}

/**
 * Apply Buddhist Lens to a common LensInput.
 * Pure function: does not mutate input; returns a derived LensResult.
 */
export function applyBuddhistLens(input: LensInput): LensResult {
  const scored = scoreConcepts(input);
  const primaryConcept = scored[0]!.id;
  const secondaryConcepts = scored
    .slice(
      1,
      input.sourceObservatory === "intimacy"
        ? 5
        : input.sourceObservatory === "scam" ||
            input.sourceObservatory === "employment" ||
            input.sourceObservatory === "education" ||
            input.sourceObservatory === "body-meaning"
          ? 8
          : 4,
    )
    .map((s) => s.id);

  const desireReading = detectDesireMotifs(
    `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
  );

  const interpretation = buildInterpretation(
    input,
    primaryConcept,
    secondaryConcepts,
    desireReading.observedDesires,
  );

  const primary = getBuddhistConceptById(primaryConcept);

  const result: LensResult = {
    lensId: BUDDHIST_LENS_ID,
    sourceObservatory: input.sourceObservatory,
    sourceObservationId: input.sourceObservationId,
    primaryConcept,
    secondaryConcepts,
    interpretation,
    whatBecomesVisible: buildWhatBecomesVisible(
      input,
      primaryConcept,
      desireReading.observedDesires,
    ),
    limitations: [
      BUDDHIST_LIMITATION_NOTE,
      "このレンズは説教・人生訓・占い・精神的権威として機能しない。",
      "宗派固有の教義差（初期仏教・大乗・禅・浄土・密教など）には V1 では深入りしない。",
      "欲の消滅を目標として断定しない。",
      DESIRE_MOTIF_COPY.nonEvilNote,
      ...(input.sourceObservatory === "entangled-society"
        ? [
            DEPENDENT_ORIGINATION_COPY.notIdenticalNote,
            "このレンズは Entangled Society の社会科学的分析を代替しない。縁起を理解すれば解決する、とは言わない。",
          ]
        : []),
      ...(input.sourceObservatory === "clean-society"
        ? [
            COMPOSITE_EVIL_LENS_BRIDGE.boundary,
            "合成悪を、単独の意図的加害や悪人探しと同一視しない。",
          ]
        : []),
      ...(input.sourceObservatory === "parallel-life"
        ? [
            PARALLEL_LIFE_LENS_COPY.counterfactualLimit,
            PARALLEL_LIFE_LENS_COPY.noClosure,
            PARALLEL_LIFE_LENS_COPY.notNegation,
            "このレンズは Parallel Life Protocol の可能性推定を代替しない。",
          ]
        : []),
      ...(input.sourceObservatory === "intimacy"
        ? [
            INTIMACY_LENS_COPY.notAdvice,
            INTIMACY_LENS_COPY.noDeterminism,
            INTIMACY_LENS_COPY.desireNotEvil,
            ROMANCE_PROTOCOL_LENS_BRIDGE.boundary,
          ]
        : []),
      ...(input.sourceObservatory === "scam"
        ? [
            SCAM_LENS_COPY.desireNotFault,
            SCAM_LENS_COPY.actorAsymmetry,
            SCAM_LENS_COPY.intentionalHarmNote,
            SCAM_LENS_COPY.notSecurityAdvice,
            SCAM_LENS_COPY.notSpiritualPrevention,
            INTENTIONAL_HARM_LENS_BRIDGE.boundary,
          ]
        : []),
      ...(input.sourceObservatory === "employment"
        ? [
            EMPLOYMENT_LENS_COPY.desireNotPathology,
            EMPLOYMENT_LENS_COPY.notManipulation,
            EMPLOYMENT_LENS_COPY.actorAsymmetry,
            EMPLOYMENT_LENS_COPY.kpiNotEvil,
            EMPLOYMENT_LENS_COPY.notCareerAdvice,
            STRUCTURAL_INCENTIVIZATION_LENS_BRIDGE.boundary,
            STRUCTURAL_INCENTIVIZATION_LENS_BRIDGE.compositeEvilNote,
          ]
        : []),
      ...(input.sourceObservatory === "education"
        ? [
            EDUCATION_LENS_COPY.parentDesireSafeguard,
            EDUCATION_LENS_COPY.childAgency,
            EDUCATION_LENS_COPY.notManipulation,
            EDUCATION_LENS_COPY.notMereIncentivization,
            EDUCATION_LENS_COPY.noSocialDeterminism,
            EDUCATION_LENS_COPY.learningVsEvaluation,
            EDUCATION_LENS_COPY.notEducationAdvice,
            INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE.boundary,
            INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE.employmentBridge,
          ]
        : []),
      ...(input.sourceObservatory === "body-meaning"
        ? isIllnessBodyMeaningInput(input.text, input.context)
          ? [
              BODY_MEANING_LENS_COPY.painReliefNotCraving,
              BODY_MEANING_LENS_COPY.bodyDisruptionNotDesire,
              BODY_MEANING_LENS_COPY.illnessNotBlame,
              BODY_MEANING_LENS_COPY.noRecoveryMoralism,
              BODY_MEANING_LENS_COPY.physicalVsMeaningSuffering,
              BODY_MEANING_LENS_COPY.desireFearBoundary,
              BODY_MEANING_LENS_COPY.antiReductionism,
              BODY_MEANING_LENS_COPY.illnessMedicalBoundary,
              ILLNESS_CHRONIC_PAIN_LENS_BRIDGE.boundary,
            ]
          : isAgingBodyMeaningInput(input.text, input.context)
            ? [
                BODY_MEANING_LENS_COPY.bodyChangeNotDesire,
                BODY_MEANING_LENS_COPY.needNotCraving,
                BODY_MEANING_LENS_COPY.agingNotMoralize,
                BODY_MEANING_LENS_COPY.noMoralAging,
                BODY_MEANING_LENS_COPY.desireFearBoundary,
                BODY_MEANING_LENS_COPY.antiReductionism,
                BODY_MEANING_LENS_COPY.gerontologicalBoundary,
                AGING_BODY_CHANGE_LENS_BRIDGE.boundary,
              ]
            : [
                BODY_MEANING_LENS_COPY.needNotCraving,
                BODY_MEANING_LENS_COPY.healthNotPathology,
                BODY_MEANING_LENS_COPY.illnessNotBlame,
                BODY_MEANING_LENS_COPY.agingNotMoralize,
                BODY_MEANING_LENS_COPY.antiReductionism,
                BODY_MEANING_LENS_COPY.medicalBoundary,
                EMBODIED_DESIRE_SIGNAL_LENS_BRIDGE.boundary,
              ]
        : []),
    ],
    reflectionQuestion:
      input.sourceObservatory === "parallel-life"
        ? pickParallelLifeReflectionQuestion(
            primaryConcept,
            `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
          )
        : input.sourceObservatory === "intimacy"
          ? pickIntimacyReflectionQuestion(
              primaryConcept,
              `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
            )
          : input.sourceObservatory === "scam"
            ? pickScamReflectionQuestion(
                primaryConcept,
                `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
              )
            : input.sourceObservatory === "employment"
              ? pickEmploymentReflectionQuestion(
                  primaryConcept,
                  `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
                )
              : input.sourceObservatory === "education"
                ? pickEducationReflectionQuestion(
                    primaryConcept,
                    `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
                  )
                : input.sourceObservatory === "body-meaning"
                  ? pickBodyMeaningReflectionQuestion(
                      primaryConcept,
                      `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
                    )
                  : input.sourceObservatory === "entangled-society"
                    ? pickEntangledReflectionQuestion(
                        `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
                      )
                    : input.sourceObservatory === "clean-society"
                      ? pickCleanSocietyReflectionQuestion(
                          `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
                        )
                      : (primary?.question ??
                        "この出来事を、どの仏教的概念からもう一度見ることができるか。"),
    notes: [
      compactDesireNote(desireReading.observedDesires),
      ...(input.sourceObservatory === "entangled-society"
        ? [DEPENDENT_ORIGINATION_COPY.observatoryView]
        : []),
      ...(input.sourceObservatory === "parallel-life"
        ? [PARALLEL_LIFE_LENS_COPY.coexistence]
        : []),
      ...(input.sourceObservatory === "scam"
        ? [
            "Security Layer（どう防ぐか）と Buddhist Lens（どう見るか）は分離する。",
          ]
        : []),
      ...(input.sourceObservatory === "education"
        ? [
            EDUCATION_LENS_COPY.notMereIncentivization,
            INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE.notManipulation,
            INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE.employmentBridge,
          ]
        : []),
      ...(input.sourceObservatory === "body-meaning"
        ? isIllnessBodyMeaningInput(input.text, input.context)
          ? [
              BODY_MEANING_LENS_COPY.branchingModel,
              BODY_MEANING_LENS_COPY.painReliefNotCraving,
              ILLNESS_CHRONIC_PAIN_LENS_BRIDGE.vsFatigueAging,
            ]
          : isAgingBodyMeaningInput(input.text, input.context)
            ? [
                BODY_MEANING_LENS_COPY.branchingModel,
                BODY_MEANING_LENS_COPY.socialTranslationAging,
                AGING_BODY_CHANGE_LENS_BRIDGE.vsFatigue,
              ]
            : [
                BODY_MEANING_LENS_COPY.embodiedSignal,
                BODY_MEANING_LENS_COPY.needNotCraving,
              ]
        : []),
    ],
    relatedPatterns: buildRelatedPatterns(input),
  };

  // Soft guard: interpretation must stay in observation language.
  if (
    !assertObservationLanguage(result.interpretation) ||
    containsParallelLifeForbidden(result.interpretation) ||
    containsIntimacyForbidden(result.interpretation) ||
    containsScamForbidden(result.interpretation) ||
    containsEmploymentForbidden(result.interpretation) ||
    containsEducationForbidden(result.interpretation) ||
    containsBodyMeaningForbidden(result.interpretation)
  ) {
    result.interpretation =
      input.sourceObservatory === "body-meaning"
        ? "一つの仏教思想的な読み方として、このレンズでは身体信号・必要・意味づけ・欲の接続が見えてくる。医療断定や渇愛への還元ではなく、観測にとどめる。"
        : input.sourceObservatory === "education"
        ? "一つの仏教思想的な読み方として、このレンズでは欲求の意味形成と評価・credentialの接続が見えてくる。親の断罪や洗脳モデルではなく、観測にとどめる。"
        : input.sourceObservatory === "employment"
          ? "一つの仏教思想的な読み方として、このレンズでは欲求と制度的誘引・評価・保障の接続が見えてくる。career advice や欲の断罪ではなく、観測にとどめる。"
          : input.sourceObservatory === "scam"
            ? "一つの仏教思想的な読み方として、このレンズでは欲求と欺瞞・情報非対称・時間圧力の接続が見えてくる。被害者の欲を原因とせず、観測にとどめる。"
            : input.sourceObservatory === "intimacy"
              ? "一つの仏教思想的な読み方として、このレンズでは関係の中の欲と選択環境の接続が見えてくる。恋愛指南や断罪ではなく、観測にとどめる。"
              : "一つの仏教思想的な読み方として、このレンズでは固定的に見えていたものが条件の組み合わせとして見えてくる。Parallel Life の探索を否定せず、なぜ今その問いが残るのかを観測する。";
  }

  return result;
}
