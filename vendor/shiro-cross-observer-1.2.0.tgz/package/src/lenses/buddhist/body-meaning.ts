/**
 * Body Meaning–specific Buddhist Lens copy and safeguards.
 * Observation only — not medical advice, diagnosis, aging moralizing, or illness blame.
 */

export const BODY_MEANING_LENS_COPY = {
  domainNote:
    "Body Meaning では、身体信号・必要・意味づけ・欲を混同せず観測する。欲がすべて社会的意味から生じるわけではない。",
  embodiedSignal:
    "Desire as Embodied Signal: Body Signal → Need → Interpretation → Desire の変換可能性を見る。Need = Desire とはしない。",
  agingCaseNote:
    "Aging は可逆的疲労とは異なる時間的・一部不可逆な身体変化のケース。Body Change が存在しても Desire は必ず生じない（Desire optional）。",
  illnessCaseNote:
    "Illness / Chronic Pain は持続・反復する身体破綻のケース。疲労とも老いとも同一モデルに押し込めない。",
  branchingModel:
    "Branching candidate: Body State → Need（adaptation/support）and/or Body State → Interpretation → Social Meaning / Fear / Identity → Desire。",
  bodyChangeNotDesire:
    "白髪・筋力低下・疲れやすさなどの変化を、自動的に『若くなりたい』へ翻訳しない。",
  bodyDisruptionNotDesire:
    "痛み・しびれ・可動制限などの破綻を、自動的に『元通りになりたい』Desire へ翻訳しない。Desire は optional。",
  painReliefNotCraving:
    "『痛みを減らしたい』は身体的 Need として成立しうる。自動的に渇愛（Craving）とラベルしない。",
  completeRestorationBoundary:
    "『完全に元通りでなければならない』には Memory / Identity / Fear / Social Meaning が加わりうる。Need と Desire を分離して観測する。",
  embodiedNeedVsSocialDesire:
    "Embodied Need（痛みなく歩きたい）と Socially Translated Desire（老けて見える→若く見られたい）を区別して観測する。二分法にはしない。",
  socialTranslationAging:
    "Social Translation of Aging: Body Change → Age Label → Social Meaning → Expected Role → Desire / Avoidance の可能性。決定論にしない。",
  socialTranslationIllness:
    "Social Translation of Illness: Illness → social label → role expectation → desire/avoidance の可能性（source にある場合）。決定論にしない。",
  pastPresentBody:
    "Past Body / Present Body の差が Meaning → Desire へ接続しうる。Parallel Life の counterfactual と近接するが同一ではない。",
  pastPresentFutureBody:
    "Past / Present / Expected Future Body から return desire・fear・hope・uncertainty が生じうる。",
  desireFearBoundary:
    "『若くいたい』と『老いたくない』、あるいは『元気になりたい』と『悪化したくない』は Desire と Fear/Avoidance の境界として記録する。Fear Engine は作らない。",
  physicalVsMeaningSuffering:
    "Physical suffering（痛み・制限）と Meaning-related suffering（恐怖・比較・identity・不確実性）を可能なら分離する。",
  needNotCraving:
    "食事・休息・安全・睡眠・治療などの身体的必要性を、自動的に渇愛（Craving）とラベルしない。",
  cravingWhenConnected:
    "Need に社会的意味・恐怖・identity・control が接続した場合に、渇愛というレンズで読める可能性を見る。断定しない。",
  healthNotPathology:
    "健康でありたい・痛みから逃れたい・休みたいといった欲求を病理化しない。",
  illnessNotBlame:
    "病・不調・慢性症状のある人の欲を、道徳的欠陥や失敗として扱わない。",
  agingNotMoralize:
    "老いを『受け入れねばならない』という説教にしない。身体を固定状態として期待していないか、という観測にとどめる。",
  noMoralAging:
    "アンチエイジング＝浅い／若さを望む＝未熟／『逆らうな』系の説教、といった道徳階層を作らない。",
  noRecoveryMoralism:
    "回復道徳（前向き強制・受容説教・諦め強制・『うまく付き合う』説教）の階層を作らない。",
  antiAgingMarketNote:
    "Aging → Desire/Fear → Products/Services → Market を観測しうる。anti-aging industry = exploitation とはしない。Manipulation / Incentivization / Formation と区別する。",
  medicalBoundary:
    "This model does not replace medical or clinical analysis.",
  gerontologicalBoundary:
    "This lens does not replace medical, clinical, or gerontological analysis.",
  illnessMedicalBoundary:
    "This lens does not replace medical, clinical, rehabilitation, pain-management, or other professional analysis.",
  antiReductionism:
    "『欲は身体だけ／社会だけから生じる』『身体症状は心理の表現にすぎない』といった一変数還元をしない。",
  dependentConditions:
    "身体経験も biology / environment / work / sleep / food / medicine / culture / age / social meaning など複数条件から生じうる。",
  compassionNote:
    "慢性疾患・障害・見えない症状・老い・痛み・疲労・ケア負担など、見落とされやすい身体経験への配慮を保つ。固定的弱者化は避ける。",
  illnessCompassionNote:
    "invisible symptoms・変動する症状・診断の不確実性・仕事の調整・経済負担・信じてもらえなさなどが見落とされていないか。固定的被害者像は作らない。",
} as const;

export const BODY_MEANING_FORBIDDEN_PHRASES: string[] = [
  "病気は執着の結果",
  "欲を減らせば治る",
  "欲を減らせば痛みが減る",
  "症状の原因は欲",
  "精神が身体を作っている",
  "心の持ち方で治る",
  "執着が病気を悪化させる",
  "老いを受け入れろ",
  "老いに逆らうな",
  "自然に老いるのが正しい",
  "アンチエイジングは浅い",
  "若さを望むのは未熟",
  "老いを受け入れない人は執着している",
  "受け入れれば楽になる",
  "執着を減らせば健康になる",
  "病気を受け入れろ",
  "変化を受容すればよい",
  "元に戻りたいのは間違い",
  "回復に執着するな",
  "前向きであるべき",
  "痛みとうまく付き合えばよい",
  "疲れたのは弱いから",
  "健康でないのは自己管理不足",
  "病人の欲が問題",
  "休息はサボり",
  "痛みは心の問題だけ",
  "身体は社会的構築物にすぎない",
  "病気は意味づけで作られる",
  "老いへの抵抗は渇愛",
  "治りたいのは渇愛",
];

export const BODY_MEANING_REFLECTION_QUESTIONS: string[] = [
  "いま感じているのは身体信号そのものか。それとも、その信号に付けられた意味や評価か。",
  "休みたい・治したい・安心したいという必要を、渇愛として扱っていないだろうか。",
  "身体を固定的な『若い自分』『強い自分』『健康な自分』として期待していないか。",
  "この疲労や不眠は、克服すべき障害としてだけ読まれていないか。従うべき判断として読める余地はないか。",
  "失いたくない／戻りたいとき、望んでいるのは身体そのものだろうか。それとも、その身体に結びつけている安心や役割だろうか。",
  "なくしたいのは痛みそのものだろうか。それとも、痛みによって失われる説明・役割・安心への不安だろうか。",
  "休みたい身体と、働き続けたい自分の間で、どちらの声が「自分の意思」として扱われているだろうか。",
];

export function isAgingBodyMeaningInput(text: string, context?: string): boolean {
  const hay = `${text}\n${context ?? ""}`.toLowerCase();
  return (
    hay.includes("body meaning case: aging") ||
    (/aging|老い|老後|認知症|加齢|frailty|anti-aging|gerontolog/.test(hay) &&
      !hay.includes("body meaning case: illness") &&
      !hay.includes("body meaning case: productive-body"))
  );
}

export function isIllnessBodyMeaningInput(
  text: string,
  context?: string,
): boolean {
  const hay = `${text}\n${context ?? ""}`.toLowerCase();
  return (
    hay.includes("body meaning case: illness") ||
    hay.includes("illness / chronic pain") ||
    hay.includes("chronic pain") ||
    hay.includes("central sensitization") ||
    hay.includes("慢性疼痛") ||
    hay.includes("中枢性感作") ||
    (hay.includes("illness-chronic-pain") &&
      !hay.includes("body meaning case: aging"))
  );
}

export function pickBodyMeaningReflectionQuestion(
  primaryConceptId: string,
  text: string,
): string {
  const hay = text.toLowerCase();
  if (
    isIllnessBodyMeaningInput(hay) ||
    /慢性疼痛|中枢性感作|central sensitization|異常なしと言わ/.test(hay)
  ) {
    return BODY_MEANING_REFLECTION_QUESTIONS[5]!;
  }
  if (
    isAgingBodyMeaningInput(hay) ||
    /老い|老後|認知症|aging|失いたく|戻りたい/.test(hay)
  ) {
    return BODY_MEANING_REFLECTION_QUESTIONS[4]!;
  }
  if (
    /productive-body|働き続け|疲労|疲れ|不眠|眠|sleep|fatigue|起こされ|眠らされ/.test(
      hay,
    ) ||
    (primaryConceptId === "b02-dukkha" &&
      !isIllnessBodyMeaningInput(hay) &&
      !isAgingBodyMeaningInput(hay))
  ) {
    return BODY_MEANING_REFLECTION_QUESTIONS[6]!;
  }
  if (
    /必要|need|休息|治療|安全|hunger|空腹/.test(hay) ||
    primaryConceptId === "b05-craving"
  ) {
    return BODY_MEANING_REFLECTION_QUESTIONS[1]!;
  }
  if (
    /若い|aging|健康な自分|強い自分|identity|無我/.test(hay) ||
    primaryConceptId === "b03-non-self" ||
    primaryConceptId === "b01-impermanence"
  ) {
    return BODY_MEANING_REFLECTION_QUESTIONS[2]!;
  }
  return BODY_MEANING_REFLECTION_QUESTIONS[0]!;
}

export function containsBodyMeaningForbidden(text: string): boolean {
  return BODY_MEANING_FORBIDDEN_PHRASES.some((p) => text.includes(p));
}
