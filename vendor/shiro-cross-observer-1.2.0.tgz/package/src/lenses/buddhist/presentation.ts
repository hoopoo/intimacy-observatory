import type { LensInput, RelatedPattern } from "../../types/lens";
import { getBuddhistConceptById } from "./concepts";
import { DESIRE_MOTIF_COPY } from "./desire-motif";
import {
  BODY_MEANING_LENS_COPY,
  isAgingBodyMeaningInput,
  isIllnessBodyMeaningInput,
} from "./body-meaning";
import { EMPLOYMENT_LENS_COPY } from "./employment";
import { EDUCATION_LENS_COPY } from "./education";
import { SCAM_LENS_COPY } from "./scam";
import { INTIMACY_LENS_COPY } from "./intimacy";
import { PARALLEL_LIFE_LENS_COPY } from "./parallel-life";
import { COMPOSITE_EVIL_LENS_BRIDGE } from "./related/composite-evil";
import { ENTANGLED_SOCIETY_RELATED_PATTERN } from "./related/entangled-society";
import { COMPOSITE_EVIL_RELATED_PATTERN } from "./related/composite-evil";
import { ROMANCE_PROTOCOL_COLLAPSE_RELATED_PATTERN } from "./related/romance-protocol-collapse";
import { INTENTIONAL_HARM_RELATED_PATTERN } from "./related/intentional-harm";
import { STRUCTURAL_INCENTIVIZATION_RELATED_PATTERN } from "./related/structural-incentivization";
import { INSTITUTIONAL_DESIRE_FORMATION_RELATED_PATTERN } from "./related/institutional-desire-formation";
import { EMBODIED_DESIRE_SIGNAL_RELATED_PATTERN } from "./related/embodied-desire-signal";
import { AGING_BODY_CHANGE_RELATED_PATTERN } from "./related/aging-body-change";
import { ILLNESS_CHRONIC_PAIN_RELATED_PATTERN } from "./related/illness-chronic-pain";

export const MAX_VISIBLE_ITEMS = 5;
export const MAX_RELATED_PATTERNS = 3;
export const MAX_DISPLAY_SECONDARIES = 4;
export const OBSERVATION_EXCERPT_CHARS = 180;

export function excerptObservationText(
  text: string,
  maxChars = OBSERVATION_EXCERPT_CHARS,
): string {
  const cleaned = text.replace(/\s+/g, " ").trim();
  if (!cleaned) return "";
  if (cleaned.length <= maxChars) return cleaned;
  const sliced = cleaned.slice(0, maxChars);
  const cut = sliced.replace(/\s+\S*$/, "");
  return `${cut || sliced}…`;
}

function hay(input: LensInput): string {
  return `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`;
}

export function buildCompactInterpretation(
  input: LensInput,
  primaryId: string,
  desires: string[],
): string {
  const primary = getBuddhistConceptById(primaryId);
  const name = primary?.nameJa ?? primaryId;
  const desireLine =
    desires.length > 0
      ? `欲の痕跡: ${desires.slice(0, 3).join(" / ")}。`
      : "";

  const domain = domainInterpretation(input, name);
  const parts = [
    `一つの仏教思想的な読み方として、主に${name}から見る。`,
    domain,
    desireLine,
    "答えを与えるのではなく、見え方が変わることを目的とする。",
  ];
  return parts.filter(Boolean).join(" ");
}

function domainInterpretation(input: LensInput, primaryName: string): string {
  const h = hay(input);
  const obs = input.sourceObservatory;

  if (obs === "entangled-society") {
    if (/AI|生産性|生成|確認する仕事|検証/.test(h)) {
      return `${primaryName}として、生産性向上を一つの技術効果ではなく、利益・検証負荷・再訓練・評価が連鎖する現象として見る。欲望は複数条件の一つであり、単独原因ではない。`;
    }
    return `${primaryName}として、接続・移動・偏在を一つの原因ではなく、制度・技術・欲求が絡む連鎖として見る。Entangled Society の構造分析を置き換えない。`;
  }

  if (obs === "clean-society") {
    return `${primaryName}として、一人の悪意ではなく、募集・金・強制・匿名インフラ・制度の隙間が接続して悪い結果が立ち上がる可能性を見る。${COMPOSITE_EVIL_LENS_BRIDGE.observation}`;
  }

  if (obs === "parallel-life") {
    return `${PARALLEL_LIFE_LENS_COPY.coexistence} ${primaryName}として、「なぜ今もその未選択人生を知りたいのか」を読む。${PARALLEL_LIFE_LENS_COPY.pastDesireNote}`;
  }

  if (obs === "intimacy") {
    return `${primaryName}として、選択肢の増加と「もっと良い人がいるかもしれない」が、探索を終わらせにくくしている可能性を見る。${INTIMACY_LENS_COPY.desireNotEvil} ${INTIMACY_LENS_COPY.desirePlusTechnology}`;
  }

  if (obs === "scam") {
    return `${primaryName}として、信頼したい・愛されたいという性質が、他者から観測・刺激される接点になりうることを見る。${SCAM_LENS_COPY.desireNotFault}`;
  }

  if (obs === "employment") {
    return `${primaryName}として、安定・評価・報酬の制度が、個人の欲を方向づける可能性を見る。${EMPLOYMENT_LENS_COPY.desireNotPathology}`;
  }

  if (obs === "education") {
    return `${primaryName}として、良い未来の形が成績・credential・期待へ翻訳される過程を見る。${EDUCATION_LENS_COPY.teachableInterface} ${EDUCATION_LENS_COPY.parentDesireSafeguard}`;
  }

  if (obs === "body-meaning") {
    if (isIllnessBodyMeaningInput(input.text, input.context)) {
      return `${primaryName}として、持続する痛みと、説明・役割・安心の喪失を分けて見る。痛みを減らしたいことは身体的必要として成立しうる。`;
    }
    if (isAgingBodyMeaningInput(input.text, input.context)) {
      return `${primaryName}として、身体変化そのものと、失う恐怖・予防責任・商品化を分けて見る。Desire は必ず生じない。`;
    }
    return `${primaryName}として、休息を求める身体と、働き続けたい意味づけの衝突を見る。${BODY_MEANING_LENS_COPY.needNotCraving}`;
  }

  return `${primaryName}の観点から、固定して見えていたものを条件の組み合わせとして見直す。`;
}

export function buildCompactVisible(
  input: LensInput,
  desires: string[],
): string[] {
  const obs = input.sourceObservatory;
  const h = hay(input);
  let items: string[] = [];

  if (obs === "entangled-society") {
    items = /AI|生産性|生成|検証|再訓練/.test(h)
      ? [
          "生成や処理の速度が上がる",
          "検証・責任の負荷が別の場所へ移る",
          "再訓練や追従の要求",
          "資格・評価の競争",
          "配分や地域の差",
        ]
      : [
          "制度・技術・移動の接続",
          "雇用や負担の地理的なずれ",
          "効率・成長への欲求",
          "単独原因では説明しきれない連鎖",
          "誰が利益を取り、誰が検証負荷を負うか",
        ];
  } else if (obs === "clean-society") {
    items = [
      COMPOSITE_EVIL_LENS_BRIDGE.observation,
      "募集する人と、それを可能にする経路",
      "金の流れとリスクの下流化",
      "強制・弱みを使う条件",
      "一人を取り除いても役割が埋まりうる制度の隙間",
    ];
  } else if (obs === "parallel-life") {
    items = [
      PARALLEL_LIFE_LENS_COPY.coreQuestion,
      "過去の Desire と、今知りたい Desire は別",
      "未選択人生を事実として断定しない",
      "年収や役職の答えでも、問いは終わり切らないかもしれない",
    ];
  } else if (obs === "intimacy") {
    items = [
      "選択肢が増える",
      "探索が終わりにくい",
      "信頼のコスト",
      "最適化の疲労",
      "同時に矛盾する欲",
    ];
  } else if (obs === "scam") {
    items = [
      "信頼したい / 愛されたい / 安心したい",
      "攻撃者側からの観測と刺激",
      "意図的な害と、それを可能にする条件",
      "被害のあとに残る羞恥",
      SCAM_LENS_COPY.manipulableInterface,
    ];
  } else if (obs === "employment") {
    items = [
      "安定・保障",
      "報酬",
      "評価",
      "雇用への依存",
      "交渉力の非対称",
    ];
  } else if (obs === "education") {
    items = [
      "点数・ラベル",
      "credential",
      "期待される未来",
      "identity への翻訳",
      "学ぶことと評価されることのずれ",
    ];
  } else if (obs === "body-meaning") {
    if (isIllnessBodyMeaningInput(input.text, input.context)) {
      items = [
        "持続する痛み・制限（身体信号）",
        "診断の空白 / 異常なしと言われる経験",
        "信じてもらえなさ",
        "役割・説明の喪失",
        "痛み緩和の必要 ≠ 自動的な渇愛",
      ];
    } else if (isAgingBodyMeaningInput(input.text, input.context)) {
      items = [
        "時間に伴う身体変化",
        "失うことへの不安",
        "予防責任への翻訳",
        "検査・市場・商品化",
        "戻りたい Desire は optional",
      ];
    } else {
      items = [
        "身体信号としての疲労・眠気",
        "休息という必要",
        "休むことが脱落として意味づけられる",
        "生産性維持の欲が Need と衝突する",
        "負荷が自己管理責任へ変換される",
      ];
    }
  } else if (desires.length > 0) {
    items = [`欲の痕跡: ${desires.slice(0, 3).join(" / ")}`];
  }

  return items.slice(0, MAX_VISIBLE_ITEMS);
}

export function buildGatedRelatedPatterns(input: LensInput): RelatedPattern[] {
  const obs = input.sourceObservatory;
  const text = hay(input).toLowerCase();
  const patterns: RelatedPattern[] = [];

  if (obs === "entangled-society") {
    patterns.push(ENTANGLED_SOCIETY_RELATED_PATTERN);
  } else if (obs === "clean-society") {
    patterns.push(COMPOSITE_EVIL_RELATED_PATTERN);
  } else if (obs === "intimacy") {
    patterns.push(ROMANCE_PROTOCOL_COLLAPSE_RELATED_PATTERN);
  } else if (obs === "scam") {
    patterns.push(INTENTIONAL_HARM_RELATED_PATTERN);
    if (
      /romance|親密|愛され|恋人|intimacy|マッチ/.test(text)
    ) {
      patterns.push(ROMANCE_PROTOCOL_COLLAPSE_RELATED_PATTERN);
    }
  } else if (obs === "employment") {
    patterns.push(STRUCTURAL_INCENTIVIZATION_RELATED_PATTERN);
    if (/合成悪|composite.?evil|誰も全体を意図/.test(text)) {
      patterns.push(COMPOSITE_EVIL_RELATED_PATTERN);
    }
  } else if (obs === "education") {
    patterns.push(INSTITUTIONAL_DESIRE_FORMATION_RELATED_PATTERN);
  } else if (obs === "body-meaning") {
    if (isIllnessBodyMeaningInput(input.text, input.context)) {
      patterns.push(ILLNESS_CHRONIC_PAIN_RELATED_PATTERN);
      patterns.push(EMBODIED_DESIRE_SIGNAL_RELATED_PATTERN);
    } else if (isAgingBodyMeaningInput(input.text, input.context)) {
      patterns.push(AGING_BODY_CHANGE_RELATED_PATTERN);
      patterns.push(EMBODIED_DESIRE_SIGNAL_RELATED_PATTERN);
    } else {
      patterns.push(EMBODIED_DESIRE_SIGNAL_RELATED_PATTERN);
    }
  } else if (
    text.includes("entangl") ||
    text.includes("絡み") ||
    text.includes("因果")
  ) {
    patterns.push(ENTANGLED_SOCIETY_RELATED_PATTERN);
  }

  return patterns.slice(0, MAX_RELATED_PATTERNS);
}

export function compactDesireNote(desires: string[]): string {
  if (desires.length === 0) {
    return DESIRE_MOTIF_COPY.nonEvilNote;
  }
  return `Desire motif: ${desires.slice(0, 3).join(" / ")}`;
}

export const ENTANGLED_REFLECTION_QUESTIONS = [
  "AIで減った仕事と、AIによって新たに増えた「確認する仕事」は、同じ人に配分されているだろうか。",
  "生産性を上げたいという欲求が満たされたとき、その代わりに誰の仕事や負担が増えているだろうか。",
  "効率や協力と呼ばれているものの中で、誰のコストが視界からずれているだろうか。",
] as const;

export function pickEntangledReflectionQuestion(text: string): string {
  if (/AI|生産性|生成|検証|再訓練/.test(text)) {
    return ENTANGLED_REFLECTION_QUESTIONS[0];
  }
  if (/効率|成長|貿易|雇用|global/.test(text)) {
    return ENTANGLED_REFLECTION_QUESTIONS[2];
  }
  return ENTANGLED_REFLECTION_QUESTIONS[1];
}

export const CLEAN_SOCIETY_REFLECTION_QUESTIONS = [
  "一人の悪意だけを取り除いても、同じ役割を別の誰かが埋める条件が残っていないだろうか。",
  "正常な効率や利益の追求が、どこで強制や危害の条件と接続しているだろうか。",
] as const;

export function pickCleanSocietyReflectionQuestion(text: string): string {
  if (/強制|犯罪|供給|recruit|監禁|トクリュウ/.test(text)) {
    return CLEAN_SOCIETY_REFLECTION_QUESTIONS[0];
  }
  return CLEAN_SOCIETY_REFLECTION_QUESTIONS[1];
}
