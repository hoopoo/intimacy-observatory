# Cross-Observer

**Cross-Observatory Lens Architecture v1.1.0** (frozen) for SHIRO & Co.

> Observatories determine WHAT we observe.  
> Lenses determine HOW we see it.

このリポジトリは、分散した各 Observatory から再利用できる **横断 Lens Layer** のソース・オブ・トゥルースです。仏教専用ページを増やすことが目的ではありません。

## Cross-Domain Proof (v1.1.0)

Cross-Observer v1.1.0 has been validated across:

- **institutional / social observations** — Clean Society (Body Meaning)
- **structural / entangled observations** — Entangled Society
- **personal / counterfactual life observations** — Parallel Life

同一 SoT:

- `LensDefinition` / Registry / B01–B08 / `applyLens` / `LensResult` / safeguards

Observatory 固有は **Adapter のみ**。

詳細: [docs/architecture-v1.1.md](./docs/architecture-v1.1.md)

## Desire Model v0.1（概念仕様）

Cross-domain structural concept model（Engine / scoring なし）。

> 欲は、どこから来て、どう形を変えるのか。

Buddhist Lens とは分離する。Desire Model は Lens でも Protocol でもなく、複数 Observatory で観測された「欲」の構造を固定する概念層。

仕様: [docs/desire-model-v0.1.md](./docs/desire-model-v0.1.md)

## Architecture

```
Source Observatory
  → Observation
  → Lens Adapter
  → Common LensInput
  → Lens Registry
  → Selected Lens
  → LensResult (derived interpretation)
  → Lens Viewer
```

LensResult は元 Observation を書き換えません。

### Layer separation

| Layer | Role |
|-------|------|
| Protocol | どう思考を進めるか（Kosuke Protocol など） |
| **Lens** | どの視点から見るか（本パッケージ） |
| Observatory | 何を観測するか |

Kosuke Protocol は Lens として登録しません。

## Buddhist Lens v1

- id: `buddhist`
- Concepts: B01–B08（無常 / 苦 / 無我 / 縁起 / 渇愛 / 執着 / 空 / 慈悲）
- Desire は cross-observatory motif（Desire Engine ではない）
- 説教・人生訓・占い・精神的権威として実装しない
- Desire Model v0.1（概念仕様）とは分離：Lens は Desire を読む手段の一つ

## Distribution (deploy-safe)

**Vendored SoT tarball**

```bash
npm run pack:consumers
```

生成: `shiro-cross-observer-1.2.0.tgz`  
同期先: Body Meaning · Entangled · kosuke · Intimacy · Scam · Education–Employment Gap

```json
"@shiro/cross-observer": "file:./vendor/shiro-cross-observer-1.2.0.tgz"
```
Consumers must not copy Lens logic. Re-sync from this SoT when upgrading.

## Quick start

```bash
npm install
npm test
npm run typecheck
npm run lint
npm run pack:consumers
```

## Production integrations (v1.1.0 + patches)

- Clean Society — Composite Evil related pattern
- Entangled Society — 縁起 related / not-identical
- Parallel Life — self / counterfactual coexistence safeguards
- Intimacy — Romance Protocol Collapse as Related Pattern; desire + choice architecture
- Scam Folklore — Intentional Harm + Enabling Conditions; Desire ≠ Fault (v1.1.1)
- Employment (Education–Employment Gap) — Structural Incentivization; Desire as Incentivizable Interface (v1.1.2)
- Education (same host) — Institutional Desire Formation; Desire as Teachable Interface (v1.1.3)
- Body Meaning (Productive Body) — Embodied Desire Signal; Desire as Embodied Signal boundary validation (v1.1.4)
- Body Meaning (Aging / Dementia Anxiety) — Aging Body Change; branching + Social Translation validation (v1.1.5)
- Body Meaning (Illness / Chronic Pain) — Persistent Disruption; triad + Desire/Fear boundary; v0.2 READY TO SPEC (v1.1.6)
- Production UX presenter — compact Lens Result + observation-specific reflection (v1.2.0)

## Future

Roadmap lenses（未実装）: stoicism, taoism, christian-thought, confucianism, shinto, existentialism  
Compare Lenses UI · Desire Engine · LLM generation は freeze 対象外。  
Desire Model v0.1 は概念仕様のみ（[docs/desire-model-v0.1.md](./docs/desire-model-v0.1.md)）。Engine 化は **NOT YET**。
