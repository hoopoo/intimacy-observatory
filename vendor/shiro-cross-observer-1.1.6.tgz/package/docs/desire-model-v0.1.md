# Desire Model v0.1

**A Cross-Domain Model of How Wanting Is Formed, Directed, and Transformed**

日本語副題：**欲は、どこから来て、どう形を変えるのか。**

| Field | Value |
|-------|--------|
| Status | CONCEPT SPEC |
| Version | 0.1 |
| Kind | Cross-domain structural concept model |
| Engine | **Not implemented** |
| Scoring / detection / LLM | **Out of scope** |
| Evidence | Observational (7 production domains through Cross-Observer v1.1.3) |

---

## 1. Definition

**Desire is not merely an internal wish.  
It can be formed, translated, intensified, redirected, conflicted, incentivized, manipulated, institutionalized, and transformed into meaning.**

**欲は、単なる個人内部の願望ではない。  
欲は形成され、翻訳され、強められ、方向づけられ、衝突し、報酬され、操作され、制度化され、結果や意味へ変換されうる。**

このモデルは：

- SHIRO & Co. の **cross-domain conceptual model**
- Lens でも Protocol でも Observatories でもない
- **観測に基づく構造モデル（observational model）**

である。

「社会がすべての欲を作る」とは定義しない。  
「7 domain で見えたから普遍法則である」とも定義しない。

---

## 2. Why this model exists

Cross-Observer の Buddhist Lens は、複数 Observatory で **Desire** を繰り返し照らしてきた。しかし Desire は仏教心理学そのものではない。

v0.1 が固定するのは：

1. 欲が **個人内部だけ** の話ではないこと  
2. 欲が **変換モード** をもつこと  
3. 欲が **interface** として他者と制度に接続すること  
4. 欲を **原因の万能変数** にしないこと  
5. Lens / Protocol / Observatory と **概念層を分離** すること  

Desire Model は Observation を置き換えない。分析レイヤーの一つである。

### Positioning

```
Desire Model  ≠  Buddhist Model
Desire Model  ≠  Lens
Desire Model  ≠  Protocol
Desire Model  ≠  Entangled Society
Desire Model  ≠  Composite Evil
Desire Model  ≠  Intentional Harm
```

利用順は固定しない。

- Observation → Desire Model → Lens → Interpretation  
- Observation → Buddhist Lens  

どちらも可。Desire Model は必須パイプラインではない。

---

## 3. Evidence base

v0.1 は、Cross-Observer 本番接続で既に観測された 7 domain を evidence とする。

| Domain | Observed desire shape | Related keyword (Cross-Observer) |
|--------|----------------------|----------------------------------|
| Clean Society | Institutional Desire | Composite Evil (related) |
| Entangled Society | Desire among Conditions | Dependent Origination related / not-identical |
| Parallel Life | Personal / Counterfactual Desire | coexistence safeguards |
| Intimacy | Relational / Conflicting Desire | Romance Protocol Collapse |
| Scam | Manipulated Desire | Intentional Harm + Enabling Conditions |
| Employment | Incentivized Desire | Structural Incentivization |
| Education | Formed / Taught Desire | Institutional Desire Formation |

これらは **証拠の束** であって、普遍法則の証明ではない。

---

## 4. Core loop

最初の概念ループ（完全因果ではない）：

```
Need / Lack / Aspiration
  → Interpretation
  → Desire
  → Decision
  → Behavior
  → Entanglement
  → Consequence
  → Meaning
  → Memory / Identity
  → New Desire
```

各ノードは：

- **skip** 可能  
- **repeat** 可能  
- **feedback** 可能  
- **multiple actors** 可能  

一本道モデルではない。

### Graph / cyclic shape（概念）

```
Actor
  → Need / Aspiration
  → Desire
  ↔ Institution
  ↔ Other Actor
  ↔ Technology / Culture / Body / Chance
  → Decision
  → Consequence
  → Meaning
  ↺ Desire
```

将来 network visualization 可能な形を想定する。v0.1 では可視化 Engine を作らない。

---

## 5. External influence layer

Desire には外部条件が作用しうる。例：

Culture · Institution · Technology · Family · Peer · Market · Platform · Employer · Education · Media · History · Body · Chance

これらは Desire の **sole cause ではない**。  
Desire の形成・方向づけ・強化・衝突に関わる **conditions** として扱う。

---

## 6. Transformation modes

v0.1 で最低限区別するモード：

### A. Formation

何を望ましいと思うかが **形成** される。

- 例：Education — 良い学校 → 良い就職 → 安定  
- Keyword: **Institutional Desire Formation**  
- Formation ≠ Manipulation  
- Formation ≠ mere Incentivization  

### B. Incentivization

既にある欲が、制度的 signal / reward によって **方向づけ** られる。

- 例：Employment — 評価 / bonus / promotion  
- Keyword: **Structural Incentivization**  
- Incentivization ≠ Manipulation  

### C. Manipulation

他 Actor が欲を観測・刺激し、**意図的に利用** する。

- 例：Scam  
- Intentional manipulation を含む  
- Manipulation ≠ mere Influence  

### D. Conflict

複数の欲が同時に存在し、互いに衝突する。

- 例：Intimacy — 愛されたい / 自由でいたい / 傷つきたくない / より良い可能性を探したい  

### E. Counterfactualization

過去の選択や結果から、**未選択可能性** への欲が生まれる。

- 例：Parallel Life — 「別の人生を知りたい」  

### F. Institutionalization

多数の Actor の欲が集積し、制度・市場・慣行へ変わる。

- 例：Clean Society  

### G. Entanglement

欲が単独ではなく、policy / technology / economy / institution / norm / history / other actors と絡み合って結果を生む。

- 例：Entangled Society  

同一現象に複数モードが重なりうる。排他分類を強制しない。

---

## 7. Interface taxonomy

Desire には複数の interface 性がある（v0.1 taxonomy）：

| Interface | Sense | Primary evidence |
|-----------|--------|------------------|
| Personal Interface | decision への接点 | Parallel Life, Employment |
| Relational Interface | 他者との関係で欲が衝突 | Intimacy |
| Manipulable Interface | 欲が意図的に利用されうる | Scam |
| Incentivizable Interface | reward / signal で方向づけされうる | Employment |
| Teachable Interface | 望ましいものが教えられ / 形成されうる | Education |
| Institutional Interface | 制度・市場へ集積しうる | Clean Society |
| Entangled Interface | 多条件・多 Actor と絡み合う | Entangled Society |

Interface は「脆弱性スコア」ではない。構造的接点の名前である。

---

## 8. Power / asymmetry

複数 Actor に欲があることと、Actor の power が対等であることは **別**。

非対称の例：

- authority  
- information  
- money  
- platform control  
- dependency  
- employment power  
- parent authority  

Desire Model は、欲の存在と権力差を混同しない。  
特に Scam / Employment / Education / Clean Society で、この区別が必須。

---

## 9. Time / memory / identity

### Time

Desire は時間で変わる。概念的に区別する：

- Past Desire  
- Present Desire  
- Expected Future Desire  

同一人物でも desired state は変化する。Impermanence（無常）との接続は可能だが、Desire Model 自体は仏教用語に依存しない。

### Memory

```
Past Desire
  → Decision
  → Life Path
  → Memory
  → Counterfactual
  → New Desire
```

過去の欲と現在の欲を区別できるようにする（Parallel Life で重要）。

### Identity

```
Desire → Evaluation → Label → Identity
```

例：「評価されたい」→ high performer →「私は高評価される人」。

ただし **Identity を欲だけで説明しない**。

### Meaning

結果そのものより、結果に与えられた **意味** が次の欲を生みうる。

- Promotion →「評価された」→「もっと上へ」  
- Failure →「自分は遅れている」→「追いつきたい」  

Meaning 層は Core Loop の重要な feedback である。

### Body（将来接続）

Desire を完全な認知モデルにしない。身体から生じる / 制約される欲もある：

fatigue · hunger · illness · aging · stress · sexual desire · pain · safety

v0.1 では Body Engine を作らない。Body Meaning との将来接続を留保する。

---

## 10. Social Translation of Desire

Education で観測された変換を概念ノート化する：

```
「幸せ」
  →「将来困らない」
  →「良い学校」
  →「良い就職」
  →「安定」
```

これを **Social Translation of Desire** と呼ぶ。

- 文化・制度・家族・市場を通じた **意味変換**  
- **Manipulation ではない**（意図的欺瞞と混同しない）  
- Formation / Institutionalization と隣接するが、同一概念ではない  

親の「子どもを幸せにしたい」が進路パッケージへ翻訳されることは、親断罪の根拠にならない。

---

## 11. Buddhist Lens relationship

| | Desire Model | Buddhist Lens |
|--|--------------|---------------|
| Kind | structural concept model | philosophical Lens |
| Role | 欲の変換・循環・接続を記述 | その変換を思想的に読む |
| Ownership | SHIRO & Co. cross-domain | Cross-Observer Lens Registry |

**The Desire Model describes structural transformations of desire.  
The Buddhist Lens offers one philosophical way to interpret those transformations.**

Buddhist concepts が照らしうる箇所（例）：

| Concept | May illuminate |
|---------|----------------|
| B05 Craving | Desire の強まり・方向 |
| B06 Attachment | 固定・維持・同一化 |
| B02 Dukkha | Consequence / Meaning の苦の読み |
| B04 Dependent Origination | Entanglement / multi-condition |
| B03 Non-self | Identity への還元拒否 |
| B01 Impermanence | Time / Past–Present–Future Desire |
| B08 Compassion | Desire ≠ Evil / ≠ Fault の倫理的配慮 |

Desire Model = Buddhist psychology **ではない**。

---

## 12. Entangled Society relationship

| | Desire Model | Entangled Society |
|--|--------------|-------------------|
| Focus | desire transformation / circulation / interaction | multi-actor / multi-condition social consequence |
| Desire role | 分析対象そのもの | 条件の一つ |

Desire ≠ sole explanatory variable。  
Desire Model と Entangled Society は近いが **同一ではない**。

---

## 13. Composite Evil relationship

Clean Society との接続。

複数 Actor の自然な欲（Employee / Customer / Manager / Investor / Platform など）が接続し、誰も全体を意図しない結果が生まれる場合がある。

Desire Model は Composite Evil を説明しきらない。  
**Related model** として扱う。

---

## 14. Intentional Harm relationship

Scam との接続。

```
Desire
  + Intentional Harm
  + Enabling Conditions
```

- Desire Model：人間の欲を観測する  
- Intentional Harm：他者が欺瞞・搾取意図をもつ  

被害者と加害者の欲を道徳的に同列化しない。  
被害者の「愛されたい」「安心したい」「損したくない」は **victim fault ではない**。

---

## 15. Seven-domain examples

各例は簡潔な observational sketch。普遍法則の主張ではない。

### Clean Society — Institutional Desire

| | |
|--|--|
| Desire | 安全・清潔・秩序・リスク回避・利益・利便 |
| Mode | Institutionalization (+ Entanglement) |
| Conditions | institution, market, platform, policy, norm |
| Consequence | 誰も全体を意図しない害の構成条件になりうる |
| Limitation | Desire alone ≠ Composite Evil explanation |

### Entangled Society — Desire among Conditions

| | |
|--|--|
| Desire | 成長・効率・接続・競争優位・安全保障など複数 |
| Mode | Entanglement |
| Conditions | policy, technology, economy, history, other actors |
| Consequence | 多条件の絡み合いとしての結果 |
| Limitation | Desire ≠ sole cause; not identical to 縁起 |

### Parallel Life — Personal / Counterfactual Desire

| | |
|--|--|
| Desire | 別の人生を知りたい / 未選択可能性への志向 |
| Mode | Counterfactualization |
| Conditions | memory, identity narrative, past decision |
| Consequence | 反実仮想の問い・物語の再編 |
| Limitation | Desire ≠ identity; past ≠ present desire |

### Intimacy — Relational / Conflicting Desire

| | |
|--|--|
| Desire | 愛されたい + 自由 + 傷つかない + より良い可能性 |
| Mode | Conflict |
| Conditions | peer, platform, culture, attachment history |
| Consequence | 関係プロトコルの緊張・崩壊可能性 |
| Limitation | Conflict ≠ pathology; Desire ≠ fault |

### Scam — Manipulated Desire

| | |
|--|--|
| Desire | 愛されたい / 安心したい / 損したくない（被害側） |
| Mode | Manipulation |
| Conditions | deception, urgency, asymmetry, enabling channels |
| Consequence | 搾取・損失・信頼破壊 |
| Limitation | Desire ≠ fault; Desire ≠ Intentional Harm |

### Employment — Incentivized Desire

| | |
|--|--|
| Desire | 認められたい / 安定したい / 昇進したい / 排除されたくない |
| Mode | Incentivization |
| Conditions | evaluation, bonus, promotion, employer power |
| Consequence | 行動の方向づけ・自己物語の強化 |
| Limitation | Incentivization ≠ Manipulation; Desire ≠ Decision |

### Education — Formed / Taught Desire

| | |
|--|--|
| Desire | 幸せ / 将来困らない / 良い学校 / 国際経験 / clean credential |
| Mode | Formation (+ Social Translation) |
| Conditions | family, school, market, class signal, employer expectation |
| Consequence | 進路パッケージとしての望ましさの固定 |
| Limitation | Formation ≠ Manipulation; parent desire ≠ pathology |

---

## 16. Safeguards（必須区別）

### Conceptual distinctions

| Must distinguish | Note |
|------------------|------|
| Formation ≠ Incentivization | 形成 vs 既存欲の方向づけ |
| Incentivization ≠ Manipulation | reward/signal vs intentional use |
| Manipulation ≠ Influence | 意図的利用 vs 単なる影響 |
| Desire ≠ Need | 解釈・方向づけを経た志向 |
| Desire ≠ Decision | 欲があっても決定しない |
| Desire ≠ Behavior | 欲があっても行為しない |
| Desire ≠ Evil | constructive / neutral desire がある |
| Desire ≠ Fault | 特に被害者の欲 |
| Desire ≠ Pathology | 親の心配・愛着・成長欲を病にしない |
| Desire ≠ Sole Cause | 一変数還元禁止 |
| Desire ≠ Identity | ラベル化は可能だが同一視しない |

### Desire ≠ Evil

欲には constructive / neutral なものもある：

愛されたい · 安心したい · 子どもを幸せにしたい · 知りたい · 創りたい · 成長したい · 助けたい

Desire Model は欲を道徳的欠陥として扱わない。見るのは：

**欲が何と接続され、どう変換され、どんな結果へ至るか。**

### Desire ≠ Fault

Scam 等で、被害者の欲を責めない。  
欺瞞・urgency・非対称性などとの **接続結果** を見る。

### Parent / care safeguards

Education 等で：

- 親の欲 = 子どもを苦しめるもの、としない  
- 「良い学校を望むのは欲深い」としない  

### Non-determinism（禁止句）

禁止：

- 「欲があれば必ず行動する」  
- 「制度が欲を作る」  
- 「評価制度が人をこうさせる」  
- 「教育が成功欲を植え付ける」  
- 「欲が社会問題の原因」  

代わりに：

condition · tendency · possibility · interaction · reinforcement

---

## 17. Limits / Anti-reductionism

Desire Model で現象のすべてを説明しない。

並行して残りうるもの：

biology · economics · law · technology · history · power · chance · culture

Desire Model は **one analytical layer**。

v0.1 の限界：

- Engine / scoring / detection なし  
- Body 層は接続候補（下記 Boundary Validation）— core loop への正式追加は **NOT YET**  
- Collective desire の形式化は未了  
- Formation と Manipulation の境界ケースは Research Question  
- 可視化・計測は未実装  

---

## 17b. Boundary Validation — Body Meaning (Cross-Observer v1.1.4)

**Observation:** `why-the-body-is-awakened-and-sedated`（Productive Body）  
**Motif:** Desire as Embodied Signal  
**Status:** observational support — **Desire Model core loop は未改訂**

### Observed distinction

| Layer | Example in observation |
|-------|------------------------|
| Body Signal | 疲労、眠気、動悸、頭痛、感情の鈍麻 |
| Need | 休息、睡眠、仕事量の見直し |
| Interpretation / Institution | 休む = 遅れる；無理を続ける = 責任感；自己管理 = 個人義務 |
| Desire | 評価を落としたくない；働き続けたい；疲労を感じなくしたい |
| Meaning | 生産性 / Clean Productivity vs Dirty Dependence |

### Core-loop implication

候補 A（Body Signal を Need の前に明示）は **SUPPORTED by this observation**。  
ただし illness / aging / pain の専用観測がまだ薄いため、v0.1 core の正式改訂は **NOT YET**。

External Conditions に Body を残す案（候補 B）も併用可。Body は condition であると同時に、signal→need の入口でもある。

### Embodied Desire taxonomy

Interface taxonomy への **ADD は保留（OBSERVE MORE）**。  
Related Pattern `embodied-desire-signal` と Desire Model 上の candidate として記録。

### Safeguards reaffirmed

- Need ≠ Craving  
- health desire ≠ pathology  
- no medicalization / no aging moralizing / no illness blame  
- anti-reductionism（身体だけ／社会だけ／心理だけに還元しない）

---

## 17c. Boundary Validation — Aging (Cross-Observer v1.1.5)

**Observation:** `dementia-business-and-aging-anxiety`  
**Motif:** Aging Body Change (distinct from reversible fatigue)  
**Status:** observational support — **Desire Model core loop は未改訂**

### Observed distinction

| Layer | Example in observation |
|-------|------------------------|
| Body Change | 老いる身体、認知への不安に結びつく変化、維持の不確実性 |
| Need | 説明、安心、支援・介護の見通し |
| Social Meaning | 老い = 失う恐怖；予防 = 責任ある備え |
| Desire / Avoidance | 失いたくない、備えたい、老いたくない／失いたくない |
| Market | 検査広告、予防サプリ、脳トレ、介護説明 |

### Branching implication

```
Body Change
  ├─→ Need (support / reassurance / care outlook)
  └─→ Interpretation → Social Meaning → Desire / Avoidance
```

Fatigue の一本道（Signal → Need → Desire）より、Aging では **分岐モデル**が適合しやすい。Desire は optional。

### Verdicts (aging pass)

- Desire as Embodied Signal: **EMERGING**（身体変化は入口だが、本観測では社会的意味・不安商品化が強い）  
- Branching Body Model: **SUPPORTED**  
- Social Translation of Body Change: **SUPPORTED**  
- Add Body Signal to Desire Model core: still **NOT YET**（Fatigue + Aging の2ケース。Illness / Chronic Pain を待って v0.2 候補）

### Desire / Fear research note

「備えたい／失いたくない」は Desire と Fear/Avoidance の境界。Fear Model は未作成。

---

## 17d. Boundary Validation — Illness / Chronic Pain (Cross-Observer v1.1.6)

**Observation:** `chronic-pain-central-sensitization-20260704-1py8`  
**Motif:** Persistent bodily disruption (distinct from reversible fatigue and aging time-change)  
**Status:** observational support — **Desire Model core loop は未改訂（v0.2 は proposal のみ）**

### Observed distinction

| Layer | Example in observation |
|-------|------------------------|
| Body Disruption | 慢性疼痛、画像で説明されない痛み、緊張が残る身体、生活への干渉 |
| Need | 痛みの緩和、説明、生活の再設計、予測可能性、医療・リハビリ接続 |
| Interpretation | 異常なしと言われる／損傷モデルから神経系・生活語彙への移動 |
| Meaning | 見えにくい痛みの正当性、治す＝症状除去と生活再設計の混線 |
| Desire / Avoidance | 元に戻りたい、仕事を続けたい、安心したい／悪化したくない |
| Fear boundary | 元気になりたい ≠ 悪化したくない ≠ 痛みを減らしたい（Need） |

### Branching implication

```
Body Disruption
  ├─→ Need (relief / support / adaptation / predictability)
  └─→ Interpretation → Meaning / Fear / Identity → Desire / Avoidance
```

Fatigue（比較的可逆）・Aging（時間変化）と並べると、Illness は **持続・反復する破綻**として分岐モデルを再確認する。Desire は optional。Pain relief ≠ Craving by default。

### Three-case comparison (Fatigue / Aging / Illness)

| Axis | Fatigue | Aging | Illness / Chronic Pain |
|------|---------|-------|------------------------|
| Body entry | Signal（比較的可逆） | Change（時間的） | Disruption（持続） |
| Branching | Signal→Need→Desire が立ちやすい | Branching **SUPPORTED** | Branching **SUPPORTED** |
| Social translation | 生産性／自己管理 | Age label / market anxiety **SUPPORTED** | Illness label / 異常なし空白（source 限定で **EMERGING**） |
| Embodied Signal | **SUPPORTED** | **EMERGING** | **SUPPORTED**（Need が強い） |
| Desire / Fear | research note | research note | **CLEARLY NEEDED** |

### Desire Model core recommendation (after triad)

候補 B（branch model）を Desire Model v0.2 **spec** の Body / Need Layer 骨格として提案可能：

```
Body State / Signal / Change / Disruption
  ├─→ Need
  └─→ Interpretation → Meaning / Fear / Identity → Desire / Avoidance
```

正式 v0.2 実装・Engine・Fear Engine は行わない。

### Verdicts (illness pass + triad)

- Branching Body Model: **SUPPORTED**  
- Add Body Signal / Body State to Desire Model core: **YES**（v0.2 spec で明示。現行 v0.1 core は未改訂）  
- Desire Model v0.2: **READY TO SPEC**（proposal only）  
- Embodied Desire taxonomy: **ADD**（候補として記録；正式 taxonomy 実装は次段）  
- Desire vs Fear separation: **CLEARLY NEEDED**（Fear Engine は作らない）

### Medical / recovery moralism safeguards

診断・予後・治療推奨・心身症帰属・「心の持ち方で治る」・回復道徳説教を禁止。観測のみ。

---

## 18. Minimal type draft（参考・未実装）

実装する場合の concept-level 草案。**現行パッケージには未投入。**

```ts
type DesireMode =
  | "formation"
  | "incentivization"
  | "manipulation"
  | "conflict"
  | "counterfactualization"
  | "institutionalization"
  | "entanglement";

type DesireActor = {
  id: string;
  role?: string;
};

type DesireRelation = {
  from: string;
  to: string;
  mode?: DesireMode;
  description?: string;
};
```

LensDefinition / LensResult / Registry / B01–B08 の schema 変更は行わない。

---

## 19. Future questions（Research）

- Desire は身体からどこまで生まれるか  
- Desire と Need をどう区別するか  
- Desire は collective になるか  
- Platform は Desire を予測できるか  
- Desire formation はいつ manipulation になるか  
- Desire は解消されるのか、変形するだけか  
- 欲と Meaning の循環はどう測れるか  
- Desire と Attention の関係  
- Desire と Trust の関係  
- Desire と Fear の関係  
- Social Translation と Formation の形式境界  
- Power asymmetry を Desire graph にどう載せるか  

---

## 20. Explicit non-goals (v0.1)

実装しない：

Desire Engine · scoring · ranking · user profiling · vulnerability score · desire detection · LLM classification · personalization · recommendation · automated intervention · visualization engine · Compare Lenses

**Ready for Engine: NOT YET**

Engine 化の前に、追加 domain 観測・境界ケース・Body 接続の問いを蓄積する。

---

## Document history

| Version | Note |
|---------|------|
| 0.1 | Initial concept spec from Cross-Observer v1.1.3 seven-domain evidence |
| 0.1+note | Body Meaning boundary validation (Productive Body / v1.1.4) — Embodied Signal supported; core-loop Body Signal formal add = NOT YET |
| 0.1+note | Aging boundary validation (Dementia Business / Aging Anxiety / v1.1.5) — Branching Body Model + Social Translation of Body Change supported; core add still NOT YET |
| 0.1+note | Illness / Chronic Pain boundary validation (Central Sensitization / v1.1.6) — triad complete; Branching SUPPORTED; Body State for v0.2 READY TO SPEC; Desire vs Fear CLEARLY NEEDED |
