/**
 * Integration guide for host Observatories.
 *
 * V1 UI is demonstrated in this package for:
 * - Parallel Life
 * - Clean Society
 * - Entangled Society
 *
 * Remaining Observatories can wire the same pattern via adapters:
 *
 *   import { adaptObservation, applyLens } from "@shiro/cross-observer";
 *   import { LensPanel } from "@shiro/cross-observer/ui";
 *
 *   const input = adaptObservation("scam", { id, title, text });
 *   // <LensPanel input={input} />
 *
 * Do not pass Observatory-internal models into Buddhist Lens directly.
 */

export const UI_INTEGRATED_OBSERVATORIES = [
  "parallel-life",
  "clean-society",
  "entangled-society",
] as const;

export const ADAPTER_READY_OBSERVATORIES = [
  "scam",
  "employment",
  "education",
  "intimacy",
  "market-signals",
  "body-meaning",
  "literature",
] as const;
