/**
 * Intimacy-specific Buddhist Lens copy and safeguards.
 * Observation only — not romantic advice or moral judgment.
 */

export const INTIMACY_LENS_COPY = {
  domainNote:
    "Intimacy では、同時に存在しときに矛盾する欲（愛されたい／自由でいたい／傷つきたくない／もっと良い相手がいるかもしれない）を観測する。",
  desireNotEvil:
    "「愛されたい」「よい関係を築きたい」という欲求を pathology や moral failure として扱わない。",
  desirePlusTechnology:
    "人間側の欲と、アルゴリズム的な choice architecture が相互に増幅する可能性を観測する。どちらが単独原因とは断定しない。",
  noDeterminism:
    "恋愛不能・アプリ悪玉・選択過多＝結婚不能といった単因断定はしない。複数条件の一つとして扱う。",
  notAdvice:
    "恋愛指南・結婚推奨・独身批判・欲望否定として機能しない。",
} as const;

export const INTIMACY_FORBIDDEN_PHRASES: string[] = [
  "理想の相手を求めるのは執着です",
  "欲を捨てれば恋愛はうまくいく",
  "結婚すべき",
  "独身でいるべき",
  "マッチングアプリをやめるべき",
  "あなたの執着が原因",
  "現代人は恋愛できなくなった",
  "アプリが恋愛を壊した",
  "選択肢が多いから結婚できない",
  "欲望が恋愛崩壊の原因",
];

export const INTIMACY_REFLECTION_QUESTIONS: string[] = [
  "探しているのは、より良い相手だろうか。それとも、選択を後悔しないという安心だろうか。",
  "『もっと良い人がいるかもしれない』という可能性は、選択肢を広げているだろうか。それとも、選択を終わらせにくくしているだろうか。",
  "知りたいのは相手そのものだろうか。それとも、選ばれる自分という確認だろうか。",
  "この関係の問いの中で、誰の経験や負担が視界から抜け落ちているだろうか。",
];

export function pickIntimacyReflectionQuestion(
  primaryConceptId: string,
  text: string,
): string {
  const hay = text.toLowerCase();
  if (
    /もっと良い|比較|マッチ|最適化|infinite|choice|optimization/.test(hay) ||
    primaryConceptId === "b05-craving"
  ) {
    return INTIMACY_REFLECTION_QUESTIONS[1]!;
  }
  if (primaryConceptId === "b06-attachment" || /理想|正解|perfect/.test(hay)) {
    return INTIMACY_REFLECTION_QUESTIONS[0]!;
  }
  if (primaryConceptId === "b08-compassion") {
    return INTIMACY_REFLECTION_QUESTIONS[3]!;
  }
  return INTIMACY_REFLECTION_QUESTIONS[2]!;
}

export function containsIntimacyForbidden(text: string): boolean {
  return INTIMACY_FORBIDDEN_PHRASES.some((p) => text.includes(p));
}
