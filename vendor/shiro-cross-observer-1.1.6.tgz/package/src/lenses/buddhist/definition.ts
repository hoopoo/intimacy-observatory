import type { LensDefinition } from "../../types/lens";
import { SUPPORTED_OBSERVATORY_IDS } from "../../types/observatory";
import { BUDDHIST_CONCEPTS } from "./concepts";
import { BUDDHIST_SAFEGUARDS } from "./safeguards";
import { BUDDHIST_LENS_COPY } from "./copy";

export const BUDDHIST_LENS_ID = "buddhist" as const;
export const BUDDHIST_LENS_VERSION = "1.0.0" as const;

export const BUDDHIST_LENS_DEFINITION: LensDefinition = {
  id: BUDDHIST_LENS_ID,
  slug: "buddhist",
  name: "Buddhist Lens",
  nameJa: "仏教レンズ",
  description: BUDDHIST_LENS_COPY.description,
  shortDescription: BUDDHIST_LENS_COPY.subheading,
  concepts: BUDDHIST_CONCEPTS,
  observationQuestions: BUDDHIST_CONCEPTS.map((c) => c.question),
  safeguards: BUDDHIST_SAFEGUARDS,
  supportedObservatories: [...SUPPORTED_OBSERVATORY_IDS],
  status: "active",
  version: BUDDHIST_LENS_VERSION,
};
