import type { LensConcept } from "../../types/lens";

/**
 * Buddhist Lens Concepts v1 (B01–B08).
 * Observational tools — not doctrinal authority.
 */
export const BUDDHIST_CONCEPTS: LensConcept[] = [
  {
    id: "b01-impermanence",
    code: "B01",
    name: "Impermanence",
    nameJa: "無常",
    question: "ここで、変わらないものとして扱われているものは何か。",
    focus: [
      "時間",
      "変化",
      "老い",
      "環境変化",
      "制度変化",
      "関係性の変化",
    ],
  },
  {
    id: "b02-dukkha",
    code: "B02",
    name: "Dukkha",
    nameJa: "苦",
    question:
      "ここには、どのような満たされなさ、摩擦、苦しさ、不足感が生じているか。",
    focus: [
      "痛み",
      "満たされない",
      "思い通りにならない",
      "摩擦",
      "不足感",
    ],
  },
  {
    id: "b03-non-self",
    code: "B03",
    name: "Non-self",
    nameJa: "無我",
    question:
      "ここで固定的な『私』『彼ら』『会社』『社会』として扱われているものは何か。",
    focus: ["自己像", "役割", "肩書", "固定されたアイデンティティ"],
  },
  {
    id: "b04-dependent-origination",
    code: "B04",
    name: "Dependent Origination",
    nameJa: "縁起",
    question:
      "この現象は、どのような条件と関係の組み合わせから生じているか。",
    focus: ["単独原因ではなく関係", "条件の組み合わせ", "相互依存"],
    notes:
      "Entangled Society と関連付けるが、同一視しない。縁起は思想的レンズ、Entangled Society は別の分析システムである。",
  },
  {
    id: "b05-craving",
    code: "B05",
    name: "Craving",
    nameJa: "渇愛",
    question:
      "何を得たい、取り戻したい、失いたくない、避けたいと思っているか。",
    focus: ["desire", "fear", "avoidance", "longing"],
  },
  {
    id: "b06-attachment",
    code: "B06",
    name: "Attachment",
    nameJa: "執着",
    question:
      "何を握り続けることで、この状態や苦しさが維持されているか。",
    focus: ["過去", "肩書", "評価", "人間関係", "成功像", "別の人生", "正解"],
  },
  {
    id: "b07-emptiness",
    code: "B07",
    name: "Emptiness",
    nameJa: "空",
    question: "固定的・固有の意味や価値があると思われているものは何か。",
    focus: ["カテゴリー", "制度", "社会的意味", "価値の固定化"],
    notes:
      "V1では宗派固有の高度な教義解説に踏み込まない。",
  },
  {
    id: "b08-compassion",
    code: "B08",
    name: "Compassion",
    nameJa: "慈悲",
    question: "誰の苦しみ、身体、経験がこの観測から抜け落ちているか。",
    focus: ["blind spot", "excluded actor", "弱い立場", "見えない被害"],
  },
];

export function getBuddhistConceptById(id: string): LensConcept | undefined {
  return BUDDHIST_CONCEPTS.find((c) => c.id === id);
}

export function getBuddhistConceptByCode(code: string): LensConcept | undefined {
  return BUDDHIST_CONCEPTS.find((c) => c.code === code);
}
