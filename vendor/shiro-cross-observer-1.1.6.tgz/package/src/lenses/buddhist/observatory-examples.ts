import type { SupportedObservatoryId } from "../../types/observatory";

export type ObservatoryLensExample = {
  observatoryId: SupportedObservatoryId;
  title: string;
  whatBecomesVisible: string[];
  note?: string;
};

/**
 * Example copy: what Buddhist Lens may make visible in each Observatory.
 * Lens itself remains shared; these are illustrative, not bindings.
 */
export const BUDDHIST_OBSERVATORY_EXAMPLES: ObservatoryLensExample[] = [
  {
    observatoryId: "parallel-life",
    title: "Parallel Life × Buddhist Lens",
    whatBecomesVisible: [
      "「別の人生を知りたい」という問いの背景にある安心・承認・後悔・失われた可能性への執着",
      "探索対象としての別人生と、その欲求を駆動する渇愛の区別",
    ],
    note:
      "Parallel Life は別の人生を探索する。Buddhist Lens はなぜその別の人生を知りたいのかを観測する。",
  },
  {
    observatoryId: "scam",
    title: "Scam × Buddhist Lens",
    whatBecomesVisible: [
      "儲けたい / 愛されたい / 助かりたい / 安心したい / 損したくない（Victim Desire ≠ Fault）",
      "欲が他Actorから観測・刺激・利用される接点になりうる構造（Desire as Manipulable Interface）",
    ],
    note: "Intentional Harm を Composite Evil と同一視しない。Security Layer とは分離する。",
  },
  {
    observatoryId: "employment",
    title: "Employment × Buddhist Lens",
    whatBecomesVisible: [
      "Employee: 評価されたい / 安定したい / 給与を上げたい（Desire ≠ Pathology）",
      "制度的シグナル（KPI・保障パッケージ・昇進）が欲を方向づける Structural Incentivization",
    ],
    note: "Intentional Manipulation（Scam）と区別する。KPI悪玉論にしない。",
  },
  {
    observatoryId: "education",
    title: "Education × Buddhist Lens",
    whatBecomesVisible: [
      "親の『幸せになってほしい』が制度の中で学校・成績・credentialへ翻訳される可能性",
      "Desire as Teachable Interface — 何を価値ある未来として欲するかの意味形成",
    ],
    note: "Manipulation / Incentivization と区別。親加害者化・洗脳モデルにしない。",
  },
  {
    observatoryId: "clean-society",
    title: "Clean Society × Buddhist Lens",
    whatBecomesVisible: [
      "悪人いなくても、正常な欲望・合理的判断・KPI・制度・善意が接続して悪い結果が立ち上がる可能性",
      "Composite Evil との Related Pattern（同一概念ではない）",
    ],
  },
  {
    observatoryId: "entangled-society",
    title: "Entangled Society × Buddhist Lens",
    whatBecomesVisible: [
      "縁起（思想的レンズ）と Entangled Society（分析システム）の隣接関係",
      "単独原因ではなく条件と関係の組み合わせ",
    ],
    note: "同一視しない。",
  },
  {
    observatoryId: "intimacy",
    title: "Intimacy × Buddhist Lens",
    whatBecomesVisible: [
      "愛されたい / 選ばれたい / 傷つきたくない",
      "もっと良い相手がいるかもしれない / 比較したい / 失いたくない",
    ],
  },
  {
    observatoryId: "market-signals",
    title: "Market Signals × Buddhist Lens",
    whatBecomesVisible: [
      "成長したい / 儲けたい / 取り残されたくない",
      "市場を支配したい / 効率化したい / リスクを避けたい",
    ],
  },
  {
    observatoryId: "body-meaning",
    title: "Body Meaning × Buddhist Lens",
    whatBecomesVisible: [
      "身体信号・必要・意味づけ・欲の境界（Need ≠ Craving）",
      "身体を固定的な『健康な自分／若い自分』として期待していないかという問い",
    ],
  },
  {
    observatoryId: "literature",
    title: "Literature / Book × Buddhist Lens",
    whatBecomesVisible: [
      "物語が固定する自己像・正解・救済への執着",
      "読む主体に生じる渇愛と慈悲の盲点",
    ],
  },
];

export function getBuddhistExampleForObservatory(
  observatoryId: string,
): ObservatoryLensExample | undefined {
  return BUDDHIST_OBSERVATORY_EXAMPLES.find(
    (e) => e.observatoryId === observatoryId,
  );
}
