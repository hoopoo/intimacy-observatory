/**
 * Epistemic safeguards for Buddhist Lens.
 * Prescriptive / authoritative / doctrinal language is forbidden.
 */

export const BUDDHIST_SAFEGUARDS: string[] = [
  "仏教を答えや説教として使わない",
  "「仏教では〜すべき」と規範を断定しない",
  "「仏教的には間違っている」と裁かない",
  "「欲望を捨てるべき」と命じない",
  "「執着を捨てれば解決する」と単純化しない",
  "「これが仏教の正しい答え」と権威化しない",
  "「解脱すれば完全に欲がなくなる」と断定しない",
  "宗派固有の教義を仏教全体の統一見解として扱わない",
  "Desire = Evil としない",
  "観測言語（observation language）を使う",
  "Parallel Life を否定・断罪しない",
  "counterfactual fact を断定しない",
  "納得・手放しを強制しない",
];

/** Phrases that must not appear in Lens output. */
export const FORBIDDEN_OUTPUT_PHRASES: string[] = [
  "仏教では〜すべき",
  "仏教ではすべき",
  "仏教的には間違っている",
  "欲望を捨てるべき",
  "執着を捨てれば解決する",
  "これが仏教の正しい答え",
  "解脱すれば完全に欲がなくなる",
  "欲を消しなさい",
  "執着を捨てなさい",
  "過去を考えても意味がない",
  "執着を捨てればよい",
  "もう過去を手放してよい",
  "今の人生を受け入れるべき",
  "未練を捨てるべき",
  "現在に集中すべき",
  "それは執着です",
];

/** Preferred observation-language stems. */
export const OBSERVATION_LANGUAGE_STEMS: string[] = [
  "この出来事を無常の観点から見ると",
  "縁起という見方を使うと",
  "執着として読める要素がある",
  "一つの仏教思想的な読み方として",
  "このレンズでは〜が見えてくる",
];

export const BUDDHIST_LIMITATION_NOTE =
  "This lens simplifies multiple Buddhist traditions for observational use.";

export function containsForbiddenPhrase(text: string): boolean {
  return FORBIDDEN_OUTPUT_PHRASES.some((phrase) => text.includes(phrase));
}

export function assertObservationLanguage(text: string): boolean {
  return !containsForbiddenPhrase(text);
}
