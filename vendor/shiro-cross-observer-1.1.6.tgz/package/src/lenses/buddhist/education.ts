/**
 * Education-specific Buddhist Lens copy and safeguards.
 * Observation only — not school/parenting advice, parent guilt, or social determinism.
 */

export const EDUCATION_LENS_COPY = {
  domainNote:
    "Education では、制度が既存の欲を刺激するだけでなく、何を価値あるものとして欲するべきかという意味形成に関与する可能性を見る。",
  teachableInterface:
    "Desire as Teachable Interface: institutional signal → social meaning → repeated evaluation → internalized goal / desired future として読める可能性。単純因果や強制的形成モデルにしない。",
  desireFormation:
    "Institutional Desire Formation: 評価・反復される社会的意味づけを通じて、成功・安心・望ましい未来の形が形成される可能性。",
  notManipulation:
    "Education を Scam の操作として扱わない。欺瞞・搾取意図としての manipulation とは区別する。",
  notMereIncentivization:
    "Employment の Incentivization（既存の欲の方向づけ）と区別する。Education では意味形成 / teaching の層を見る。",
  parentDesireSafeguard:
    "「子どもを幸せにしたい」という親の欲求は自然で理解可能なものとして扱う。親を加害者化しない。",
  meaningTranslation:
    "幸せ → 将来困らない → 良い教育 → 良い学校 / 海外経験 → 成績・credential といった意味変換を、陰謀ではなく社会的意味変換として観測する。",
  learningVsEvaluation:
    "Learning（好奇心・理解）と Evaluation（score・ranking・credential）は同一ではない。評価悪玉論にしない。",
  childAgency:
    "子どもを制度に形成されるだけの存在としない。curiosity / resistance / preference / unexpected pathways もありうる。",
  noSocialDeterminism:
    "社会が欲望を単独で作る、個人の動機がゼロだ、といった決定論にはしない。",
  notEducationAdvice:
    "This lens does not replace educational, developmental, career, or parenting analysis.",
} as const;

export const EDUCATION_FORBIDDEN_PHRASES: string[] = [
  "親の欲が子どもを苦しめている",
  "教育熱心な親は執着している",
  "良い学校を望むのは欲深い",
  "親が手放せば子どもは自由になる",
  "学校が子どもを洗脳する",
  "教育が欲望を植え付ける",
  "社会が欲望を作る",
  "学校に洗脳されている",
  "学歴は幻想",
  "成功は全部社会的構築物",
  "本人の欲は存在しない",
  "評価は悪",
  "点数はいらない",
];

export const EDUCATION_REFLECTION_QUESTIONS: string[] = [
  "自分が『欲しい』と思っている未来のうち、どこまでが自分で見つけたもので、どこからが『望ましい未来』として教えられてきたものだろうか。",
  "子どもに望んでいるのは『幸せ』そのものだろうか。それとも、社会が幸せに近いと教えてきた進路だろうか。",
  "評価されることと、学ぶことは、この場面で同じだろうか。それとも、すでに離れ始めているだろうか。",
  "この評価やcredentialの設計から、誰の学び方や生活条件が抜け落ちているだろうか。",
];

export function pickEducationReflectionQuestion(
  primaryConceptId: string,
  text: string,
): string {
  const hay = text.toLowerCase();
  if (
    /親|parent|子ども|child|幸せ|家庭資本|家族/.test(hay) ||
    primaryConceptId === "b08-compassion"
  ) {
    return EDUCATION_REFLECTION_QUESTIONS[1]!;
  }
  if (
    /成績|score|ranking|評価|学ぶ|learning|curiosity/.test(hay) ||
    primaryConceptId === "b03-non-self"
  ) {
    return EDUCATION_REFLECTION_QUESTIONS[2]!;
  }
  if (
    /留学|credential|階級|国際|admission|偏差値/.test(hay) ||
    primaryConceptId === "b05-craving" ||
    primaryConceptId === "b06-attachment"
  ) {
    return EDUCATION_REFLECTION_QUESTIONS[0]!;
  }
  return EDUCATION_REFLECTION_QUESTIONS[3]!;
}

export function containsEducationForbidden(text: string): boolean {
  return EDUCATION_FORBIDDEN_PHRASES.some((p) => text.includes(p));
}
