/**
 * Desire as a cross-observatory motif within Buddhist Lens v1.
 *
 * Desire ≠ Evil.
 * We observe the chain, not the desire itself as moral failure.
 *
 * Desire → Decision → Behavior → Entanglement → Consequence → Meaning
 *
 * No independent Desire Engine in v1.
 */

export const DESIRE_CHAIN_STAGES = [
  "desire",
  "decision",
  "behavior",
  "entanglement",
  "consequence",
  "meaning",
] as const;

export type DesireChainStage = (typeof DESIRE_CHAIN_STAGES)[number];

export type DesireExample = {
  text: string;
  valence: "bright" | "mixed" | "shadow";
};

/** Illustrative desires — neither condemned nor celebrated. */
export const DESIRE_SPECTRUM: DesireExample[] = [
  { text: "お金が欲しい", valence: "mixed" },
  { text: "愛されたい", valence: "bright" },
  { text: "評価されたい", valence: "mixed" },
  { text: "安心したい", valence: "bright" },
  { text: "成功したい", valence: "mixed" },
  { text: "失敗したくない", valence: "shadow" },
  { text: "子どもを幸せにしたい", valence: "bright" },
  { text: "誰かを助けたい", valence: "bright" },
  { text: "美しいものを作りたい", valence: "bright" },
  { text: "知りたい", valence: "bright" },
];

export const DESIRE_MOTIF_COPY = {
  keyStatement:
    "欲を消すのではなく、欲に動かされている自分と社会を観測する。",
  secondaryStatement:
    "欲がなくなることではなく、欲が生じても、それに完全に支配されない状態を考える。",
  chainDescription:
    "見るべきなのは欲そのものではなく、欲 → Decision → Behavior → Entanglement → Consequence → Meaning という流れである。",
  nonEvilNote:
    "Desire = Evil とはしない。欲には明暗両方がある。",
} as const;

export type DesireMotifReading = {
  chain: typeof DESIRE_CHAIN_STAGES;
  observedDesires: string[];
  note: string;
};

/**
 * Lightweight keyword scan for desire motifs in observation text.
 * Heuristic only — not a Desire Engine.
 */
export function detectDesireMotifs(text: string): DesireMotifReading {
  const lower = text.toLowerCase();
  const haystack = `${text}\n${lower}`;

  const patterns: Array<{ desire: string; keys: string[] }> = [
    { desire: "お金が欲しい / 儲けたい", keys: ["お金", "儲け", "利益", "money", "profit", "wealth"] },
    { desire: "愛されたい / 選ばれたい", keys: ["愛され", "選ばれ", "loved", "chosen", "intimacy"] },
    { desire: "評価されたい", keys: ["評価", "承認", "recognition", "status", "肩書"] },
    { desire: "安心したい / 安定したい", keys: ["安心", "安定", "safety", "security"] },
    { desire: "成功したい / 成長したい", keys: ["成功", "成長", "success", "growth"] },
    { desire: "失敗したくない / 損したくない", keys: ["失敗", "損した", "取り残され", "fomo", "risk"] },
    { desire: "別の人生を知りたい", keys: ["別の人生", "平行", "parallel", "もしも", "後悔"] },
    { desire: "子どもを幸せにしたい", keys: ["子ども", "子供", "良い学校", "教育"] },
    { desire: "知りたい", keys: ["知りたい", "探索", "curiosity", "learn"] },
  ];

  const observedDesires = patterns
    .filter((p) => p.keys.some((k) => haystack.includes(k)))
    .map((p) => p.desire);

  return {
    chain: DESIRE_CHAIN_STAGES,
    observedDesires,
    note: DESIRE_MOTIF_COPY.chainDescription,
  };
}
