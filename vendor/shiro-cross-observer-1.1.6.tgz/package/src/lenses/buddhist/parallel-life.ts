/**
 * Parallel Life–specific Buddhist Lens copy and safeguards.
 * Coexists with Parallel Life Protocol — does not negate exploration.
 */

export const PARALLEL_LIFE_LENS_COPY = {
  coexistence:
    "Parallel Life は選ばなかった人生を探索する。Buddhist Lens は、なぜその人生を今も探索したいのかを観測する。両者は共存する。",
  coreQuestion: "なぜ、その選ばなかった人生を今も知りたいのか。",
  pastDesireNote:
    "過去の分岐時点の Desire と、現在その未選択人生を知りたいという Desire は混同しない。",
  selfMotif:
    "Desire → Decision → Life Path → Consequence → Memory → Counterfactual → Meaning → Desire（自己物語としての読み。Desire Engine ではない）。",
  counterfactualLimit:
    "このレンズは counterfactual fact（未選択人生の結果断定）を生成しない。知りたいという問いを読む。",
  noClosure:
    "納得・手放し・現在への集中を強制しない。問いが残り続けること自体も Observation になりうる。",
  notNegation:
    "このレンズは Parallel Life を否定しない。未選択人生を考えること自体を苦の原因として断罪しない。",
} as const;

export const PARALLEL_LIFE_FORBIDDEN_PHRASES: string[] = [
  "過去を考えても意味がない",
  "執着を捨てればよい",
  "未選択人生を考えること自体が苦の原因",
  "仏教的にはParallel Lifeは不要",
  "もう過去を手放してよい",
  "今の人生を受け入れるべき",
  "未練を捨てるべき",
  "現在に集中すべき",
  "それは執着です",
  "部長になっていた",
  "年収は上がっていた",
];

export const PARALLEL_LIFE_REFLECTION_QUESTIONS: string[] = [
  "もし未選択人生の結果を完全に知ることができたら、あなたが本当に確認したいのは何だろう。",
  "知りたいのは、別の人生そのものだろうか。それとも、その人生が持っていたと思う何かだろうか。",
  "もし年収や役職の答えが分かっても、この問いは終わるだろうか。",
  "なぜ、その選ばなかった人生を今も知りたいのか。",
  "この問いが今も残っていることで、守られているもの、または見えなくなっているものは何か。",
];

export function pickParallelLifeReflectionQuestion(
  primaryConceptId: string,
  text: string,
): string {
  const hay = text.toLowerCase();
  if (
    primaryConceptId === "b05-craving" ||
    /年収|役職|知りたい|どうなって/.test(hay)
  ) {
    return PARALLEL_LIFE_REFLECTION_QUESTIONS[2]!;
  }
  if (primaryConceptId === "b06-attachment" || /残って|もし|未選択|別の人生/.test(hay)) {
    return PARALLEL_LIFE_REFLECTION_QUESTIONS[0]!;
  }
  if (primaryConceptId === "b01-impermanence") {
    return PARALLEL_LIFE_REFLECTION_QUESTIONS[1]!;
  }
  if (primaryConceptId === "b08-compassion") {
    return PARALLEL_LIFE_REFLECTION_QUESTIONS[4]!;
  }
  return PARALLEL_LIFE_REFLECTION_QUESTIONS[3]!;
}

export function containsParallelLifeForbidden(text: string): boolean {
  return PARALLEL_LIFE_FORBIDDEN_PHRASES.some((p) => text.includes(p));
}
