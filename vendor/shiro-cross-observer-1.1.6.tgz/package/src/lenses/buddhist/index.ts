export { BUDDHIST_LENS_DEFINITION, BUDDHIST_LENS_ID, BUDDHIST_LENS_VERSION } from "./definition";
export { BUDDHIST_CONCEPTS, getBuddhistConceptById, getBuddhistConceptByCode } from "./concepts";
export { applyBuddhistLens } from "./apply";
export {
  BUDDHIST_SAFEGUARDS,
  FORBIDDEN_OUTPUT_PHRASES,
  BUDDHIST_LIMITATION_NOTE,
  containsForbiddenPhrase,
  assertObservationLanguage,
} from "./safeguards";
export {
  DESIRE_CHAIN_STAGES,
  DESIRE_SPECTRUM,
  DESIRE_MOTIF_COPY,
  detectDesireMotifs,
} from "./desire-motif";
export {
  BUDDHIST_OBSERVATORY_EXAMPLES,
  getBuddhistExampleForObservatory,
} from "./observatory-examples";
export { BUDDHIST_LENS_COPY } from "./copy";
export { ENTANGLED_SOCIETY_RELATED_PATTERN, DEPENDENT_ORIGINATION_COPY } from "./related/entangled-society";
export {
  COMPOSITE_EVIL_RELATED_PATTERN,
  COMPOSITE_EVIL_LENS_BRIDGE,
} from "./related/composite-evil";
export {
  PARALLEL_LIFE_LENS_COPY,
  PARALLEL_LIFE_FORBIDDEN_PHRASES,
  PARALLEL_LIFE_REFLECTION_QUESTIONS,
  pickParallelLifeReflectionQuestion,
  containsParallelLifeForbidden,
} from "./parallel-life";
export {
  INTIMACY_LENS_COPY,
  INTIMACY_FORBIDDEN_PHRASES,
  INTIMACY_REFLECTION_QUESTIONS,
  pickIntimacyReflectionQuestion,
  containsIntimacyForbidden,
} from "./intimacy";
export {
  ROMANCE_PROTOCOL_COLLAPSE_RELATED_PATTERN,
  ROMANCE_PROTOCOL_LENS_BRIDGE,
} from "./related/romance-protocol-collapse";
export {
  SCAM_LENS_COPY,
  SCAM_FORBIDDEN_PHRASES,
  SCAM_REFLECTION_QUESTIONS,
  pickScamReflectionQuestion,
  containsScamForbidden,
} from "./scam";
export {
  INTENTIONAL_HARM_RELATED_PATTERN,
  INTENTIONAL_HARM_LENS_BRIDGE,
} from "./related/intentional-harm";
export {
  EMPLOYMENT_LENS_COPY,
  EMPLOYMENT_FORBIDDEN_PHRASES,
  EMPLOYMENT_REFLECTION_QUESTIONS,
  pickEmploymentReflectionQuestion,
  containsEmploymentForbidden,
} from "./employment";
export {
  STRUCTURAL_INCENTIVIZATION_RELATED_PATTERN,
  STRUCTURAL_INCENTIVIZATION_LENS_BRIDGE,
} from "./related/structural-incentivization";
export {
  EDUCATION_LENS_COPY,
  EDUCATION_FORBIDDEN_PHRASES,
  EDUCATION_REFLECTION_QUESTIONS,
  pickEducationReflectionQuestion,
  containsEducationForbidden,
} from "./education";
export {
  INSTITUTIONAL_DESIRE_FORMATION_RELATED_PATTERN,
  INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE,
} from "./related/institutional-desire-formation";
export {
  BODY_MEANING_LENS_COPY,
  BODY_MEANING_FORBIDDEN_PHRASES,
  BODY_MEANING_REFLECTION_QUESTIONS,
  pickBodyMeaningReflectionQuestion,
  containsBodyMeaningForbidden,
  isAgingBodyMeaningInput,
  isIllnessBodyMeaningInput,
} from "./body-meaning";
export {
  EMBODIED_DESIRE_SIGNAL_RELATED_PATTERN,
  EMBODIED_DESIRE_SIGNAL_LENS_BRIDGE,
} from "./related/embodied-desire-signal";
export {
  AGING_BODY_CHANGE_RELATED_PATTERN,
  AGING_BODY_CHANGE_LENS_BRIDGE,
} from "./related/aging-body-change";
export {
  ILLNESS_CHRONIC_PAIN_RELATED_PATTERN,
  ILLNESS_CHRONIC_PAIN_LENS_BRIDGE,
} from "./related/illness-chronic-pain";
