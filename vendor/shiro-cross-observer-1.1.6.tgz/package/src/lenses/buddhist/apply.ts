import type { LensInput, LensResult, RelatedPattern } from "../../types/lens";
import { BUDDHIST_CONCEPTS, getBuddhistConceptById } from "./concepts";
import {
  BUDDHIST_LIMITATION_NOTE,
  assertObservationLanguage,
} from "./safeguards";
import { detectDesireMotifs, DESIRE_MOTIF_COPY } from "./desire-motif";
import { getBuddhistExampleForObservatory } from "./observatory-examples";
import {
  ENTANGLED_SOCIETY_RELATED_PATTERN,
  DEPENDENT_ORIGINATION_COPY,
} from "./related/entangled-society";
import {
  COMPOSITE_EVIL_RELATED_PATTERN,
  COMPOSITE_EVIL_LENS_BRIDGE,
} from "./related/composite-evil";
import {
  PARALLEL_LIFE_LENS_COPY,
  pickParallelLifeReflectionQuestion,
  containsParallelLifeForbidden,
} from "./parallel-life";
import {
  INTIMACY_LENS_COPY,
  pickIntimacyReflectionQuestion,
  containsIntimacyForbidden,
} from "./intimacy";
import {
  ROMANCE_PROTOCOL_COLLAPSE_RELATED_PATTERN,
  ROMANCE_PROTOCOL_LENS_BRIDGE,
} from "./related/romance-protocol-collapse";
import {
  SCAM_LENS_COPY,
  pickScamReflectionQuestion,
  containsScamForbidden,
} from "./scam";
import {
  INTENTIONAL_HARM_RELATED_PATTERN,
  INTENTIONAL_HARM_LENS_BRIDGE,
} from "./related/intentional-harm";
import {
  EMPLOYMENT_LENS_COPY,
  pickEmploymentReflectionQuestion,
  containsEmploymentForbidden,
} from "./employment";
import {
  STRUCTURAL_INCENTIVIZATION_RELATED_PATTERN,
  STRUCTURAL_INCENTIVIZATION_LENS_BRIDGE,
} from "./related/structural-incentivization";
import {
  EDUCATION_LENS_COPY,
  pickEducationReflectionQuestion,
  containsEducationForbidden,
} from "./education";
import {
  BODY_MEANING_LENS_COPY,
  containsBodyMeaningForbidden,
  isAgingBodyMeaningInput,
  isIllnessBodyMeaningInput,
  pickBodyMeaningReflectionQuestion,
} from "./body-meaning";
import {
  EMBODIED_DESIRE_SIGNAL_RELATED_PATTERN,
  EMBODIED_DESIRE_SIGNAL_LENS_BRIDGE,
} from "./related/embodied-desire-signal";
import {
  AGING_BODY_CHANGE_RELATED_PATTERN,
  AGING_BODY_CHANGE_LENS_BRIDGE,
} from "./related/aging-body-change";
import {
  ILLNESS_CHRONIC_PAIN_RELATED_PATTERN,
  ILLNESS_CHRONIC_PAIN_LENS_BRIDGE,
} from "./related/illness-chronic-pain";
import {
  INSTITUTIONAL_DESIRE_FORMATION_RELATED_PATTERN,
  INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE,
} from "./related/institutional-desire-formation";
import { BUDDHIST_LENS_ID } from "./definition";

type ScoredConcept = { id: string; score: number };

const CONCEPT_KEYWORDS: Record<string, string[]> = {
  "b01-impermanence": [
    "変わら",
    "変化",
    "老い",
    "時間",
    "制度",
    "関係",
    "永遠",
    "固定",
    "impermanence",
    "change",
    "aging",
  ],
  "b02-dukkha": [
    "苦",
    "満たされ",
    "摩擦",
    "不足",
    "痛み",
    "思い通り",
    "ストレス",
    "dukkha",
    "suffer",
    "摩擦",
    "比較",
    "孤独",
    "不安",
    "羞恥",
    "恥",
    "混乱",
    "疲労",
    "疲れ",
    "不眠",
    "眠気",
    "fatigue",
    "urgency",
    "損失",
    "fear",
    "shame",
  ],
  "b03-non-self": [
    "私",
    "彼ら",
    "会社",
    "社会",
    "肩書",
    "優等生",
    "落ちこぼれ",
    "偏差値",
    "学歴",
    "identity",
    "国際性",
    "役割",
    "アイデンティティ",
    "identity",
    "self",
    "ロール",
  ],
  "b04-dependent-origination": [
    "条件",
    "関係",
    "接続",
    "因果",
    "絡み",
    "entangl",
    "composite",
    "合成",
    "システム",
    "依存",
  ],
  "b05-craving": [
    "欲し",
    "取り戻",
    "失いたく",
    "避けたい",
    "渇",
    "desire",
    "craving",
    "fear",
    "longing",
    "儲け",
    "愛され",
    "知りたい",
    "年収",
    "役職",
    "どうなって",
    "確認",
    "選ばれ",
    "見捨て",
    "もっと良い",
    "マッチ",
    "安心",
    "助けたい",
    "損したく",
    "騙",
    "詐欺",
  ],
  "b06-attachment": [
    "執着",
    "握",
    "手放せ",
    "過去",
    "正解",
    "別の人生",
    "成功像",
    "attachment",
    "cling",
    "評価",
    "残って",
    "もし",
    "未選択",
    "後悔",
    "理想",
    "最適",
    "perfect",
    "sunk",
    "すでに払",
    "信じ",
    "関係が偽物",
  ],
  "b07-emptiness": [
    "意味",
    "価値",
    "カテゴリー",
    "本質",
    "固有",
    "emptiness",
    "本質的",
    "正しい教育",
    "正常",
  ],
  "b08-compassion": [
    "被害",
    "弱",
    "見えな",
    "抜け落ち",
    "排除",
    "blind",
    "compassion",
    "誰の",
    "身体",
    "高齢",
    "孤独",
    "grief",
    "介護",
    "恥",
    "相談",
  ],
};

const OBSERVATORY_CONCEPT_BIAS: Record<string, string[]> = {
  "parallel-life": ["b05-craving", "b06-attachment", "b01-impermanence"],
  scam: [
    "b05-craving",
    "b08-compassion",
    "b06-attachment",
    "b02-dukkha",
    "b04-dependent-origination",
  ],
  employment: [
    "b05-craving",
    "b06-attachment",
    "b04-dependent-origination",
    "b03-non-self",
    "b02-dukkha",
    "b01-impermanence",
    "b08-compassion",
  ],
  education: [
    "b05-craving",
    "b06-attachment",
    "b03-non-self",
    "b04-dependent-origination",
    "b02-dukkha",
    "b01-impermanence",
    "b08-compassion",
  ],
  "clean-society": [
    "b04-dependent-origination",
    "b05-craving",
    "b06-attachment",
  ],
  "entangled-society": [
    "b04-dependent-origination",
    "b08-compassion",
    "b07-emptiness",
  ],
  intimacy: ["b05-craving", "b06-attachment", "b02-dukkha", "b04-dependent-origination"],
  "market-signals": ["b05-craving", "b01-impermanence", "b06-attachment"],
  "body-meaning": [
    "b01-impermanence",
    "b02-dukkha",
    "b03-non-self",
    "b04-dependent-origination",
    "b08-compassion",
    "b05-craving",
    "b06-attachment",
  ],
  literature: ["b06-attachment", "b07-emptiness", "b08-compassion"],
};

function scoreConcepts(input: LensInput): ScoredConcept[] {
  const haystack = `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`;
  const lower = haystack.toLowerCase();

  const scores = BUDDHIST_CONCEPTS.map((concept) => {
    const keys = CONCEPT_KEYWORDS[concept.id] ?? [];
    let score = 0;
    for (const key of keys) {
      if (lower.includes(key.toLowerCase())) score += 2;
    }
    return { id: concept.id, score };
  });

  const bias = OBSERVATORY_CONCEPT_BIAS[input.sourceObservatory] ?? [];
  bias.forEach((id, index) => {
    const row = scores.find((s) => s.id === id);
    if (row) row.score += 3 - Math.min(index, 2);
  });

  // Ensure deterministic non-zero baseline so we always produce a reading.
  for (const row of scores) {
    if (row.score === 0) row.score = 0.1;
  }

  return scores.sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
}

function buildRelatedPatterns(input: LensInput): RelatedPattern[] {
  const patterns: RelatedPattern[] = [];
  const obs = input.sourceObservatory;
  const text = `${input.title ?? ""} ${input.text} ${input.context ?? ""}`.toLowerCase();

  if (
    obs === "entangled-society" ||
    text.includes("entangl") ||
    text.includes("絡み") ||
    text.includes("因果")
  ) {
    patterns.push(ENTANGLED_SOCIETY_RELATED_PATTERN);
  }

  if (
    obs === "clean-society" ||
    obs === "employment" ||
    ((text.includes("composite evil") ||
      text.includes("合成悪") ||
      (text.includes("合成") && !text.includes("intentional"))) &&
      obs !== "scam")
  ) {
    patterns.push(COMPOSITE_EVIL_RELATED_PATTERN);
  }

  if (
    obs === "intimacy" ||
    text.includes("romance protocol") ||
    text.includes("恋愛プロトコル") ||
    text.includes("infinite choice") ||
    text.includes("optimization fatigue") ||
    text.includes("マッチング") ||
    text.includes("親密")
  ) {
    patterns.push(ROMANCE_PROTOCOL_COLLAPSE_RELATED_PATTERN);
  }

  if (
    obs === "scam" ||
    text.includes("intentional harm") ||
    text.includes("詐欺") ||
    text.includes("romance scam")
  ) {
    patterns.push(INTENTIONAL_HARM_RELATED_PATTERN);
  }

  if (
    obs === "employment" ||
    text.includes("structural incentivization") ||
    text.includes("構造的誘引") ||
    text.includes("kpi") ||
    text.includes("hidden compensation") ||
    text.includes("保障パッケージ")
  ) {
    patterns.push(STRUCTURAL_INCENTIVIZATION_RELATED_PATTERN);
  }

  if (
    obs === "education" ||
    text.includes("institutional desire formation") ||
    text.includes("制度的欲望形成") ||
    text.includes("偏差値") ||
    text.includes("credential") ||
    text.includes("進学") ||
    text.includes("留学")
  ) {
    patterns.push(INSTITUTIONAL_DESIRE_FORMATION_RELATED_PATTERN);
  }

  if (
    obs === "body-meaning" ||
    text.includes("embodied desire") ||
    text.includes("body signal") ||
    text.includes("身体信号") ||
    text.includes("productive body") ||
    text.includes("働き続ける身体")
  ) {
    patterns.push(EMBODIED_DESIRE_SIGNAL_RELATED_PATTERN);
  }

  if (
    (obs === "body-meaning" &&
      !text.includes("body meaning case: illness") &&
      (text.includes("body meaning case: aging") ||
        text.includes("aging case") ||
        text.includes("認知症") ||
        text.includes("老い") ||
        text.includes("老後") ||
        text.includes("aging"))) ||
    text.includes("aging-body-change") ||
    text.includes("aging body change")
  ) {
    patterns.push(AGING_BODY_CHANGE_RELATED_PATTERN);
  }

  if (
    (obs === "body-meaning" &&
      (text.includes("body meaning case: illness") ||
        text.includes("illness / chronic pain") ||
        text.includes("chronic pain") ||
        text.includes("慢性疼痛") ||
        text.includes("中枢性感作") ||
        text.includes("central sensitization"))) ||
    text.includes("illness-chronic-pain")
  ) {
    patterns.push(ILLNESS_CHRONIC_PAIN_RELATED_PATTERN);
  }

  return patterns;
}

function buildInterpretation(
  input: LensInput,
  primaryId: string,
  secondaryIds: string[],
  desires: string[],
): string {
  const primary = getBuddhistConceptById(primaryId);
  const secondaryNames = secondaryIds
    .map((id) => getBuddhistConceptById(id))
    .filter(Boolean)
    .map((c) => `${c!.nameJa}（${c!.name}）`)
    .join("、");

  const desireClause =
    desires.length > 0
      ? `この観測には、例えば「${desires.slice(0, 3).join("」「")}」といった欲の痕跡が読める。`
      : "この観測には、明示されない欲や回避が潜んでいる可能性がある。";

  const entangledClause =
    input.sourceObservatory === "entangled-society"
      ? "欲望は複数条件の一つとして観測できる。このレンズでは、制度的説明とは異なる層が見えてくる。Entangled Society の構造分析に、別の思想的観測レイヤーを重ねる。"
      : "";

  const parallelClause =
    input.sourceObservatory === "parallel-life"
      ? [
          PARALLEL_LIFE_LENS_COPY.coexistence,
          `中心的な観測問いとして、「${PARALLEL_LIFE_LENS_COPY.coreQuestion}」が読める可能性がある。`,
          PARALLEL_LIFE_LENS_COPY.pastDesireNote,
          "欲や執着として断定するのではなく、そう読める要素がある、という観測にとどめる。",
        ].join(" ")
      : "";

  const intimacyClause =
    input.sourceObservatory === "intimacy"
      ? [
          INTIMACY_LENS_COPY.domainNote,
          INTIMACY_LENS_COPY.desireNotEvil,
          INTIMACY_LENS_COPY.desirePlusTechnology,
          "欲や執着として断定するのではなく、そう読める要素がある、という観測にとどめる。",
        ].join(" ")
      : "";

  const scamClause =
    input.sourceObservatory === "scam"
      ? [
          SCAM_LENS_COPY.domainNote,
          SCAM_LENS_COPY.desireNotFault,
          SCAM_LENS_COPY.actorAsymmetry,
          SCAM_LENS_COPY.intentionalHarmNote,
          "欲や執着として断定するのではなく、そう読める要素がある、という観測にとどめる。",
        ].join(" ")
      : "";

  const employmentClause =
    input.sourceObservatory === "employment"
      ? [
          EMPLOYMENT_LENS_COPY.domainNote,
          EMPLOYMENT_LENS_COPY.desireNotPathology,
          EMPLOYMENT_LENS_COPY.incentivizableInterface,
          EMPLOYMENT_LENS_COPY.notManipulation,
          EMPLOYMENT_LENS_COPY.actorAsymmetry,
          "欲や執着として断定するのではなく、そう読める要素がある、という観測にとどめる。",
        ].join(" ")
      : "";

  const educationClause =
    input.sourceObservatory === "education"
      ? [
          EDUCATION_LENS_COPY.domainNote,
          EDUCATION_LENS_COPY.teachableInterface,
          EDUCATION_LENS_COPY.parentDesireSafeguard,
          EDUCATION_LENS_COPY.meaningTranslation,
          EDUCATION_LENS_COPY.notMereIncentivization,
          EDUCATION_LENS_COPY.childAgency,
          "欲や執着として断定するのではなく、そう読める要素がある、という観測にとどめる。",
        ].join(" ")
      : "";

  const bodyMeaningClause =
    input.sourceObservatory === "body-meaning"
      ? [
          BODY_MEANING_LENS_COPY.domainNote,
          isIllnessBodyMeaningInput(input.text, input.context)
            ? [
                BODY_MEANING_LENS_COPY.illnessCaseNote,
                BODY_MEANING_LENS_COPY.branchingModel,
                BODY_MEANING_LENS_COPY.painReliefNotCraving,
                BODY_MEANING_LENS_COPY.physicalVsMeaningSuffering,
                BODY_MEANING_LENS_COPY.illnessMedicalBoundary,
              ].join(" ")
            : isAgingBodyMeaningInput(input.text, input.context)
              ? [
                  BODY_MEANING_LENS_COPY.agingCaseNote,
                  BODY_MEANING_LENS_COPY.branchingModel,
                  BODY_MEANING_LENS_COPY.bodyChangeNotDesire,
                  BODY_MEANING_LENS_COPY.socialTranslationAging,
                  BODY_MEANING_LENS_COPY.gerontologicalBoundary,
                ].join(" ")
              : [
                  BODY_MEANING_LENS_COPY.embodiedSignal,
                  BODY_MEANING_LENS_COPY.needNotCraving,
                  BODY_MEANING_LENS_COPY.medicalBoundary,
                ].join(" "),
          "欲や執着として断定するのではなく、そう読める要素がある、という観測にとどめる。",
        ].join(" ")
      : "";

  const parts = [
    `一つの仏教思想的な読み方として、主に${primary?.nameJa ?? primaryId}（${primary?.name ?? primaryId}）の観点から見る。`,
    `この出来事を${primary?.nameJa ?? "当該概念"}の観点から見ると、「${primary?.question ?? ""}」という問いが立ち上がる。`,
    desireClause,
    entangledClause,
    parallelClause,
    intimacyClause,
    scamClause,
    employmentClause,
    educationClause,
    bodyMeaningClause,
    DESIRE_MOTIF_COPY.keyStatement,
    secondaryNames
      ? `副次的には、${secondaryNames}としても読める要素がある。`
      : "",
    `このレンズでは、答えを与えることではなく、見え方が変わることを目的とする。`,
  ];

  return parts.filter(Boolean).join(" ");
}

function buildWhatBecomesVisible(
  input: LensInput,
  primaryId: string,
  desires: string[],
): string[] {
  const primary = getBuddhistConceptById(primaryId);
  const example = getBuddhistExampleForObservatory(input.sourceObservatory);
  const visible: string[] = [];

  if (primary) {
    visible.push(`観測問い: ${primary.question}`);
    visible.push(`焦点: ${primary.focus.slice(0, 4).join(" / ")}`);
  }

  if (desires.length > 0) {
    visible.push(`欲のモチーフ: ${desires.slice(0, 4).join(" / ")}`);
    visible.push(DESIRE_MOTIF_COPY.chainDescription);
  }

  if (example) {
    visible.push(...example.whatBecomesVisible.slice(0, 2));
  }

  if (input.sourceObservatory === "clean-society") {
    visible.push(COMPOSITE_EVIL_LENS_BRIDGE.observation);
  }

  if (input.sourceObservatory === "entangled-society") {
    visible.push(DEPENDENT_ORIGINATION_COPY.desireNotSoleCause);
    visible.push(
      "Desire → Decision → Behavior → Entanglement → Consequence → Meaning のうち、特に Entanglement（制度・技術・誘因・政策・歴史・規範との接続）を観測する。",
    );
    visible.push(ENTANGLED_SOCIETY_RELATED_PATTERN.description);
  }

  if (input.sourceObservatory === "parallel-life") {
    visible.push(PARALLEL_LIFE_LENS_COPY.coreQuestion);
    visible.push(PARALLEL_LIFE_LENS_COPY.selfMotif);
    visible.push(PARALLEL_LIFE_LENS_COPY.pastDesireNote);
    if (input.metadata?.userQuestion) {
      visible.push(
        `現在の Desire（知りたい問い）として読める可能性: ${String(input.metadata.userQuestion)}`,
      );
    }
    if (input.metadata?.branchPoint || input.metadata?.chosenPath) {
      visible.push(
        "過去の Desire（分岐時点の選択）と現在の Desire を区別して見る。",
      );
    }
  }

  if (input.sourceObservatory === "intimacy") {
    visible.push(INTIMACY_LENS_COPY.desirePlusTechnology);
    visible.push(
      `構造スケッチ（Related Pattern側）: ${ROMANCE_PROTOCOL_LENS_BRIDGE.structuralSketch}`,
    );
    visible.push(
      `Lens側の読み: ${ROMANCE_PROTOCOL_LENS_BRIDGE.lensSketch}`,
    );
    visible.push(ROMANCE_PROTOCOL_LENS_BRIDGE.boundary);
  }

  if (input.sourceObservatory === "scam") {
    visible.push(SCAM_LENS_COPY.manipulableInterface);
    visible.push(SCAM_LENS_COPY.actorAsymmetry);
    visible.push(
      `構造スケッチ: ${INTENTIONAL_HARM_LENS_BRIDGE.manipulableDesireSketch}`,
    );
    visible.push(INTENTIONAL_HARM_LENS_BRIDGE.notCompositeEvil);
    visible.push(INTENTIONAL_HARM_LENS_BRIDGE.boundary);
  }

  if (input.sourceObservatory === "employment") {
    visible.push(EMPLOYMENT_LENS_COPY.incentivizableInterface);
    visible.push(EMPLOYMENT_LENS_COPY.structuralIncentivization);
    visible.push(
      `構造スケッチ: ${STRUCTURAL_INCENTIVIZATION_LENS_BRIDGE.incentivizableSketch}`,
    );
    visible.push(STRUCTURAL_INCENTIVIZATION_LENS_BRIDGE.notManipulation);
    visible.push(STRUCTURAL_INCENTIVIZATION_LENS_BRIDGE.compositeEvilNote);
    visible.push(EMPLOYMENT_LENS_COPY.actorAsymmetry);
    visible.push(EMPLOYMENT_LENS_COPY.kpiNotEvil);
  }

  if (input.sourceObservatory === "education") {
    visible.push(EDUCATION_LENS_COPY.teachableInterface);
    visible.push(EDUCATION_LENS_COPY.desireFormation);
    visible.push(
      `構造スケッチ: ${INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE.teachableSketch}`,
    );
    visible.push(
      `意味変換スケッチ: ${INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE.meaningTranslationSketch}`,
    );
    visible.push(INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE.notManipulation);
    visible.push(
      INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE.notMereIncentivization,
    );
    visible.push(INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE.employmentBridge);
    visible.push(EDUCATION_LENS_COPY.learningVsEvaluation);
    visible.push(EDUCATION_LENS_COPY.childAgency);
    visible.push(EDUCATION_LENS_COPY.parentDesireSafeguard);
  }

  if (input.sourceObservatory === "body-meaning") {
    const illness = isIllnessBodyMeaningInput(input.text, input.context);
    const aging = isAgingBodyMeaningInput(input.text, input.context);
    if (illness) {
      visible.push(BODY_MEANING_LENS_COPY.illnessCaseNote);
      visible.push(BODY_MEANING_LENS_COPY.branchingModel);
      visible.push(BODY_MEANING_LENS_COPY.bodyDisruptionNotDesire);
      visible.push(BODY_MEANING_LENS_COPY.painReliefNotCraving);
      visible.push(BODY_MEANING_LENS_COPY.completeRestorationBoundary);
      visible.push(BODY_MEANING_LENS_COPY.physicalVsMeaningSuffering);
      visible.push(
        `構造スケッチ: ${ILLNESS_CHRONIC_PAIN_LENS_BRIDGE.branchingSketch}`,
      );
      visible.push(ILLNESS_CHRONIC_PAIN_LENS_BRIDGE.vsFatigueAging);
      visible.push(BODY_MEANING_LENS_COPY.pastPresentFutureBody);
      visible.push(BODY_MEANING_LENS_COPY.desireFearBoundary);
      visible.push(BODY_MEANING_LENS_COPY.socialTranslationIllness);
      visible.push(BODY_MEANING_LENS_COPY.illnessCompassionNote);
      visible.push(BODY_MEANING_LENS_COPY.noRecoveryMoralism);
      visible.push(BODY_MEANING_LENS_COPY.illnessMedicalBoundary);
    } else if (aging) {
      visible.push(BODY_MEANING_LENS_COPY.agingCaseNote);
      visible.push(BODY_MEANING_LENS_COPY.branchingModel);
      visible.push(BODY_MEANING_LENS_COPY.bodyChangeNotDesire);
      visible.push(BODY_MEANING_LENS_COPY.embodiedNeedVsSocialDesire);
      visible.push(BODY_MEANING_LENS_COPY.socialTranslationAging);
      visible.push(
        `構造スケッチ: ${AGING_BODY_CHANGE_LENS_BRIDGE.branchingSketch}`,
      );
      visible.push(AGING_BODY_CHANGE_LENS_BRIDGE.vsFatigue);
      visible.push(BODY_MEANING_LENS_COPY.pastPresentBody);
      visible.push(BODY_MEANING_LENS_COPY.desireFearBoundary);
      visible.push(BODY_MEANING_LENS_COPY.antiAgingMarketNote);
      visible.push(BODY_MEANING_LENS_COPY.noMoralAging);
      visible.push(BODY_MEANING_LENS_COPY.gerontologicalBoundary);
    } else {
      visible.push(BODY_MEANING_LENS_COPY.embodiedSignal);
      visible.push(BODY_MEANING_LENS_COPY.needNotCraving);
      visible.push(BODY_MEANING_LENS_COPY.cravingWhenConnected);
      visible.push(
        `構造スケッチ: ${EMBODIED_DESIRE_SIGNAL_LENS_BRIDGE.embodiedSketch}`,
      );
      visible.push(EMBODIED_DESIRE_SIGNAL_LENS_BRIDGE.needNotCraving);
      visible.push(BODY_MEANING_LENS_COPY.dependentConditions);
      visible.push(BODY_MEANING_LENS_COPY.compassionNote);
      visible.push(BODY_MEANING_LENS_COPY.antiReductionism);
      visible.push(BODY_MEANING_LENS_COPY.medicalBoundary);
    }
  }

  return visible;
}

/**
 * Apply Buddhist Lens to a common LensInput.
 * Pure function: does not mutate input; returns a derived LensResult.
 */
export function applyBuddhistLens(input: LensInput): LensResult {
  const scored = scoreConcepts(input);
  const primaryConcept = scored[0]!.id;
  const secondaryConcepts = scored
    .slice(
      1,
      input.sourceObservatory === "intimacy"
        ? 5
        : input.sourceObservatory === "scam" ||
            input.sourceObservatory === "employment" ||
            input.sourceObservatory === "education" ||
            input.sourceObservatory === "body-meaning"
          ? 8
          : 4,
    )
    .map((s) => s.id);

  const desireReading = detectDesireMotifs(
    `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
  );

  const interpretation = buildInterpretation(
    input,
    primaryConcept,
    secondaryConcepts,
    desireReading.observedDesires,
  );

  const primary = getBuddhistConceptById(primaryConcept);

  const result: LensResult = {
    lensId: BUDDHIST_LENS_ID,
    sourceObservatory: input.sourceObservatory,
    sourceObservationId: input.sourceObservationId,
    primaryConcept,
    secondaryConcepts,
    interpretation,
    whatBecomesVisible: buildWhatBecomesVisible(
      input,
      primaryConcept,
      desireReading.observedDesires,
    ),
    limitations: [
      BUDDHIST_LIMITATION_NOTE,
      "このレンズは説教・人生訓・占い・精神的権威として機能しない。",
      "宗派固有の教義差（初期仏教・大乗・禅・浄土・密教など）には V1 では深入りしない。",
      "欲の消滅を目標として断定しない。",
      DESIRE_MOTIF_COPY.nonEvilNote,
      ...(input.sourceObservatory === "entangled-society"
        ? [
            DEPENDENT_ORIGINATION_COPY.notIdenticalNote,
            "このレンズは Entangled Society の社会科学的分析を代替しない。縁起を理解すれば解決する、とは言わない。",
          ]
        : []),
      ...(input.sourceObservatory === "parallel-life"
        ? [
            PARALLEL_LIFE_LENS_COPY.counterfactualLimit,
            PARALLEL_LIFE_LENS_COPY.noClosure,
            PARALLEL_LIFE_LENS_COPY.notNegation,
            "このレンズは Parallel Life Protocol の可能性推定を代替しない。",
          ]
        : []),
      ...(input.sourceObservatory === "intimacy"
        ? [
            INTIMACY_LENS_COPY.notAdvice,
            INTIMACY_LENS_COPY.noDeterminism,
            INTIMACY_LENS_COPY.desireNotEvil,
            ROMANCE_PROTOCOL_LENS_BRIDGE.boundary,
          ]
        : []),
      ...(input.sourceObservatory === "scam"
        ? [
            SCAM_LENS_COPY.desireNotFault,
            SCAM_LENS_COPY.actorAsymmetry,
            SCAM_LENS_COPY.intentionalHarmNote,
            SCAM_LENS_COPY.notSecurityAdvice,
            SCAM_LENS_COPY.notSpiritualPrevention,
            INTENTIONAL_HARM_LENS_BRIDGE.boundary,
          ]
        : []),
      ...(input.sourceObservatory === "employment"
        ? [
            EMPLOYMENT_LENS_COPY.desireNotPathology,
            EMPLOYMENT_LENS_COPY.notManipulation,
            EMPLOYMENT_LENS_COPY.actorAsymmetry,
            EMPLOYMENT_LENS_COPY.kpiNotEvil,
            EMPLOYMENT_LENS_COPY.notCareerAdvice,
            STRUCTURAL_INCENTIVIZATION_LENS_BRIDGE.boundary,
            STRUCTURAL_INCENTIVIZATION_LENS_BRIDGE.compositeEvilNote,
          ]
        : []),
      ...(input.sourceObservatory === "education"
        ? [
            EDUCATION_LENS_COPY.parentDesireSafeguard,
            EDUCATION_LENS_COPY.childAgency,
            EDUCATION_LENS_COPY.notManipulation,
            EDUCATION_LENS_COPY.notMereIncentivization,
            EDUCATION_LENS_COPY.noSocialDeterminism,
            EDUCATION_LENS_COPY.learningVsEvaluation,
            EDUCATION_LENS_COPY.notEducationAdvice,
            INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE.boundary,
            INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE.employmentBridge,
          ]
        : []),
      ...(input.sourceObservatory === "body-meaning"
        ? isIllnessBodyMeaningInput(input.text, input.context)
          ? [
              BODY_MEANING_LENS_COPY.painReliefNotCraving,
              BODY_MEANING_LENS_COPY.bodyDisruptionNotDesire,
              BODY_MEANING_LENS_COPY.illnessNotBlame,
              BODY_MEANING_LENS_COPY.noRecoveryMoralism,
              BODY_MEANING_LENS_COPY.physicalVsMeaningSuffering,
              BODY_MEANING_LENS_COPY.desireFearBoundary,
              BODY_MEANING_LENS_COPY.antiReductionism,
              BODY_MEANING_LENS_COPY.illnessMedicalBoundary,
              ILLNESS_CHRONIC_PAIN_LENS_BRIDGE.boundary,
            ]
          : isAgingBodyMeaningInput(input.text, input.context)
            ? [
                BODY_MEANING_LENS_COPY.bodyChangeNotDesire,
                BODY_MEANING_LENS_COPY.needNotCraving,
                BODY_MEANING_LENS_COPY.agingNotMoralize,
                BODY_MEANING_LENS_COPY.noMoralAging,
                BODY_MEANING_LENS_COPY.desireFearBoundary,
                BODY_MEANING_LENS_COPY.antiReductionism,
                BODY_MEANING_LENS_COPY.gerontologicalBoundary,
                AGING_BODY_CHANGE_LENS_BRIDGE.boundary,
              ]
            : [
                BODY_MEANING_LENS_COPY.needNotCraving,
                BODY_MEANING_LENS_COPY.healthNotPathology,
                BODY_MEANING_LENS_COPY.illnessNotBlame,
                BODY_MEANING_LENS_COPY.agingNotMoralize,
                BODY_MEANING_LENS_COPY.antiReductionism,
                BODY_MEANING_LENS_COPY.medicalBoundary,
                EMBODIED_DESIRE_SIGNAL_LENS_BRIDGE.boundary,
              ]
        : []),
    ],
    reflectionQuestion:
      input.sourceObservatory === "parallel-life"
        ? pickParallelLifeReflectionQuestion(
            primaryConcept,
            `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
          )
        : input.sourceObservatory === "intimacy"
          ? pickIntimacyReflectionQuestion(
              primaryConcept,
              `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
            )
          : input.sourceObservatory === "scam"
            ? pickScamReflectionQuestion(
                primaryConcept,
                `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
              )
            : input.sourceObservatory === "employment"
              ? pickEmploymentReflectionQuestion(
                  primaryConcept,
                  `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
                )
              : input.sourceObservatory === "education"
                ? pickEducationReflectionQuestion(
                    primaryConcept,
                    `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
                  )
                : input.sourceObservatory === "body-meaning"
                  ? pickBodyMeaningReflectionQuestion(
                      primaryConcept,
                      `${input.title ?? ""}\n${input.text}\n${input.context ?? ""}`,
                    )
                  : (primary?.question ??
                    "この出来事を、どの仏教的概念からもう一度見ることができるか。"),
    notes: [
      DESIRE_MOTIF_COPY.secondaryStatement,
      desireReading.note,
      ...(input.sourceObservatory === "entangled-society"
        ? [DEPENDENT_ORIGINATION_COPY.observatoryView]
        : []),
      ...(input.sourceObservatory === "parallel-life"
        ? [PARALLEL_LIFE_LENS_COPY.selfMotif, PARALLEL_LIFE_LENS_COPY.coexistence]
        : []),
      ...(input.sourceObservatory === "intimacy"
        ? [INTIMACY_LENS_COPY.domainNote, INTIMACY_LENS_COPY.desirePlusTechnology]
        : []),
      ...(input.sourceObservatory === "scam"
        ? [
            SCAM_LENS_COPY.domainNote,
            SCAM_LENS_COPY.manipulableInterface,
            "Security Layer（どう防ぐか）と Buddhist Lens（どう見るか）は分離する。",
          ]
        : []),
      ...(input.sourceObservatory === "employment"
        ? [
            EMPLOYMENT_LENS_COPY.domainNote,
            EMPLOYMENT_LENS_COPY.incentivizableInterface,
            EMPLOYMENT_LENS_COPY.structuralIncentivization,
          ]
        : []),
      ...(input.sourceObservatory === "education"
        ? [
            EDUCATION_LENS_COPY.domainNote,
            EDUCATION_LENS_COPY.teachableInterface,
            EDUCATION_LENS_COPY.desireFormation,
          ]
        : []),
      ...(input.sourceObservatory === "body-meaning"
        ? isIllnessBodyMeaningInput(input.text, input.context)
          ? [
              BODY_MEANING_LENS_COPY.domainNote,
              BODY_MEANING_LENS_COPY.illnessCaseNote,
              BODY_MEANING_LENS_COPY.branchingModel,
              BODY_MEANING_LENS_COPY.painReliefNotCraving,
              ILLNESS_CHRONIC_PAIN_LENS_BRIDGE.vsFatigueAging,
            ]
          : isAgingBodyMeaningInput(input.text, input.context)
            ? [
                BODY_MEANING_LENS_COPY.domainNote,
                BODY_MEANING_LENS_COPY.agingCaseNote,
                BODY_MEANING_LENS_COPY.branchingModel,
                BODY_MEANING_LENS_COPY.socialTranslationAging,
                AGING_BODY_CHANGE_LENS_BRIDGE.vsFatigue,
              ]
            : [
                BODY_MEANING_LENS_COPY.domainNote,
                BODY_MEANING_LENS_COPY.embodiedSignal,
                BODY_MEANING_LENS_COPY.needNotCraving,
                EMBODIED_DESIRE_SIGNAL_LENS_BRIDGE.desireModelNote,
              ]
        : []),
    ],
    relatedPatterns: buildRelatedPatterns(input),
  };

  // Soft guard: interpretation must stay in observation language.
  if (
    !assertObservationLanguage(result.interpretation) ||
    containsParallelLifeForbidden(result.interpretation) ||
    containsIntimacyForbidden(result.interpretation) ||
    containsScamForbidden(result.interpretation) ||
    containsEmploymentForbidden(result.interpretation) ||
    containsEducationForbidden(result.interpretation) ||
    containsBodyMeaningForbidden(result.interpretation)
  ) {
    result.interpretation =
      input.sourceObservatory === "body-meaning"
        ? "一つの仏教思想的な読み方として、このレンズでは身体信号・必要・意味づけ・欲の接続が見えてくる。医療断定や渇愛への還元ではなく、観測にとどめる。"
        : input.sourceObservatory === "education"
        ? "一つの仏教思想的な読み方として、このレンズでは欲求の意味形成と評価・credentialの接続が見えてくる。親の断罪や洗脳モデルではなく、観測にとどめる。"
        : input.sourceObservatory === "employment"
          ? "一つの仏教思想的な読み方として、このレンズでは欲求と制度的誘引・評価・保障の接続が見えてくる。career advice や欲の断罪ではなく、観測にとどめる。"
          : input.sourceObservatory === "scam"
            ? "一つの仏教思想的な読み方として、このレンズでは欲求と欺瞞・情報非対称・時間圧力の接続が見えてくる。被害者の欲を原因とせず、観測にとどめる。"
            : input.sourceObservatory === "intimacy"
              ? "一つの仏教思想的な読み方として、このレンズでは関係の中の欲と選択環境の接続が見えてくる。恋愛指南や断罪ではなく、観測にとどめる。"
              : "一つの仏教思想的な読み方として、このレンズでは固定的に見えていたものが条件の組み合わせとして見えてくる。Parallel Life の探索を否定せず、なぜ今その問いが残るのかを観測する。";
  }

  return result;
}
