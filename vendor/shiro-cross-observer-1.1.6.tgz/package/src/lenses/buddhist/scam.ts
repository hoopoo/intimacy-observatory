/**
 * Scam-specific Buddhist Lens copy and safeguards.
 * Observation only — not security advice, victim-blaming, or spiritual prevention.
 */

export const SCAM_LENS_COPY = {
  domainNote:
    "Scam では、欲が本人の行動を生むだけでなく、他者から観測・刺激・利用される接点になりうる可能性を見る。",
  desireNotFault:
    "Human Desire ≠ Fault。人間なら自然に持ちうる欲求を、被害の道徳的原因として扱わない。",
  actorAsymmetry:
    "Victim Desire と Attacker Intent は別物。道徳的に相殺・同列化しない。",
  intentionalHarmNote:
    "Intentional Harm（欺瞞・操作・搾取意図）と、platform / trust / isolation などの Enabling Conditions を分けて観測する。Composite Evil と同一視しない。",
  manipulableInterface:
    "欲は、自分を動かす動機であるだけでなく、他者がこちらへ作用するための接点にもなりうる。ただし全ての欲を vulnerability と定義しない。",
  notSecurityAdvice:
    "This lens does not replace fraud prevention, legal, financial, or security analysis.",
  notSpiritualPrevention:
    "瞑想・執着削減・心の整えを詐欺予防の代替として提示しない。",
} as const;

export const SCAM_FORBIDDEN_PHRASES: string[] = [
  "欲深かったから騙された",
  "執着があったから被害に遭った",
  "欲を捨てれば詐欺に遭わない",
  "被害者にも原因がある",
  "愛されたいという欲が弱点だった",
  "あなたの欲が原因",
  "あなたの執着が原因",
  "瞑想すれば詐欺を防げる",
  "執着を減らせば騙されない",
  "心を整えれば判断できる",
];

export const SCAM_REFLECTION_QUESTIONS: string[] = [
  "ここで利用されたのは、誰かの『弱さ』だろうか。それとも、人間なら持ちうる信頼したい・愛されたいという性質だろうか。",
  "『もっと得たい』だけでなく、『失いたくない』という欲求は、判断にどのように作用していただろうか。",
  "個人の判断力だけを見ることで、周囲の制度や接触環境を見落としていないだろうか。",
  "この状況で、誰の苦しみや生活条件が観測から抜け落ちているだろうか。",
];

export function pickScamReflectionQuestion(
  primaryConceptId: string,
  text: string,
): string {
  const hay = text.toLowerCase();
  if (
    /romance|親密|愛され|lonely|孤独|恋人|intimacy/.test(hay) ||
    primaryConceptId === "b05-craving"
  ) {
    return SCAM_REFLECTION_QUESTIONS[0]!;
  }
  if (
    /invest|投資|儲け|損|fomo|ponzi|老後/.test(hay) ||
    primaryConceptId === "b06-attachment"
  ) {
    return SCAM_REFLECTION_QUESTIONS[1]!;
  }
  if (
    /elderly|高齢|認知|介護|family imperson|オレオレ|voice/.test(hay) ||
    primaryConceptId === "b08-compassion" ||
    primaryConceptId === "b04-dependent-origination"
  ) {
    return SCAM_REFLECTION_QUESTIONS[2]!;
  }
  return SCAM_REFLECTION_QUESTIONS[3]!;
}

export function containsScamForbidden(text: string): boolean {
  return SCAM_FORBIDDEN_PHRASES.some((p) => text.includes(p));
}
