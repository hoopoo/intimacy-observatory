import type { RelatedPattern } from "../../../types/lens";

/**
 * Related Pattern — Embodied Desire Signal
 * Cross-domain structural sketch (not a diagnosis engine).
 *
 * Body Signal ≠ Need ≠ Desire ≠ Meaning.
 * Desire Model candidate interface: Embodied Desire.
 */

export const EMBODIED_DESIRE_SIGNAL_RELATED_PATTERN: RelatedPattern = {
  id: "embodied-desire-signal",
  name: "Embodied Desire Signal",
  nameJa: "身体信号としての欲",
  relationship: "related",
  description:
    "空腹・疲労・痛み・眠気などの身体信号が、必要・解釈・制度的圧力を経て欲へ変換されうる構造。身体的必要を自動的に渇愛と同一視しない。医療・臨床分析を代替しない。Buddhist concept ではない。",
};

export const EMBODIED_DESIRE_SIGNAL_LENS_BRIDGE = {
  embodiedSketch:
    "Body Signal → Need → Interpretation (+ Institution) → Desire → Decision → Behavior → Consequence → Body / Meaning → New Desire",
  needNotCraving:
    "Need（休息・治療・睡眠など）≠ Craving。意味・恐怖・identity・control が接続したときに渇愛として読める可能性を見る。",
  medicalBoundary:
    "This model does not replace medical or clinical analysis.",
  antiReductionism:
    "身体還元でも社会還元でも心理還元でもない。複数条件の絡まりとして観測する。",
  desireModelNote:
    "Desire Model v0.1 への Body Signal 明示追加は、追加観測を待って判断する候補（candidate A）。",
  boundary:
    "身体症状の原因帰属・治癒保証・自己管理断罪をしない。観測レイヤーにとどめる。",
  relationNote:
    "Buddhist Lens は身体経験に付与された意味・固定・苦・縁起・慈悲の層を読む。Desire Model は Body Signal → Need → Interpretation → Desire の構造変換を記述する。両者は同一ではない。",
} as const;
