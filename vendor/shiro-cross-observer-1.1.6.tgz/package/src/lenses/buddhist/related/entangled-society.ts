import type { RelatedPattern } from "../../../types/lens";

/**
 * B04 Dependent Origination ↔ Entangled Society
 * Related, not identical.
 */
export const ENTANGLED_SOCIETY_RELATED_PATTERN: RelatedPattern = {
  id: "entangled-society",
  name: "Entangled Society",
  nameJa: "絡み合う社会",
  relationship: "not-identical",
  description:
    "縁起は、現象を単独原因ではなく、条件と関係から見る思想的レンズである。Entangled Society は、現代社会における複雑な因果、相互作用、波及、分配される結果を観測する分析システムである。両者は近接する視点を持つが、同一の概念ではない。",
};

export const DEPENDENT_ORIGINATION_COPY = {
  conceptId: "b04-dependent-origination",
  lensView:
    "縁起という見方を使うと、単独の犯人や単一原因ではなく、条件と関係の組み合わせが見えてくる。",
  observatoryView:
    "Entangled Society は、actors / incentives / institutions / dependencies / secondary effects / externalities / distribution / feedback loops を社会観測として記録・分析する。",
  notIdenticalNote:
    "Dependent Origination ≠ Entangled Society。思想的レンズと分析システムを同一視しない。",
  desireNotSoleCause:
    "欲望は複数条件の一つとして観測できる。制度・技術・経済的誘因・政策・歴史・社会規範などと接続して結果が立ち上がる可能性を維持する。",
} as const;
