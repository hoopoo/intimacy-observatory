import type { RelatedPattern } from "../../../types/lens";

/**
 * Related Pattern — Aging Body Change
 * Distinct from reversible fatigue (Productive Body).
 * Desire optional. Not moral aging. Not medical advice.
 */

export const AGING_BODY_CHANGE_RELATED_PATTERN: RelatedPattern = {
  id: "aging-body-change",
  name: "Aging Body Change",
  nameJa: "老いとしての身体変化",
  relationship: "related",
  description:
    "時間による継続的・一部不可逆な身体変化が、Need（適応・支援）および／または Interpretation → Social Meaning → Desire / Avoidance へ分岐しうる構造。Body Change ≠ Desire。医学的・老年学的分析の代替ではない。",
};

export const AGING_BODY_CHANGE_LENS_BRIDGE = {
  branchingSketch:
    "Body Change → Need (adaptation/support)  and/or  Body Change → Interpretation → Social Meaning → Desire/Avoidance",
  vsFatigue:
    "Fatigue: relatively reversible Body Signal. Aging: time-based ongoing change. Same linear modelを無理に当てはめない。",
  bodyChangeNotDesire:
    "変化の存在は Desire を自動生成しない。Desire は optional。",
  socialTranslation:
    "Body Change → Age Label → Social Meaning → Expected Role → Desire/Avoidance（Social Translation of Aging）。",
  pastPresentBody:
    "Past Body / Memory / Present Body / Difference / Meaning / Desire — Parallel Life counterfactual と近接するが同一ではない。",
  desireFearBoundary:
    "『若くいたい』と『老いたくない』の境界を記録。Fear Model は未実装。",
  marketNote:
    "Aging anxiety → products/services を観測しうる。exploitation 断定や Manipulation 同一視をしない。",
  medicalBoundary:
    "This lens does not replace medical, clinical, or gerontological analysis.",
  noMoralAging:
    "自然に老いるのが正しい／アンチエイジングは浅い／若さを望むのは未熟——道徳階層を作らない。",
  boundary:
    "医学的原因断定・治療推奨・受け入れ説教・渇愛自動分類をしない。観測にとどめる。",
} as const;
