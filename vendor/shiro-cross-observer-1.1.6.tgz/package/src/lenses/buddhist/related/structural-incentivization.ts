import type { RelatedPattern } from "../../../types/lens";

/**
 * Structural Incentivization ↔ Buddhist Lens
 * Related Pattern for Employment — NOT a Buddhist concept.
 * Distinct from Intentional Manipulation (Scam).
 */
export const STRUCTURAL_INCENTIVIZATION_RELATED_PATTERN: RelatedPattern = {
  id: "structural-incentivization",
  name: "Structural Incentivization",
  nameJa: "構造的誘引",
  relationship: "related",
  description:
    "明確な操作意図がなくても、評価・報酬・ランキング・罰則・雇用条件などの制度的シグナルによって、人間の行動が特定方向へ調整される構造。Scam の Intentional Manipulation とは区別する。Buddhist concept ではない。",
};

export const STRUCTURAL_INCENTIVIZATION_LENS_BRIDGE = {
  relatedConceptIds: [
    "b05-craving",
    "b06-attachment",
    "b02-dukkha",
    "b04-dependent-origination",
    "b03-non-self",
    "b01-impermanence",
    "b08-compassion",
  ] as const,
  incentivizableSketch:
    "Human Desire → Institutional Signal → Incentive → Behavioral Adjustment → Performance → Evaluation → Reinforcement → New Desire / Fear",
  notManipulation:
    "Scam: Desire → Observed → Manipulated → Extraction。Employment: Desire → Measured → Incentivized → Directed → Evaluated → Reinforced。自動的に manipulation と呼ばない。",
  compositeEvilNote:
    "合理的な各Actorの欲が接続すると overwork / metric gaming / burnout 等が生まれる可能性はある（Composite Evil 隣接）。Employment = Composite Evil とはしない。",
  boundary:
    "KPI悪玉論・会社操作断定・欲の病理学化をしない。career advice の代替ではない。",
} as const;
