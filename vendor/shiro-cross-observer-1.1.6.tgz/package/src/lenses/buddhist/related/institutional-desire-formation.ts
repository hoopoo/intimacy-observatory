import type { RelatedPattern } from "../../../types/lens";

/**
 * Institutional Desire Formation ↔ Buddhist Lens
 * Related Pattern for Education — NOT a Buddhist concept.
 * Distinct from Manipulation (Scam) and Incentivization (Employment).
 */
export const INSTITUTIONAL_DESIRE_FORMATION_RELATED_PATTERN: RelatedPattern = {
  id: "institutional-desire-formation",
  name: "Institutional Desire Formation",
  nameJa: "制度的欲望形成",
  relationship: "related",
  description:
    "制度、評価、反復される社会的意味づけを通じて、何を成功・安心・価値ある未来として望むかが形成される可能性。Scam の Intentional Manipulation や Employment の Structural Incentivization とは区別する。Buddhist concept ではない。",
};

export const INSTITUTIONAL_DESIRE_FORMATION_LENS_BRIDGE = {
  relatedConceptIds: [
    "b05-craving",
    "b06-attachment",
    "b03-non-self",
    "b04-dependent-origination",
    "b02-dukkha",
    "b01-impermanence",
    "b08-compassion",
  ] as const,
  teachableSketch:
    "Human Potential / Need → Institutional Signal → Social Meaning → Repeated Evaluation → Internalized Goal → Desired Future",
  meaningTranslationSketch:
    "幸せになってほしい → 将来困らない → 良い教育 → 良い学校 / 海外経験 → 成績・credential・階級シグナル",
  notManipulation:
    "欺瞞・搾取意図としての manipulation ではない。社会的意味変換として観測する。",
  notMereIncentivization:
    "Employment の incentivization（既存の欲の方向づけ）と重なりうるが同一ではない。形成 / teaching の層を見る。",
  employmentBridge:
    "Education で形成された Desired Future / Credential が Employment の評価・報酬と接続しうる。Education exists only to produce employees とは定義しない。",
  boundary:
    "強制的形成モデル・社会決定論・親加害者化・評価悪玉論にしない。educational / parenting advice の代替ではない。",
} as const;
