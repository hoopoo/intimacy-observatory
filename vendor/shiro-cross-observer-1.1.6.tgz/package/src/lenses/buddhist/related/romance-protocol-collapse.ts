import type { RelatedPattern } from "../../../types/lens";

/**
 * Romance Protocol Collapse ↔ Buddhist Lens
 * Related Pattern only — not a Buddhist concept.
 */
export const ROMANCE_PROTOCOL_COLLAPSE_RELATED_PATTERN: RelatedPattern = {
  id: "romance-protocol-collapse",
  name: "Romance Protocol Collapse",
  nameJa: "恋愛プロトコルの崩れ",
  relationship: "related",
  description:
    "信頼コスト、条件比較、プラットフォーム設計、Composite Friction などにより、関係形成の社会的プロトコルが機能しにくくなる観測パターン。Infinite Choice Paradox / Decision Stack / Trust Cost Inflation / Optimization Fatigue と隣接する。Buddhist concept ではない。Buddhist Lens では渇愛・執着・苦・縁起という別レイヤーから読む。",
};

export const ROMANCE_PROTOCOL_LENS_BRIDGE = {
  relatedConceptIds: [
    "b02-dukkha",
    "b05-craving",
    "b06-attachment",
    "b04-dependent-origination",
  ] as const,
  structuralSketch:
    "Infinite Choice → More Possible Matches → Comparison → Fear of Missing Better Option → Continued Search → Optimization Fatigue",
  lensSketch: "Craving / Attachment / Dukkha / Dependent Origination（別レイヤー。原因断定ではない）",
  boundary:
    "Infinite Choice を渇愛と同一視しない。アプリ悪玉論や単因断定をしない。複数条件の隣接として扱う。",
} as const;
