import type { RelatedPattern } from "../../../types/lens";

/**
 * Related Pattern — Illness / Chronic Pain Disruption
 * Distinct from reversible fatigue and aging time-change.
 * Pain relief Need ≠ Craving. Not medical advice.
 */

export const ILLNESS_CHRONIC_PAIN_RELATED_PATTERN: RelatedPattern = {
  id: "illness-chronic-pain",
  name: "Illness / Chronic Pain Disruption",
  nameJa: "病気・慢性痛としての持続的身体破綻",
  relationship: "related",
  description:
    "反復・持続する身体破綻が、Need（緩和・支援・予測可能性）および／または Interpretation → Meaning / Fear / Identity → Desire / Avoidance へ分岐しうる構造。痛み緩和の Need を自動的に渇愛と同一視しない。医療・リハビリ・疼痛管理の代替ではない。",
};

export const ILLNESS_CHRONIC_PAIN_LENS_BRIDGE = {
  branchingSketch:
    "Body Disruption → Need (relief/support/adaptation)  and/or  Body Disruption → Interpretation → Meaning/Fear/Identity → Desire/Avoidance",
  vsFatigueAging:
    "Fatigue: relatively reversible signal. Aging: time-based change. Illness/Chronic Pain: persistent disruption that may interfere with daily role.",
  painReliefNotCraving:
    "Pain → Need for relief は身体的 Need として成立しうる。『完全に元通りでなければならない』には Memory / Identity / Fear / Social Meaning が加わりうる。",
  physicalVsMeaningSuffering:
    "Physical suffering（痛み・制限）と Meaning-related suffering（恐怖・比較・identity・不確実性）を可能なら分離する。",
  pastPresentFuture:
    "Past Body / Present Body / Expected Future Body — return desire, fear, hope, uncertainty。Parallel Life counterfactual と近接するが同一ではない。",
  desireFearBoundary:
    "『元気になりたい』『悪化したくない』『痛みを減らしたい』を同一 Desire に押し込まない。Fear Engine 未実装。",
  socialTranslation:
    "Illness → social label → role expectation → desire/avoidance（例: 休む→迷惑→無理して働きたい）。source にある場合のみ。",
  medicalBoundary:
    "This lens does not replace medical, clinical, rehabilitation, pain-management, or other professional analysis.",
  noRecoveryMoralism:
    "回復道徳（前向き強制・受容説教・諦め強制・『うまく付き合う』説教）の階層を作らない。",
  boundary:
    "診断・予後・治療推奨・心身症帰属・スピリチュアル原因帰属をしない。観測にとどめる。",
} as const;
