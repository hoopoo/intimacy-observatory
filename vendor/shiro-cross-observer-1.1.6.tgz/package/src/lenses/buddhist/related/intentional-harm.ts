import type { RelatedPattern } from "../../../types/lens";

/**
 * Intentional Harm + Enabling Conditions ↔ Buddhist Lens
 * Related structural note for Scam — NOT identical to Composite Evil.
 */
export const INTENTIONAL_HARM_RELATED_PATTERN: RelatedPattern = {
  id: "intentional-harm-enabling-conditions",
  name: "Intentional Harm + Enabling Conditions",
  nameJa: "意図的加害＋成立条件",
  relationship: "related",
  description:
    "明確な欺瞞・操作・搾取意図を持つ Actor が存在しうる一方、platform・trust・isolation・情報非対称・金融インフラなどの条件が周囲を構成する。Composite Evil（悪意なき合理的行動の接続）とは同一視しない。Buddhist concept ではない。",
};

export const INTENTIONAL_HARM_LENS_BRIDGE = {
  relatedConceptIds: [
    "b05-craving",
    "b06-attachment",
    "b02-dukkha",
    "b04-dependent-origination",
    "b08-compassion",
  ] as const,
  notCompositeEvil:
    "Composite Evil は『誰も全体を意図していない』接続を見る。Scam では Intentional Harm を構造論で薄めず、Enabling Conditions と並置する。",
  manipulableDesireSketch:
    "Desire → Observed/inferred → Stimulated → Manipulated → Decision pressure → Action → Loss/dependency → Meaning/shame",
  boundary:
    "被害者の欲を fault としない。意図的加害を Composite Evil に還元しない。",
} as const;
