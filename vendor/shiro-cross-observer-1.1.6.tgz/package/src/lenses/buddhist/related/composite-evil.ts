import type { RelatedPattern } from "../../../types/lens";

/**
 * Craving / Attachment / Dependent Origination ↔ Composite Evil
 * Related Pattern only — Composite Evil is NOT a Buddhist concept.
 */
export const COMPOSITE_EVIL_RELATED_PATTERN: RelatedPattern = {
  id: "composite-evil",
  name: "Composite Evil",
  nameJa: "合成悪",
  relationship: "related",
  description:
    "複数の合理的判断、善意、KPI、欲望が接続され、誰も全体を意図していないにもかかわらず、悪い結果が立ち上がることがある。Buddhist Lens では、この構造を縁起、渇愛、執着という観点から別の角度で観測する。両者は同一概念ではない。",
};

export const COMPOSITE_EVIL_LENS_BRIDGE = {
  relatedConceptIds: [
    "b05-craving",
    "b06-attachment",
    "b04-dependent-origination",
  ] as const,
  observation:
    "「悪人」がいなくても、複数の正常な欲望、合理的判断、KPI、制度、善意が接続すると、悪い結果が立ち上がることがある。",
  boundary:
    "これは仏教概念の定義ではなく、Clean Society における Related Pattern である。",
  uiHeading: "Related Pattern — Composite Evil",
} as const;
