/**
 * Employment-specific Buddhist Lens copy and safeguards.
 * Observation only — not career advice, pathology labeling, or company-blaming.
 */

export const EMPLOYMENT_LENS_COPY = {
  domainNote:
    "Employment では、明確な悪意がなくても、評価・KPI・報酬・安定保障などの制度的シグナルが人間の欲を方向づける可能性を見る。",
  desireNotPathology:
    "Desire ≠ Pathology。昇進欲・安定欲・評価欲を執着や欲深さと道徳評価しない。",
  incentivizableInterface:
    "欲は、制度的シグナルによって測定・誘引・方向づけ・強化される接点にもなりうる（Desire as Incentivizable Interface）。",
  structuralIncentivization:
    "Structural Incentivization: 操作意図がなくても、評価・報酬・ランキング・雇用条件が行動を特定方向へ調整しうる。",
  notManipulation:
    "Employment を Scam の弱い版として扱わない。まず incentive architecture として観測し、自動的に manipulation と呼ばない。",
  actorAsymmetry:
    "Employee と Company の欲を対称に扱いすぎない。Bargaining power / income dependency / termination authority の非対称がありうる。",
  kpiNotEvil:
    "KPI そのものを悪としない。alignment / accountability の機能もありうる。接続を観測する。",
  notCareerAdvice:
    "This lens does not replace employment, career, labor, or organizational analysis.",
} as const;

export const EMPLOYMENT_FORBIDDEN_PHRASES: string[] = [
  "昇進欲は執着",
  "高い給与を求めるのは欲深い",
  "評価されたいから苦しむ",
  "欲を捨てれば仕事は楽になる",
  "会社を辞めれば解決する",
  "執着したあなたが悪い",
  "仕事への欲を捨てればいい",
  "KPIは悪",
  "評価制度は人を壊す",
  "会社が社員を操作している",
];

export const EMPLOYMENT_REFLECTION_QUESTIONS: string[] = [
  "自分が本当に望んでいるものと、評価制度や保障パッケージによって望むようになったものは、どこまで同じだろうか。",
  "評価されたいという欲求は、自分の仕事を支えているだろうか。それとも、評価されること自体を仕事の目的に変えているだろうか。",
  "安定を求めているのは個人の性格だろうか。それとも、社会が安定を組織の内側に置いているからだろうか。",
  "この評価や報酬の設計から、誰の負担や生活条件が抜け落ちているだろうか。",
];

export function pickEmploymentReflectionQuestion(
  primaryConceptId: string,
  text: string,
): string {
  const hay = text.toLowerCase();
  if (
    /保障|安定|benefit|package|住宅|医療|退職|hidden.?compensation/.test(
      hay,
    )
  ) {
    return EMPLOYMENT_REFLECTION_QUESTIONS[2]!;
  }
  if (
    /kpi|評価|昇進|promotion|ranking|給与|報酬/.test(hay) ||
    primaryConceptId === "b05-craving"
  ) {
    return EMPLOYMENT_REFLECTION_QUESTIONS[1]!;
  }
  if (
    primaryConceptId === "b08-compassion" ||
    /介護|burnout|layoff|解雇|障害者|契約/.test(hay)
  ) {
    return EMPLOYMENT_REFLECTION_QUESTIONS[3]!;
  }
  return EMPLOYMENT_REFLECTION_QUESTIONS[0]!;
}

export function containsEmploymentForbidden(text: string): boolean {
  return EMPLOYMENT_FORBIDDEN_PHRASES.some((p) => text.includes(p));
}
