export const BUDDHIST_LENS_COPY = {
  header: "Buddhist Lens",
  subheading: "仏教という観測地点から世界を見る",
  description:
    "仏教を答えとして使うのではなく、無常、苦、無我、縁起、渇愛、執着、空、慈悲という概念から、同じ出来事をもう一度見る。",
  keyStatement:
    "欲を消すのではなく、欲に動かされている自分と社会を観測する。",
  secondaryStatement:
    "欲がなくなることではなく、欲が生じても、それに完全に支配されない状態を考える。",
  positioning: "Buddhism as Lens",
  positioningJa:
    "仏教を答えとして使うのではなく、世界の別の見え方として使う。",
  viewThroughLens: {
    en: "View through a lens",
    ja: "別のレンズから見る",
  },
  viewThroughBuddhist: {
    en: "Buddhist Lens",
    ja: "仏教という観測地点から見る",
  },
} as const;
