import type { LensInput } from "../types/lens";
import type { SupportedObservatoryId } from "../types/observatory";
import {
  createLensInput,
  type AdaptableObservation,
  type ObservatoryAdapter,
} from "./types";

function makeAdapter(
  observatoryId: SupportedObservatoryId,
): ObservatoryAdapter {
  return {
    observatoryId,
    toLensInput: (observation) => createLensInput(observatoryId, observation),
  };
}

/** Adapters for all target Observatories — ready for incremental UI wiring. */
export const parallelLifeAdapter = makeAdapter("parallel-life");
export const scamAdapter = makeAdapter("scam");
export const employmentAdapter = makeAdapter("employment");
export const educationAdapter = makeAdapter("education");
export const cleanSocietyAdapter = makeAdapter("clean-society");
export const entangledSocietyAdapter = makeAdapter("entangled-society");
export const intimacyAdapter = makeAdapter("intimacy");
export const marketSignalsAdapter = makeAdapter("market-signals");
export const bodyMeaningAdapter = makeAdapter("body-meaning");
export const literatureAdapter = makeAdapter("literature");

export const ADAPTERS_BY_OBSERVATORY: Record<
  SupportedObservatoryId,
  ObservatoryAdapter
> = {
  "parallel-life": parallelLifeAdapter,
  scam: scamAdapter,
  employment: employmentAdapter,
  education: educationAdapter,
  "clean-society": cleanSocietyAdapter,
  "entangled-society": entangledSocietyAdapter,
  intimacy: intimacyAdapter,
  "market-signals": marketSignalsAdapter,
  "body-meaning": bodyMeaningAdapter,
  literature: literatureAdapter,
};

export function adaptObservation(
  observatoryId: SupportedObservatoryId,
  observation: AdaptableObservation,
): LensInput {
  return ADAPTERS_BY_OBSERVATORY[observatoryId].toLensInput(observation);
}

export type { AdaptableObservation, ObservatoryAdapter };
export { createLensInput };

/**
 * Domain-shaped helpers for UI-integrated Observatories.
 * These accept richer local shapes without leaking into the Lens core.
 */

export {
  parallelLifeToLensInput,
  adaptParallelLife,
  type ParallelLifeObservation,
} from "./parallel-life";

export {
  cleanSocietyToLensInput,
  adaptCleanSociety,
  type CleanSocietyObservation,
} from "./clean-society";

export {
  entangledSocietyToLensInput,
  adaptEntangledSociety,
  type EntangledSocietyObservation,
} from "./entangled-society";

export {
  intimacyToLensInput,
  type IntimacyObservation,
} from "./intimacy";

export {
  scamToLensInput,
  type ScamObservation,
} from "./scam";

export {
  employmentToLensInput,
  type EmploymentObservation,
} from "./employment";

export {
  educationToLensInput,
  type EducationObservation,
} from "./education";

export {
  bodyMeaningToLensInput,
  adaptBodyMeaning,
  type BodyMeaningObservation,
} from "./body-meaning";
