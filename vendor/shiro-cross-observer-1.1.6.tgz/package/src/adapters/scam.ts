import type { LensInput } from "../types/lens";
import { createLensInput } from "./types";

/**
 * Production-facing Scam observation shape.
 * Host maps page models into this; Lens core stays observatory-agnostic.
 *
 * Victim Desire ≠ Attacker Intent — keep asymmetry in metadata/context.
 */
export type ScamObservation = {
  id?: string;
  slug?: string;
  title: string;
  titleEn?: string;
  text: string;
  context?: string;
  scamType?: string;
  target?: string;
  attacker?: string;
  channel?: string;
  manipulationTechniques?: string[];
  trustSignals?: string[];
  urgencySignals?: string[];
  financialSignals?: string[];
  platform?: string;
  vulnerabilityContext?: string;
  intentionalHarm?: boolean;
  metadata?: Record<string, unknown>;
};

/**
 * ScamObservation → common LensInput.
 * Does not mutate the source observation.
 */
export function scamToLensInput(observation: ScamObservation): LensInput {
  const title = observation.titleEn
    ? `${observation.titleEn}／${observation.title}`
    : observation.title;

  const contextParts = [
    observation.context,
    observation.scamType ? `Scam type: ${observation.scamType}` : undefined,
    observation.target ? `Target context: ${observation.target}` : undefined,
    observation.attacker
      ? `Attacker-side signals (intent/control — not victim desire): ${observation.attacker}`
      : undefined,
    observation.channel ? `Channel: ${observation.channel}` : undefined,
    observation.platform ? `Platform: ${observation.platform}` : undefined,
    observation.vulnerabilityContext
      ? `Enabling / vulnerability context: ${observation.vulnerabilityContext}`
      : undefined,
    observation.manipulationTechniques &&
    observation.manipulationTechniques.length > 0
      ? `Manipulation techniques: ${observation.manipulationTechniques.join(", ")}`
      : undefined,
    observation.trustSignals && observation.trustSignals.length > 0
      ? `Trust signals: ${observation.trustSignals.join(", ")}`
      : undefined,
    observation.urgencySignals && observation.urgencySignals.length > 0
      ? `Urgency signals: ${observation.urgencySignals.join(", ")}`
      : undefined,
    observation.financialSignals && observation.financialSignals.length > 0
      ? `Financial signals: ${observation.financialSignals.join(", ")}`
      : undefined,
    observation.intentionalHarm
      ? "Related structural note: Intentional Harm + Enabling Conditions (not identical to Clean Society Composite Evil pattern)"
      : undefined,
    "Victim Desire and Attacker Intent are distinct. Do not moralize victim desire as fault.",
    "This Lens does not replace fraud prevention, legal, financial, or security analysis.",
  ].filter((part): part is string => Boolean(part && part.trim()));

  return createLensInput("scam", {
    id: observation.id ?? observation.slug,
    title,
    text: observation.text,
    context: contextParts.join("\n"),
    metadata: {
      ...observation.metadata,
      kind: "scam-observation",
      slug: observation.slug,
      scamType: observation.scamType,
      intentionalHarm: observation.intentionalHarm ?? true,
    },
  });
}
