import type { LensInput } from "../types/lens";
import { createLensInput } from "./types";

/**
 * Production-facing Education observation shape.
 * Host maps page models into this; Lens core stays observatory-agnostic.
 *
 * Desire Formation / Teachable Interface ≠ Incentivization (Employment)
 * ≠ Manipulation (Scam). Parent Desire ≠ Pathology.
 */
export type EducationObservation = {
  id?: string;
  slug?: string;
  title: string;
  titleEn?: string;
  text: string;
  context?: string;
  actors?: string[];
  evaluationSignals?: string[];
  grades?: string[];
  ranking?: string;
  admissions?: string[];
  credentials?: string[];
  parentExpectations?: string[];
  peerComparison?: string[];
  learningGoals?: string[];
  careerSignals?: string[];
  employmentConnection?: string;
  institutionalRewards?: string[];
  metadata?: Record<string, unknown>;
};

/**
 * EducationObservation → common LensInput.
 * Does not mutate the source observation.
 */
export function educationToLensInput(
  observation: EducationObservation,
): LensInput {
  const title = observation.titleEn
    ? `${observation.titleEn}／${observation.title}`
    : observation.title;

  const contextParts = [
    observation.context,
    observation.actors && observation.actors.length > 0
      ? `Actors: ${observation.actors.join(", ")}`
      : undefined,
    observation.learningGoals && observation.learningGoals.length > 0
      ? `Learning goals: ${observation.learningGoals.join(", ")}`
      : undefined,
    observation.evaluationSignals && observation.evaluationSignals.length > 0
      ? `Evaluation signals: ${observation.evaluationSignals.join(", ")}`
      : undefined,
    observation.grades && observation.grades.length > 0
      ? `Grades / scores: ${observation.grades.join(", ")}`
      : undefined,
    observation.ranking ? `Ranking: ${observation.ranking}` : undefined,
    observation.admissions && observation.admissions.length > 0
      ? `Admissions: ${observation.admissions.join(", ")}`
      : undefined,
    observation.credentials && observation.credentials.length > 0
      ? `Credentials: ${observation.credentials.join(", ")}`
      : undefined,
    observation.parentExpectations &&
    observation.parentExpectations.length > 0
      ? `Parent expectations (natural care, not pathology): ${observation.parentExpectations.join(", ")}`
      : undefined,
    observation.peerComparison && observation.peerComparison.length > 0
      ? `Peer comparison: ${observation.peerComparison.join(", ")}`
      : undefined,
    observation.careerSignals && observation.careerSignals.length > 0
      ? `Career signals: ${observation.careerSignals.join(", ")}`
      : undefined,
    observation.employmentConnection
      ? `Education→Employment connection (not identity): ${observation.employmentConnection}`
      : undefined,
    observation.institutionalRewards &&
    observation.institutionalRewards.length > 0
      ? `Institutional rewards / meaning: ${observation.institutionalRewards.join(", ")}`
      : undefined,
    "Related structural note: Institutional Desire Formation (not Manipulation; not mere Incentivization).",
    "Parent desire to make a child happy is understandable; observe how it may be translated into school/credential metrics.",
    "Child agency (curiosity, resistance, preference) remains possible alongside institutional signals.",
    "This lens does not replace educational, developmental, career, or parenting analysis.",
  ].filter((part): part is string => Boolean(part && part.trim()));

  return createLensInput("education", {
    id: observation.id ?? observation.slug,
    title,
    text: observation.text,
    context: contextParts.join("\n"),
    metadata: {
      ...observation.metadata,
      kind: "education-observation",
      slug: observation.slug,
      employmentConnection: observation.employmentConnection,
    },
  });
}
