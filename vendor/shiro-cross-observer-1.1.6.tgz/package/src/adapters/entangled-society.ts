import type { LensInput } from "../types/lens";
import { createLensInput } from "./types";

/**
 * Production-facing Entangled Society observation shape.
 * Host apps map EntangledEntry / simulation summaries into this;
 * Lens core stays observatory-agnostic.
 */
export type EntangledSocietyObservation = {
  id?: string;
  slug?: string;
  title: string;
  titleJa?: string;
  /** Primary observation text assembled from existing entry fields only. */
  text: string;
  context?: string;
  metadata?: Record<string, unknown>;
};

/**
 * EntangledSocietyObservation → common LensInput.
 * Does not mutate the source observation.
 */
export function entangledSocietyToLensInput(
  observation: EntangledSocietyObservation,
): LensInput {
  const title = observation.titleJa
    ? `${observation.title}／${observation.titleJa}`
    : observation.title;

  return createLensInput("entangled-society", {
    id: observation.id ?? observation.slug,
    title,
    text: observation.text,
    context: observation.context,
    metadata: {
      ...observation.metadata,
      slug: observation.slug,
      kind: "entangled-entry",
      host: "entangled-society",
    },
  });
}

/** @deprecated Prefer entangledSocietyToLensInput */
export function adaptEntangledSociety(observation: {
  id?: string;
  title: string;
  entryText: string;
  entanglementNote?: string;
  metadata?: Record<string, unknown>;
}): LensInput {
  return entangledSocietyToLensInput({
    id: observation.id,
    title: observation.title,
    text: observation.entryText,
    context: observation.entanglementNote,
    metadata: observation.metadata,
  });
}
