import type { LensInput } from "../types/lens";
import { createLensInput } from "./types";

/**
 * Production-facing Body Meaning observation shape.
 * Host maps page models into this; Lens core stays observatory-agnostic.
 *
 * Body Signal ≠ Need ≠ Desire ≠ Meaning.
 * Need ≠ Craving. Health desire ≠ pathology. Not medical diagnosis.
 */
export type BodyMeaningObservation = {
  id?: string;
  slug?: string;
  title: string;
  titleEn?: string;
  text: string;
  context?: string;
  /** Observational case tag — does not change Lens schema. */
  caseKind?: "productive-body" | "aging" | "illness" | "general";
  /** Raw bodily states (not yet desire). Fatigue-style signals. */
  bodySignals?: string[];
  /** Time-based / ongoing body changes (aging) — not automatically desire. */
  bodyChanges?: string[];
  /** Persistent disruption (illness / chronic pain) — not automatically desire. */
  bodyDisruptions?: string[];
  /** Lived necessities arising from body / situation. */
  needs?: string[];
  /** Oriented wanting after interpretation — optional. */
  desires?: string[];
  /** Avoidance / fear-adjacent orientations (not a Fear Model). */
  fearAvoidances?: string[];
  /** Social / self meanings attached to body states. */
  meanings?: string[];
  institutionalPressures?: string[];
  actors?: string[];
  medicalBoundaryNote?: string;
  metadata?: Record<string, unknown>;
};

function caseNote(caseKind: BodyMeaningObservation["caseKind"]): string {
  if (caseKind === "aging") {
    return "Aging case: time-based body change ≠ reversible fatigue. Body Change → Need and/or Interpretation → Social Meaning → Desire (desire optional).";
  }
  if (caseKind === "illness") {
    return "Illness / Chronic Pain case: persistent bodily disruption ≠ reversible fatigue ≠ age-based time change. Body Disruption → Need and/or Interpretation → Meaning/Fear/Identity → Desire/Avoidance (desire optional). Pain relief Need ≠ Craving by default.";
  }
  if (caseKind === "productive-body") {
    return "Desire as Embodied Signal: body signal may convert toward need → interpretation → desire; not sole social construction.";
  }
  return "Desire as Embodied Signal: body signal may convert toward need → interpretation → desire; not sole social construction.";
}

function medicalNote(
  caseKind: BodyMeaningObservation["caseKind"],
  override?: string,
): string {
  if (override) return override;
  if (caseKind === "aging") {
    return "This lens does not replace medical, clinical, or gerontological analysis.";
  }
  if (caseKind === "illness") {
    return "This lens does not replace medical, clinical, rehabilitation, pain-management, or other professional analysis.";
  }
  return "This model does not replace medical or clinical analysis.";
}

/**
 * BodyMeaningObservation → common LensInput.
 * Does not mutate the source observation.
 */
export function bodyMeaningToLensInput(
  observation: BodyMeaningObservation,
): LensInput {
  const title = observation.titleEn
    ? `${observation.titleEn}／${observation.title}`
    : observation.title;

  const contextParts = [
    observation.context,
    observation.caseKind
      ? `Body Meaning case: ${observation.caseKind}`
      : undefined,
    observation.actors && observation.actors.length > 0
      ? `Actors: ${observation.actors.join(", ")}`
      : undefined,
    observation.bodySignals && observation.bodySignals.length > 0
      ? `Body signals (not desire): ${observation.bodySignals.join(", ")}`
      : undefined,
    observation.bodyChanges && observation.bodyChanges.length > 0
      ? `Body changes (not automatically desire): ${observation.bodyChanges.join(", ")}`
      : undefined,
    observation.bodyDisruptions && observation.bodyDisruptions.length > 0
      ? `Body disruptions (persistent; not automatically desire): ${observation.bodyDisruptions.join(", ")}`
      : undefined,
    observation.needs && observation.needs.length > 0
      ? `Needs (not craving by default): ${observation.needs.join(", ")}`
      : undefined,
    observation.desires && observation.desires.length > 0
      ? `Desires (after interpretation; optional): ${observation.desires.join(", ")}`
      : undefined,
    observation.fearAvoidances && observation.fearAvoidances.length > 0
      ? `Fear / avoidance orientations (research boundary, not Fear Engine): ${observation.fearAvoidances.join(", ")}`
      : undefined,
    observation.meanings && observation.meanings.length > 0
      ? `Meanings attached to body: ${observation.meanings.join(", ")}`
      : undefined,
    observation.institutionalPressures &&
    observation.institutionalPressures.length > 0
      ? `Institutional / performance pressures: ${observation.institutionalPressures.join(", ")}`
      : undefined,
    caseNote(observation.caseKind),
    medicalNote(observation.caseKind, observation.medicalBoundaryNote),
    "Anti-reductionism: body + biology + meaning + society + history + chance.",
  ].filter((part): part is string => Boolean(part && String(part).trim()));

  return createLensInput("body-meaning", {
    id: observation.id ?? observation.slug,
    title,
    text: observation.text,
    context: contextParts.join("\n"),
    metadata: {
      ...observation.metadata,
      caseKind: observation.caseKind,
      bodySignals: observation.bodySignals,
      bodyChanges: observation.bodyChanges,
      bodyDisruptions: observation.bodyDisruptions,
      needs: observation.needs,
      desires: observation.desires,
      fearAvoidances: observation.fearAvoidances,
      meanings: observation.meanings,
    },
  });
}

/** @deprecated Prefer bodyMeaningToLensInput */
export const adaptBodyMeaning = bodyMeaningToLensInput;
