import type { LensInput } from "../types/lens";
import { createLensInput } from "./types";

/**
 * Production-facing Intimacy observation shape.
 * Host maps page models into this; Lens core stays observatory-agnostic.
 */
export type IntimacyObservation = {
  id?: string;
  slug?: string;
  title: string;
  titleEn?: string;
  text: string;
  context?: string;
  patterns?: string[];
  actors?: string[];
  choiceStructure?: string;
  trustCost?: string;
  optimizationSignals?: string[];
  relationshipContext?: string;
  mentionsRomanceProtocolCollapse?: boolean;
  metadata?: Record<string, unknown>;
};

/**
 * IntimacyObservation → common LensInput.
 * Does not mutate the source observation.
 */
export function intimacyToLensInput(
  observation: IntimacyObservation,
): LensInput {
  const title = observation.titleEn
    ? `${observation.titleEn}／${observation.title}`
    : observation.title;

  const contextParts = [
    observation.context,
    observation.relationshipContext
      ? `Relationship context: ${observation.relationshipContext}`
      : undefined,
    observation.choiceStructure
      ? `Choice structure: ${observation.choiceStructure}`
      : undefined,
    observation.trustCost ? `Trust cost: ${observation.trustCost}` : undefined,
    observation.patterns && observation.patterns.length > 0
      ? `Patterns: ${observation.patterns.join(", ")}`
      : undefined,
    observation.optimizationSignals &&
    observation.optimizationSignals.length > 0
      ? `Optimization signals: ${observation.optimizationSignals.join(", ")}`
      : undefined,
    observation.actors && observation.actors.length > 0
      ? `Actors: ${observation.actors.join(", ")}`
      : undefined,
    observation.mentionsRomanceProtocolCollapse
      ? "Related pattern context: Romance Protocol Collapse (not a Buddhist concept)"
      : undefined,
    "Intimacy analysis is separate from this Lens reading.",
    "Do not treat desire as pathology or moral failure.",
  ].filter((part): part is string => Boolean(part && part.trim()));

  return createLensInput("intimacy", {
    id: observation.id ?? observation.slug,
    title,
    text: observation.text,
    context: contextParts.join("\n"),
    metadata: {
      ...observation.metadata,
      kind: "intimacy-observation",
      slug: observation.slug,
      patterns: observation.patterns,
      mentionsRomanceProtocolCollapse:
        observation.mentionsRomanceProtocolCollapse ?? false,
    },
  });
}
