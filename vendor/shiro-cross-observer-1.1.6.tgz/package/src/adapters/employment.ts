import type { LensInput } from "../types/lens";
import { createLensInput } from "./types";

/**
 * Production-facing Employment observation shape.
 * Host maps page models into this; Lens core stays observatory-agnostic.
 *
 * Structural Incentivization ≠ Intentional Manipulation (Scam).
 * Employee Desire ≠ Company Goals — keep asymmetry; do not moralize.
 */
export type EmploymentObservation = {
  id?: string;
  slug?: string;
  title: string;
  titleEn?: string;
  text: string;
  context?: string;
  actors?: string[];
  employeeGoals?: string[];
  managerGoals?: string[];
  companyGoals?: string[];
  incentives?: string[];
  kpis?: string[];
  compensation?: string;
  promotionSignals?: string[];
  jobSecuritySignals?: string[];
  rankingSignals?: string[];
  laborMarketContext?: string;
  automationContext?: string;
  mentionsCompositeEvil?: boolean;
  metadata?: Record<string, unknown>;
};

/**
 * EmploymentObservation → common LensInput.
 * Does not mutate the source observation.
 */
export function employmentToLensInput(
  observation: EmploymentObservation,
): LensInput {
  const title = observation.titleEn
    ? `${observation.titleEn}／${observation.title}`
    : observation.title;

  const contextParts = [
    observation.context,
    observation.actors && observation.actors.length > 0
      ? `Actors: ${observation.actors.join(", ")}`
      : undefined,
    observation.employeeGoals && observation.employeeGoals.length > 0
      ? `Employee-side goals (not pathology): ${observation.employeeGoals.join(", ")}`
      : undefined,
    observation.managerGoals && observation.managerGoals.length > 0
      ? `Manager-side goals: ${observation.managerGoals.join(", ")}`
      : undefined,
    observation.companyGoals && observation.companyGoals.length > 0
      ? `Company-side goals: ${observation.companyGoals.join(", ")}`
      : undefined,
    observation.incentives && observation.incentives.length > 0
      ? `Incentives: ${observation.incentives.join(", ")}`
      : undefined,
    observation.kpis && observation.kpis.length > 0
      ? `KPI / evaluation signals: ${observation.kpis.join(", ")}`
      : undefined,
    observation.compensation
      ? `Compensation context: ${observation.compensation}`
      : undefined,
    observation.promotionSignals && observation.promotionSignals.length > 0
      ? `Promotion signals: ${observation.promotionSignals.join(", ")}`
      : undefined,
    observation.jobSecuritySignals &&
    observation.jobSecuritySignals.length > 0
      ? `Job security signals: ${observation.jobSecuritySignals.join(", ")}`
      : undefined,
    observation.rankingSignals && observation.rankingSignals.length > 0
      ? `Ranking signals: ${observation.rankingSignals.join(", ")}`
      : undefined,
    observation.laborMarketContext
      ? `Labor market: ${observation.laborMarketContext}`
      : undefined,
    observation.automationContext
      ? `Automation context: ${observation.automationContext}`
      : undefined,
    observation.mentionsCompositeEvil
      ? "Related pattern context: Composite Evil (not identical to Employment / Structural Incentivization)"
      : undefined,
    "Related structural note: Structural Incentivization (not Intentional Manipulation / Scam).",
    "Employee and Company desires are not morally equivalent; bargaining power may be asymmetric.",
    "This Lens does not replace employment, career, labor, or organizational analysis.",
  ].filter((part): part is string => Boolean(part && part.trim()));

  return createLensInput("employment", {
    id: observation.id ?? observation.slug,
    title,
    text: observation.text,
    context: contextParts.join("\n"),
    metadata: {
      ...observation.metadata,
      kind: "employment-observation",
      slug: observation.slug,
      mentionsCompositeEvil: observation.mentionsCompositeEvil ?? false,
    },
  });
}
