import type { LensInput } from "../types/lens";
import { createLensInput } from "./types";

/**
 * Production-facing Clean Society observation shape.
 * Host apps map their page models into this; Lens core stays observatory-agnostic.
 */
export type CleanSocietyObservation = {
  id?: string;
  title: string;
  /** Primary observation text for the lens (non-destructive copy of source material). */
  text: string;
  context?: string;
  /** When true, Composite Evil related pattern bridging is enabled. */
  mentionsCompositeEvil?: boolean;
  metadata?: Record<string, unknown>;
};

/**
 * CleanSocietyObservation → common LensInput.
 * Does not mutate the source observation.
 */
export function cleanSocietyToLensInput(
  observation: CleanSocietyObservation,
): LensInput {
  const contextParts = [
    observation.context,
    observation.mentionsCompositeEvil
      ? "Related pattern context: Composite Evil / 合成悪"
      : undefined,
  ].filter((part): part is string => Boolean(part && part.trim()));

  return createLensInput("clean-society", {
    id: observation.id,
    title: observation.title,
    text: observation.text,
    context: contextParts.length > 0 ? contextParts.join("\n") : undefined,
    metadata: {
      ...observation.metadata,
      mentionsCompositeEvil: observation.mentionsCompositeEvil ?? false,
    },
  });
}

/** @deprecated Prefer cleanSocietyToLensInput — kept for earlier demo helpers. */
export function adaptCleanSociety(
  observation: {
    id?: string;
    title: string;
    caseText: string;
    mentionsCompositeEvil?: boolean;
    metadata?: Record<string, unknown>;
  },
): LensInput {
  return cleanSocietyToLensInput({
    id: observation.id,
    title: observation.title,
    text: observation.caseText,
    mentionsCompositeEvil: observation.mentionsCompositeEvil,
    metadata: observation.metadata,
  });
}
