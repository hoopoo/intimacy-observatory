import type { LensInput } from "../types/lens";
import type { SupportedObservatoryId } from "../types/observatory";

/**
 * Minimal observation shape that adapters accept.
 * Observatory-specific models should map into this (or a narrower adapter input).
 */
export type AdaptableObservation = {
  id?: string;
  title?: string;
  text: string;
  context?: string;
  metadata?: Record<string, unknown>;
};

export type ObservatoryAdapter<T = AdaptableObservation> = {
  observatoryId: SupportedObservatoryId;
  toLensInput: (observation: T) => LensInput;
};

export function createLensInput(
  observatoryId: SupportedObservatoryId,
  observation: AdaptableObservation,
): LensInput {
  return {
    sourceObservatory: observatoryId,
    sourceObservationId: observation.id,
    title: observation.title,
    text: observation.text,
    context: observation.context,
    metadata: observation.metadata,
  };
}
