import type { LensInput } from "../types/lens";
import { createLensInput } from "./types";

/**
 * Production-facing Parallel Life observation shape.
 * Host maps Protocol result / session fields into this;
 * Lens core stays observatory-agnostic.
 */
export type ParallelLifeObservation = {
  id?: string;
  title?: string;
  /** Primary text: branch question / source text / branch point. */
  text: string;
  context?: string;
  branchAge?: string;
  branchPoint?: string;
  chosenPath?: string;
  unchosenPath?: string;
  userQuestion?: string;
  residue?: string;
  relatedDomains?: string[];
  metadata?: Record<string, unknown>;
};

/**
 * ParallelLifeObservation → common LensInput.
 * Does not mutate the source observation.
 * Does not invent counterfactual outcomes.
 */
export function parallelLifeToLensInput(
  observation: ParallelLifeObservation,
): LensInput {
  const contextParts = [
    observation.context,
    observation.branchAge ? `Branch age: ${observation.branchAge}` : undefined,
    observation.branchPoint
      ? `Branch point: ${observation.branchPoint}`
      : undefined,
    observation.chosenPath ? `Chosen path: ${observation.chosenPath}` : undefined,
    observation.unchosenPath
      ? `Unchosen path: ${observation.unchosenPath}`
      : undefined,
    observation.userQuestion
      ? `Present question: ${observation.userQuestion}`
      : undefined,
    observation.residue ? `Residue: ${observation.residue}` : undefined,
    observation.relatedDomains && observation.relatedDomains.length > 0
      ? `Related domains: ${observation.relatedDomains.join(", ")}`
      : undefined,
    "Parallel Life Protocol analysis is separate from this Lens reading.",
    "Do not treat unchosen lives as fixed counterfactual facts.",
  ].filter((part): part is string => Boolean(part && part.trim()));

  return createLensInput("parallel-life", {
    id: observation.id,
    title: observation.title ?? "Parallel Life branch",
    text: observation.text,
    context: contextParts.join("\n"),
    metadata: {
      ...observation.metadata,
      kind: "parallel-life-branch",
      branchAge: observation.branchAge,
      branchPoint: observation.branchPoint,
      chosenPath: observation.chosenPath,
      unchosenPath: observation.unchosenPath,
      userQuestion: observation.userQuestion,
      relatedDomains: observation.relatedDomains,
    },
  });
}

/** @deprecated Prefer parallelLifeToLensInput */
export function adaptParallelLife(observation: {
  id?: string;
  branchQuestion: string;
  lifeContext?: string;
  metadata?: Record<string, unknown>;
}): LensInput {
  return parallelLifeToLensInput({
    id: observation.id,
    text: observation.branchQuestion,
    context: observation.lifeContext,
    metadata: observation.metadata,
  });
}
