"use client";

import { useState } from "react";
import type { LensInput } from "../types/lens";
import { applyLens } from "../engine/apply-lens";
import { ViewThroughLens } from "./ViewThroughLens";
import { LensViewer } from "./LensViewer";
import "./lens-panel.css";

type Props = {
  input: LensInput;
  className?: string;
};

/**
 * Drop-in panel for Observatory detail pages.
 * Keeps original observation untouched; shows derived LensResult on demand.
 * Lens options come from the Lens Registry — not hard-coded.
 */
export function LensPanel({ input, className = "" }: Props) {
  const [selectedLensId, setSelectedLensId] = useState<string | null>(null);
  const outcome =
    selectedLensId !== null ? applyLens(selectedLensId, input) : null;

  return (
    <div className={`lens-panel ${className}`.trim()}>
      <ViewThroughLens
        selectedLensId={selectedLensId}
        onSelectLens={(lens) =>
          setSelectedLensId((current) =>
            current === lens.id ? null : lens.id,
          )
        }
      />

      {outcome?.ok ? (
        <LensViewer input={outcome.originalInput} result={outcome.result} />
      ) : null}

      {outcome && !outcome.ok ? (
        <p className="lens-panel__error" role="alert">
          {outcome.message}
        </p>
      ) : null}
    </div>
  );
}
