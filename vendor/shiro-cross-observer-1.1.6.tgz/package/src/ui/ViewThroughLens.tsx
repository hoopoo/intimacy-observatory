"use client";

import { listActiveLenses } from "../registry/lens-registry";
import type { LensDefinition } from "../types/lens";

type Props = {
  /** Currently selected lens id, or null when closed. */
  selectedLensId?: string | null;
  onSelectLens?: (lens: LensDefinition) => void;
  className?: string;
};

/**
 * Shared entry control: "View through a lens".
 * Renders active lenses from the Lens Registry (no hard-coded lens ids).
 */
export function ViewThroughLens({
  selectedLensId = null,
  onSelectLens,
  className = "",
}: Props) {
  const lenses = listActiveLenses();

  return (
    <section
      className={`lens-entry ${className}`.trim()}
      aria-label="Lens layer"
    >
      <p className="annotation lens-entry__label">View through a lens</p>
      <p className="lens-entry__label-ja">別のレンズから見る</p>

      <ul className="lens-entry__list">
        {lenses.map((lens) => {
          const selected = selectedLensId === lens.id;
          const jaCue =
            lens.id === "buddhist"
              ? "仏教という観測地点から見る"
              : lens.shortDescription;

          return (
            <li key={lens.id}>
              <button
                type="button"
                className={`lens-entry__option${selected ? " is-selected" : ""}`}
                onClick={() => onSelectLens?.(lens)}
                aria-pressed={selected}
              >
                <span className="lens-entry__option-name">{lens.name}</span>
                <span className="lens-entry__option-ja">{jaCue}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
