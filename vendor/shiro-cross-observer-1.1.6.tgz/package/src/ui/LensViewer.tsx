import type { LensInput, LensResult } from "../types/lens";
import { getBuddhistConceptById } from "../lenses/buddhist/concepts";
import { getLensDefinition } from "../registry/lens-registry";

type Props = {
  input: LensInput;
  result: LensResult;
  className?: string;
};

function conceptLabel(id: string): string {
  const c = getBuddhistConceptById(id);
  if (!c) return id;
  return `${c.code} ${c.nameJa} / ${c.name}`;
}

/**
 * Neutral / quiet / analytical Lens Result viewer.
 * No religious ornamentation.
 */
export function LensViewer({ input, result, className = "" }: Props) {
  const lens = getLensDefinition(result.lensId);

  return (
    <article className={`lens-viewer ${className}`.trim()}>
      <p className="annotation">Lens Result · derived interpretation</p>

      <section className="lens-viewer__block">
        <h2>1. Original Observation</h2>
        {input.title ? <h3 className="lens-viewer__obs-title">{input.title}</h3> : null}
        <p className="lens-viewer__obs-meta">
          Source: {input.sourceObservatory}
          {input.sourceObservationId ? ` · ${input.sourceObservationId}` : ""}
        </p>
        <p className="lens-viewer__obs-text">{input.text}</p>
        {input.context ? (
          <p className="lens-viewer__obs-context">{input.context}</p>
        ) : null}
      </section>

      <section className="lens-viewer__block">
        <h2>2. Lens</h2>
        <p>
          {lens?.name ?? result.lensId}
          {lens ? ` / ${lens.nameJa}` : ""}
          {lens ? ` · v${lens.version}` : ""}
        </p>
      </section>

      <section className="lens-viewer__block">
        <h2>3. Primary Concept</h2>
        <p>{conceptLabel(result.primaryConcept)}</p>
      </section>

      <section className="lens-viewer__block">
        <h2>4. Secondary Concepts</h2>
        <ul>
          {result.secondaryConcepts.map((id) => (
            <li key={id}>{conceptLabel(id)}</li>
          ))}
        </ul>
      </section>

      <section className="lens-viewer__block">
        <h2>5. Interpretation</h2>
        <p>{result.interpretation}</p>
      </section>

      <section className="lens-viewer__block">
        <h2>6. What becomes visible</h2>
        <ul>
          {result.whatBecomesVisible.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>

      <section className="lens-viewer__block">
        <h2>7. What this lens cannot determine</h2>
        <ul>
          {result.limitations.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>

      <section className="lens-viewer__block">
        <h2>8. Reflection Question</h2>
        <p className="lens-viewer__reflection">{result.reflectionQuestion}</p>
      </section>

      {result.relatedPatterns && result.relatedPatterns.length > 0 ? (
        <section className="lens-viewer__block lens-viewer__related">
          <h2>Related Patterns</h2>
          <ul className="lens-viewer__related-list">
            {result.relatedPatterns.map((p) => (
              <li key={p.id} className="lens-viewer__related-item">
                <p className="annotation">
                  Related Pattern — {p.name}
                  {p.nameJa ? ` / ${p.nameJa}` : ""}
                </p>
                <p>{p.description}</p>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </article>
  );
}
