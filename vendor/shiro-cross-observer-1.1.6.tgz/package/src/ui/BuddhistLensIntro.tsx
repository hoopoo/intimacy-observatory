import { BUDDHIST_LENS_COPY } from "../lenses/buddhist/copy";
import { BUDDHIST_CONCEPTS } from "../lenses/buddhist/concepts";

type Props = {
  compact?: boolean;
  className?: string;
};

export function BuddhistLensIntro({ compact = false, className = "" }: Props) {
  return (
    <header className={`buddhist-intro ${className}`.trim()}>
      <p className="annotation">Lens Layer</p>
      <h1 className="buddhist-intro__title">{BUDDHIST_LENS_COPY.header}</h1>
      <p className="buddhist-intro__sub">{BUDDHIST_LENS_COPY.subheading}</p>
      <p className="buddhist-intro__desc">{BUDDHIST_LENS_COPY.description}</p>

      {!compact && (
        <>
          <blockquote className="buddhist-intro__key">
            {BUDDHIST_LENS_COPY.keyStatement}
          </blockquote>
          <p className="buddhist-intro__secondary">
            {BUDDHIST_LENS_COPY.secondaryStatement}
          </p>
          <ul className="buddhist-intro__concepts">
            {BUDDHIST_CONCEPTS.map((c) => (
              <li key={c.id}>
                <span className="annotation">{c.code}</span> {c.nameJa} / {c.name}
              </li>
            ))}
          </ul>
        </>
      )}
    </header>
  );
}
