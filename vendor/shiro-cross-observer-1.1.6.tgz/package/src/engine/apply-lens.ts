import type { LensApplyOutcome, LensInput } from "../types/lens";
import { getLensApplicator, getLensDefinition } from "../registry/lens-registry";

function isValidInput(input: LensInput): input is LensInput {
  return Boolean(
    input &&
      typeof input.sourceObservatory === "string" &&
      input.sourceObservatory.length > 0 &&
      typeof input.text === "string" &&
      input.text.trim().length > 0,
  );
}

/**
 * Apply a registered Lens to a LensInput.
 * - Does not mutate the original input
 * - Unknown lens IDs fail safely
 */
export function applyLens(
  lensId: string,
  input: LensInput,
): LensApplyOutcome {
  const frozenInput: Readonly<LensInput> = Object.freeze({
    ...input,
    metadata: input.metadata ? { ...input.metadata } : undefined,
  });

  if (!isValidInput(input)) {
    return {
      ok: false,
      code: "invalid_input",
      message: "LensInput requires non-empty sourceObservatory and text.",
    };
  }

  const definition = getLensDefinition(lensId);
  if (!definition) {
    return {
      ok: false,
      code: "unknown_lens",
      message: `Unknown lens id: ${lensId}`,
    };
  }

  if (definition.status !== "active") {
    return {
      ok: false,
      code: "inactive_lens",
      message: `Lens is not active: ${lensId}`,
    };
  }

  const applicator = getLensApplicator(lensId);
  if (!applicator) {
    return {
      ok: false,
      code: "unknown_lens",
      message: `No applicator for lens id: ${lensId}`,
    };
  }

  const result = applicator(input);

  return {
    ok: true,
    result,
    originalInput: frozenInput,
  };
}
