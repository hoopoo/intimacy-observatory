import type { SupportedObservatoryId } from "./observatory";

export type LensStatus = "active" | "roadmap" | "retired";

/**
 * A reusable interpretive concept belonging to a Lens
 * (e.g. B01 Impermanence within Buddhist Lens).
 */
export type LensConcept = {
  id: string;
  code: string;
  name: string;
  nameJa: string;
  question: string;
  focus: string[];
  notes?: string;
};

export type LensDefinition = {
  id: string;
  slug: string;
  name: string;
  nameJa: string;
  description: string;
  shortDescription: string;
  concepts: LensConcept[];
  observationQuestions: string[];
  safeguards: string[];
  supportedObservatories: SupportedObservatoryId[];
  status: LensStatus;
  version: string;
};

/**
 * Common input to any Lens.
 * Observatory-specific structures must be adapted into this shape.
 * Lenses must not depend on Observatory internal data models.
 */
export type LensInput = {
  sourceObservatory: string;
  sourceObservationId?: string;
  title?: string;
  text: string;
  context?: string;
  metadata?: Record<string, unknown>;
};

/**
 * Derived interpretation produced by a Lens.
 * Never mutates or replaces the original Observation.
 */
export type LensResult = {
  lensId: string;
  sourceObservatory: string;
  sourceObservationId?: string;

  primaryConcept: string;
  secondaryConcepts: string[];

  interpretation: string;
  whatBecomesVisible: string[];
  limitations: string[];
  reflectionQuestion: string;

  /** Optional notes / related patterns — kept minimal for v1. */
  notes?: string[];
  relatedPatterns?: RelatedPattern[];
};

export type RelatedPattern = {
  id: string;
  name: string;
  nameJa?: string;
  relationship: "related" | "adjacent" | "not-identical";
  description: string;
};

export type LensApplyErrorCode = "unknown_lens" | "inactive_lens" | "invalid_input";

export type LensApplyError = {
  ok: false;
  code: LensApplyErrorCode;
  message: string;
};

export type LensApplySuccess = {
  ok: true;
  result: LensResult;
  /** Frozen snapshot of the input — proves non-mutation contract. */
  originalInput: Readonly<LensInput>;
};

export type LensApplyOutcome = LensApplySuccess | LensApplyError;
