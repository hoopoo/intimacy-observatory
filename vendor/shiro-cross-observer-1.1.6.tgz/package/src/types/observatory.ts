/**
 * Observatory IDs that the Lens Layer can connect to.
 * Observatories determine WHAT we observe — not HOW we interpret.
 */
export const SUPPORTED_OBSERVATORY_IDS = [
  "parallel-life",
  "scam",
  "employment",
  "education",
  "clean-society",
  "entangled-society",
  "intimacy",
  "market-signals",
  "body-meaning",
  "literature",
] as const;

export type SupportedObservatoryId = (typeof SUPPORTED_OBSERVATORY_IDS)[number];

export function isSupportedObservatoryId(
  value: string,
): value is SupportedObservatoryId {
  return (SUPPORTED_OBSERVATORY_IDS as readonly string[]).includes(value);
}
