/**
 * SHIRO & Co. layer separation (v1 architecture note).
 *
 * Protocol Layer  = how thinking proceeds (e.g. Kosuke Protocol)
 * Lens Layer      = from which perspective we see (this package)
 * Observatory Layer = what we observe
 *
 * These layers must remain separable.
 * Kosuke Protocol is NOT a Lens and must not be registered as one.
 */

export const ARCHITECTURE_LAYERS = {
  protocol: {
    id: "protocol",
    name: "Protocol Layer",
    role: "どう思考を進めるか",
    examples: ["Kosuke Protocol"],
    note: "Lens より上位の処理系になり得る。Lens と混同しない。",
  },
  lens: {
    id: "lens",
    name: "Lens Layer",
    role: "どの視点から見るか",
    examples: ["Buddhist Lens", "(future) Stoic Lens", "(future) Taoist Lens"],
    note: "Observation を書き換えず、derived interpretation を返す。",
  },
  observatory: {
    id: "observatory",
    name: "Observatory Layer",
    role: "何を観測するか",
    examples: [
      "Parallel Life",
      "Clean Society",
      "Entangled Society",
      "Scam Folklore",
    ],
    note: "Observatories determine WHAT we observe. Lenses determine HOW we see it.",
  },
} as const;

/**
 * Future: the same Observation may be compared across multiple Lenses.
 * Compare UI is intentionally not implemented in v1.
 */
export type FutureMultiLensComparison = {
  observationId: string;
  lensIds: string[];
  /** Reserved for a future Compare Lenses UI. */
  compareEnabled: false;
};
