import {
  adaptParallelLife,
  adaptCleanSociety,
  adaptEntangledSociety,
} from "../adapters/index";
import type { LensInput } from "../types/lens";

export type DemoObservation = {
  id: string;
  observatoryId: string;
  observatoryName: string;
  label: string;
  input: LensInput;
};

export const DEMO_OBSERVATIONS: DemoObservation[] = [
  {
    id: "pl-001",
    observatoryId: "parallel-life",
    observatoryName: "Parallel Life",
    label: "別の人生を知りたい",
    input: adaptParallelLife({
      id: "pl-001",
      branchQuestion:
        "もし大学を中退せずに大手に就職していたら、今の私はもっと安定して評価されていたのではないか。別の人生を知りたい。後悔と失われた可能性が頭から離れない。",
      lifeContext:
        "安心したい、承認されたいという欲求が、平行世界の探索を駆動している可能性がある。",
    }),
  },
  {
    id: "cs-001",
    observatoryId: "clean-society",
    observatoryName: "Clean Society",
    label: "Composite Evil 隣接ケース",
    input: adaptCleanSociety({
      id: "cs-001",
      title: "誰も悪人ではない接続",
      caseText:
        "成長したい会社、KPIを達成したい管理職、評価されたい従業員、安く便利に使いたい顧客、利益を増やしたい投資家。それぞれの正常な欲望と合理的判断が接続され、過剰労働と見えない被害が立ち上がる。合成悪として読める構造がある。",
      mentionsCompositeEvil: true,
    }),
  },
  {
    id: "es-001",
    observatoryId: "entangled-society",
    observatoryName: "Entangled Society",
    label: "絡み合う因果の観測",
    input: adaptEntangledSociety({
      id: "es-001",
      title: "分配される結果",
      entryText:
        "この現象は単一の犯人や単独原因では説明できない。制度、市場、身体、言語、広告が条件として接続し、結果が不均等に分配されている。絡み合う因果を観測する。",
      entanglementNote:
        "縁起という思想的レンズとは隣接するが、同一の分析システムではない。",
    }),
  },
];

export function getDemoObservation(id: string): DemoObservation | undefined {
  return DEMO_OBSERVATIONS.find((d) => d.id === id);
}
