import type { LensDefinition, LensInput, LensResult } from "../types/lens";
import {
  BUDDHIST_LENS_DEFINITION,
  BUDDHIST_LENS_ID,
  applyBuddhistLens,
} from "../lenses/buddhist/index";
import { FUTURE_LENS_CANDIDATES } from "./future-lenses";

type LensApplicator = (input: LensInput) => LensResult;

type RegistryEntry = {
  definition: LensDefinition;
  apply: LensApplicator;
};

const ACTIVE_LENSES: RegistryEntry[] = [
  {
    definition: BUDDHIST_LENS_DEFINITION,
    apply: applyBuddhistLens,
  },
];

const byId = new Map(ACTIVE_LENSES.map((e) => [e.definition.id, e]));
const bySlug = new Map(ACTIVE_LENSES.map((e) => [e.definition.slug, e]));

export function listLenses(): LensDefinition[] {
  return ACTIVE_LENSES.map((e) => e.definition);
}

export function listActiveLenses(): LensDefinition[] {
  return listLenses().filter((l) => l.status === "active");
}

export function getLensDefinition(idOrSlug: string): LensDefinition | undefined {
  return byId.get(idOrSlug)?.definition ?? bySlug.get(idOrSlug)?.definition;
}

export function hasLens(idOrSlug: string): boolean {
  return byId.has(idOrSlug) || bySlug.has(idOrSlug);
}

export function getLensApplicator(idOrSlug: string): LensApplicator | undefined {
  return byId.get(idOrSlug)?.apply ?? bySlug.get(idOrSlug)?.apply;
}

export function isBuddhistLensRegistered(): boolean {
  const lens = getLensDefinition(BUDDHIST_LENS_ID);
  return Boolean(lens && lens.status === "active" && lens.version === "1.0.0");
}

export function listFutureLensCandidates() {
  return FUTURE_LENS_CANDIDATES;
}

/** Registry snapshot for diagnostics / tests. */
export function getLensRegistrySnapshot() {
  return {
    active: listActiveLenses().map((l) => ({
      id: l.id,
      slug: l.slug,
      version: l.version,
      status: l.status,
    })),
    future: FUTURE_LENS_CANDIDATES.map((l) => l.id),
  };
}
