/**
 * Future Lens candidates — NOT implemented in v1.
 * Architecture is extensible; Compare Lenses UI is also deferred.
 */
export const FUTURE_LENS_CANDIDATES = [
  {
    id: "stoicism",
    slug: "stoicism",
    name: "Stoic Lens",
    nameJa: "ストア派レンズ",
    status: "roadmap" as const,
    sketch: "controllable / uncontrollable",
  },
  {
    id: "taoism",
    slug: "taoism",
    name: "Taoist Lens",
    nameJa: "道教レンズ",
    status: "roadmap" as const,
    sketch: "effort / flow",
  },
  {
    id: "christian-thought",
    slug: "christian-thought",
    name: "Christian Thought Lens",
    nameJa: "キリスト教思想レンズ",
    status: "roadmap" as const,
    sketch: "grace / responsibility",
  },
  {
    id: "confucianism",
    slug: "confucianism",
    name: "Confucian Lens",
    nameJa: "儒家レンズ",
    status: "roadmap" as const,
    sketch: "role / harmony",
  },
  {
    id: "shinto",
    slug: "shinto",
    name: "Shinto Lens",
    nameJa: "神道レンズ",
    status: "roadmap" as const,
    sketch: "purity / relation to place",
  },
  {
    id: "existentialism",
    slug: "existentialism",
    name: "Existentialist Lens",
    nameJa: "実存主義レンズ",
    status: "roadmap" as const,
    sketch: "freedom / responsibility",
  },
] as const;
